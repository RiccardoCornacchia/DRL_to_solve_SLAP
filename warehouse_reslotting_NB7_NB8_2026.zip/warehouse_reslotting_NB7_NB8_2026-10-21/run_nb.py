import sys, nbformat, time
from nbclient import NotebookClient
name = sys.argv[1]; nb = nbformat.read(name, as_version=4); t0 = time.time()
client = NotebookClient(nb, timeout=1700, kernel_name="python3", allow_errors=True, resources={"metadata": {"path": "."}})
with client.setup_kernel():
    for i, cell in enumerate(nb.cells):
        if cell.cell_type != "code": continue
        t = time.time(); client.execute_cell(cell, i); nbformat.write(nb, name)
        err = [o for o in cell.get("outputs", []) if o.get("output_type") == "error"]
        print(f"cell {i}: {time.time()-t:.0f}s {'ERROR ' + err[0]['ename'] + ': ' + err[0]['evalue'][:200] if err else 'ok'}", flush=True)
print(f"done {name}: {time.time()-t0:.0f}s", flush=True)
