# Dati di prelievo di magazzino — versione anonimizzata

Dati reali di prelievo di un magazzino sanitario: 58.616 giri di prelievo,
441.190 prelievi singoli, 2.385 articoli, 972 posizioni di stoccaggio,
circa dieci mesi di attività.

Gli identificatori sono stati sostituiti da codici opachi:

| tipo | codice | esempio |
|---|---|---|
| articolo | `ART####` | `ART0870` |
| posizione di stoccaggio | `LOC####` | `LOC1080` |
| transazione (lista di prelievo) | `TRX#####` | `TRX18403` |

La corrispondenza è biunivoca: articoli, posizioni e transazioni restano
distinguibili e collegabili fra i file esattamente come negli originali. Tutto
il resto è invariato: tempi, quantità, livelli di scaffale, categorie merceologiche,
coordinate sulla piantina, distanze. I dati sono quindi pienamente lavorabili.

## File

| file | una riga è | note |
|---|---|---|
| `liste_prelievo.csv` | un giro di prelievo | `transazione ; tempo_totale_s ; prodotto ; prodotto ; ...` — righe di lunghezza variabile, prodotti in ordine cronologico di prelievo |
| `transazioni_dettaglio.csv` | un giro | misure di tempo alternative, conteggi, quantità |
| `righe_prelievo.csv` | un singolo prelievo | posizione, livello, inizio, fine, durata |
| `slotting_attuale.csv` | un articolo | dove è stoccato oggi |
| `mappa_magazzino.csv` | una posizione | coordinate (riga, colonna) sulla griglia della piantina |
| `costo_livelli.csv` | un livello di scaffale | durata mediana del prelievo |
| `istanza_qap/` | — | problema di assegnazione quadratica già pronto: `D.npy` distanze, `F.npy` co-prelievi, `locazioni.csv`, `assegnazione_attuale.csv` |

Delimitatore `;`, UTF-8, tempi in secondi interi, nessun campo contiene il
delimitatore o virgolette.

## Avvertenze d'uso

* `tempo_totale_s` è tempo di lavoro effettivo: le pause fra un prelievo e il
  successivo non sono contate, le righe sovrapposte non sono contate due volte.
* Le distanze in `D.npy` sono in celle della griglia della piantina (una cella =
  un vano di scaffale), calcolate camminando sul pavimento, non in linea d'aria.
* L'indice `0..971` di `locazioni.csv` è l'indice di riga e colonna di `D` e `F`.
* Gli articoli sono più delle posizioni: in media 2,45 articoli per vano.
* Il tempo è dominato dalla manipolazione (~71 s per prelievo) più che dal
  cammino (~0,55 s per cella percorsa): il cammino è circa il 29% del tempo
  totale.
