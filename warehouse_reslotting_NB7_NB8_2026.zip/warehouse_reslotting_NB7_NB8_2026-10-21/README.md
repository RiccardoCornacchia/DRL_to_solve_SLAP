# Warehouse re-slotting under a budget: the two notebooks, the package and the data

Everything needed to run the method on the two warehouses, with the same code.

* `Warehouse_NB7_Footwear.ipynb` and `Warehouse_NB8_Pharma.ipynb`: the two notebooks, generated from the same flow by `build_nb.py` (they differ only in `DATASET = ...` and in the dataset-specific checks of section 9). Open them in Jupyter from this folder and run the cells in order. Delivered executed in QUICK mode with `RUN_NETWORK=0` (greedy only): the network and video cells are ready and run on a machine with PyTorch. Both notebooks are executed to the end in this mode; their caches (`cache_footwear/`, `cache_pharma/`) are included, so reopening them recomputes nothing until the network cells. With 2,385 product types the slowest cell of the pharmaceutical notebook is the protocol comparison of section 6 (24 minutes with the greedy in QUICK mode).
* `whrl_pkg/`: the Python package with the method (`pip install -e whrl_pkg` once). `whrl_pkg/README.md` explains the modules, the run modes of the notebooks (`QUICK`, `RUN_NETWORK`, `RUN_VIDEOS`, `RUN_FULL`, `SURROGATE`, `SEEDS`) and the command-line runner of the full-scale protocol (`whrl_pkg/scripts/run_full_scale.py`).
* `run_nb.py <notebook>`: executes a notebook from the command line, cell by cell, saving after every cell.
* `cache_<dataset>/` (QUICK mode) and `cache_<dataset>_full/` (full scale): created by the notebooks; every heavy result is saved there as soon as it is computed, so an interrupted run resumes where it stopped, and the two modes never overwrite each other. Delete a file to recompute it. The `.json` copies are readable tables of every result.
* Data, already in place: `footwear/footwear_mendeley/` (public dataset, Mendeley Data, doi 10.17632/pf2w725pw3.1) and `pharma/` (private dataset of the pharmaceutical company: for use within the project only, not to be shared).
* `REPORT.md` (Italian): the project report; its first block is the update note with the shared decisions and what changed. `CHANGELOG.md` (Italian): what changed in this release and why, point by point. `state_of_the_art.md`: literature survey.

Training memory: the trainer replays every game chunk by chunk (`TRAIN_CHUNK_MB` in the first cell, 512 MB by default), so a long game does not run out of memory.

Prerequisites: Python 3.10+, `pip install -e whrl_pkg`, plus `pip install torch mlxtend scipy matplotlib pandas numpy nbformat nbclient ipykernel` (PyTorch only for the network cells; `imageio`/`ffmpeg` for the videos).
