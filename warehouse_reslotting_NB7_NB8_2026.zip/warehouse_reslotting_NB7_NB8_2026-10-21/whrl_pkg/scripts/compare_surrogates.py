"""Comparison between our score (association-rule weights, squared form, depot cross terms) and the index of the QAP instance
shipped with the pharmaceutical dataset (raw co-picks, linear form), rewritten per product type. Same greedy, same
window, same budgets, three seeds; every layout is judged with the true routes of the next two months.
Usage: python compare_surrogates.py footwear|pharma"""
import json, sys, time, numpy as np
from scipy.stats import spearmanr
from whrl import load_dataset, RollEnv, build_W, optimize, Judge
from whrl.knowledge import build_counts
from whrl.rolling import move_cost
name = sys.argv[1]; path = {"footwear": "footwear/footwear_mendeley", "pharma": "pharma"}[name]
ds = load_dataset(name, path); J = Judge(ds); m = ds.months; o = ds.orders[ds.orders.month.isin(m[:3])]; JM = m[3:5]
W, sp = build_W(o, ds.P, use_mlxtend=(name == "footwear")); C, c = build_counts(o, ds.P)
SURR = {"rules_squared": dict(W=W, sp=sp, gamma=0.3, beta=5.0, p=2), "rules_linear": dict(W=W, sp=sp, gamma=0.3, beta=5.0, p=1),
        "copicks_linear": dict(W=C, sp=c, gamma=0.0, beta=2.0, p=1)}
def env(key, pl, K): s = SURR[key]; return RollEnv(ds, s["W"], s["sp"], pl, K, gamma=s["gamma"], beta=s["beta"], p=s["p"])
def judge(pl): return sum(J.month_distance(pl, mm) for mm in JM)
Ks = [10, 30, 90, 150] if name == "footwear" else [30, 90, 150, 300]; SEEDS = [0, 1, 2]; mov = np.where(ds.movable)[0]
layouts = [("as-is", ds.pl_asis.copy())]; head = []
import os
out = json.load(open(f"surrogate_comparison_{name}.json")) if os.path.exists(f"surrogate_comparison_{name}.json") else {"dataset": name, "judge_months": [str(x) for x in JM], "rows": [], "head": []}
done_keys = {(h["K"], h["seed"]) for h in out["head"]}; os.makedirs(f"layouts_{name}", exist_ok=True)
d0 = judge(ds.pl_asis)
for K in Ks:
    for sd in SEEDS:
        if (K, sd) in done_keys and all(os.path.exists(f"layouts_{name}/{K}_{sd}_{i}.npy") for i in range(2)):
            for i, key in enumerate(("rules_squared", "copicks_linear")): layouts.append((f"greedy on {key}, K={K}, seed {sd}", np.load(f"layouts_{name}/{K}_{sd}_{i}.npy")))
            continue
        out["head"] = [h for h in out["head"] if (h["K"], h["seed"]) != (K, sd)]; res = {}
        for i, key in enumerate(("rules_squared", "copicks_linear")):
            t = time.time(); pl = optimize(env(key, ds.pl_asis, K), steps=1000, rng=np.random.default_rng(100 * K + sd)); np.save(f"layouts_{name}/{K}_{sd}_{i}.npy", pl)
            dj = judge(pl); cost = move_cost(ds, np.where(pl != ds.pl_asis)[0]) * len(JM) / len(m[3:])   # labour spread over the judged months
            res[key] = dict(dist=dj, gross=(d0 - dj) / d0, sec=time.time() - t); layouts.append((f"greedy on {key}, K={K}, seed {sd}", pl))
        out["head"].append(dict(K=K, seed=sd, **{k: v for k, v in res.items()}))
        json.dump(out, open(f"surrogate_comparison_{name}.json", "w"), indent=1, default=float); print(K, sd, {k: round(v["gross"], 4) for k, v in res.items()}, flush=True)
rng = np.random.default_rng(7)
for k in (20, 60, 150, 300):                                   # random layouts: k random moves from the current layout
    e = env("rules_squared", ds.pl_asis, 10 ** 9).reset(); done = 0
    while done < k:
        a = int(rng.choice(mov)); s = int(rng.integers(ds.L))
        if e.delta_put(a, s)[0] is not None: e.put(a, s); done += 1
    layouts.append((f"random, {k} moves", e.pl.copy()))
for lab, pl in layouts:
    row = dict(layout=lab, judge=judge(pl))
    for key in SURR: row[key] = env(key, pl, 10 ** 9).reset().F2
    out["rows"].append(row)
jv = [r["judge"] for r in out["rows"]]
out["spearman"] = {key: float(spearmanr([r[key] for r in out["rows"]], jv)[0]) for key in SURR}
json.dump(out, open(f"surrogate_comparison_{name}.json", "w"), indent=1, default=float); print("spearman:", out["spearman"], flush=True)

AB = out.setdefault("ablation", {}); KA = 90 if name == "footwear" else 150
for wkey, (Wx, spx, g, b) in {"association-rule weights": (W, sp, 0.3, 5.0), "raw co-picks": (C, c, 0.0, 2.0)}.items():
    for p in (1, 2):
        for sd in SEEDS:
            k = f"{wkey} | p={p} | seed {sd}"
            if k in AB: continue
            pl = optimize(RollEnv(ds, Wx, spx, ds.pl_asis, KA, gamma=g, beta=b, p=p), steps=1000, rng=np.random.default_rng(100 * KA + sd))
            AB[k] = (d0 - judge(pl)) / d0; json.dump(out, open(f"surrogate_comparison_{name}.json", "w"), indent=1, default=float); print("ablation", k, round(AB[k], 4), flush=True)
