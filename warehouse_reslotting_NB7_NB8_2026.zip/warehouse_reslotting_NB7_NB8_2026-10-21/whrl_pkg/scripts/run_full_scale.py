"""Runs the full-scale protocol (whrl.fullscale) for one dataset and prints the final table.

Examples
  python run_full_scale.py --dataset footwear --seeds 0 1 2 3 4
  python run_full_scale.py --dataset pharma --seeds 0 1 --configs greedy zero-shot      # machine A
  python run_full_scale.py --dataset pharma --seeds 2 3 4 --configs greedy zero-shot    # machine B
  python run_full_scale.py --dataset pharma --seeds 0 1 2 3 4 --summary-only            # after copying the caches together
Every (configuration, seed) is cached in --cache; an interrupted run resumes from the last checkpoint.
"""
import argparse, os, sys, json, numpy as np
from whrl import load_dataset, set_surrogate
from whrl.rolling import Judge
from whrl import fullscale as fs

p = argparse.ArgumentParser()
p.add_argument("--dataset", choices=["footwear", "pharma"], required=True)
p.add_argument("--data", default=None, help="dataset folder (default: footwear/footwear_mendeley or pharma)")
p.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2, 3, 4])
p.add_argument("--configs", nargs="+", default=["greedy", "zero-shot", "monthly", "weekly-bootstrap", "synthetic"])
p.add_argument("--k0", type=int, default=None, help="initial budget (default: the one chosen on validation by the notebook, read from cache_<dataset>/budgets.json)")
p.add_argument("--km", type=int, default=None, help="monthly retouch budget (default: as --k0)")
p.add_argument("--checkpoints", type=int, nargs="+", default=[150, 300, 450, 600, 900, 1200, 1500, 1800, 2100])
p.add_argument("--patience", type=int, default=2)
p.add_argument("--surrogate", default=None, help="score: rules_squared, copicks_linear or copicks_linear_b5 (default: the SURROGATE environment variable, else the choice of the notebook in cache_<dataset>/score_choice.json)")
p.add_argument("--cache", default=None)
p.add_argument("--summary-only", action="store_true")
a = p.parse_args()

cache_nb = f"cache_{a.dataset}"
def from_cache(name, key):
    f = f"{cache_nb}/{name}.json"
    return json.load(open(f))[key] if os.path.exists(f) else None
surrogate = a.surrogate or os.environ.get("SURROGATE") or from_cache("score_choice", "chosen") or "copicks_linear_b5"; set_surrogate(surrogate)
ds = load_dataset(a.dataset, a.data or {"footwear": "footwear/footwear_mendeley", "pharma": "pharma"}[a.dataset]); J = Judge(ds)
months = list(ds.months); WARM = 3; vol = ds.orders.groupby("month").size()
EVAL = [m for m in months[WARM:] if vol[m] >= 0.3 * vol.median()]                 # same rule as the notebooks: partial months excluded
K0 = a.k0 if a.k0 is not None else from_cache("budgets", "K0"); KM = a.km if a.km is not None else from_cache("budgets", "Km")
if K0 is None: sys.exit("no budget: run the notebook first (it chooses K0 and Km on validation) or pass --k0 and --km")
KM = int(KM or 0)
split = fs.Split(ds, J, EVAL, n_val=3); cache = a.cache or f"full_scale_{a.dataset}_{surrogate}"
print(f"{a.dataset} | score {surrogate} | validation {[str(m) for m in split.val]} | test {[str(m) for m in split.test]} | budgets K0 = {K0}, Km = {KM} per month | cache {cache}")

def greedy_unit(seed):
    net, per = fs.test_report(ds, J, split, fs.greedy_opt(ds, K0, seed=seed), K0, KM); return dict(test=net, months=per, ckpt=None)

def network_unit(kind, seed):
    train = months[:WARM]
    pool = fs.instance_pool(ds, train, kind, seed=seed)
    W0, sp0 = fs.instance_pool(ds, train, "static")[0]
    starts = [ds.pl_asis, fs.greedy_opt(ds, K0, seed=seed)(W0, sp0, ds.pl_asis, K0)] if KM > 0 else [ds.pl_asis]   # current layout (+ greedy layout for the retouch regime)
    net_pol, st = fs.train_select(ds, J, split, fs.make_sampler(pool, starts, K0, max(KM, 1)), seed, K0, max(KM, 1), a.checkpoints, a.patience,
                                  cache_path=f"{cache}/{kind}__seed{seed}__training.pt")
    net, per = fs.test_report(ds, J, split, fs.network_opt(net_pol, ds, seed=seed), K0, KM)
    return dict(test=net, months=per, ckpt=st["best_ck"], validation_curve=st["curve"])

KIND = {"zero-shot": "static", "monthly": "monthly", "weekly-bootstrap": "weekly_bootstrap", "synthetic": "synthetic"}
R = {}
for seed in a.seeds:
    for c in a.configs:
        f = f"{cache}/{c}__seed{seed}.pkl"
        if a.summary_only and not os.path.exists(f): print("missing:", f); continue
        print(f"--> {c}, seed {seed}", flush=True)
        R[(c, seed)] = fs.run_unit(cache, c, seed, (lambda s=seed: greedy_unit(s)) if c == "greedy" else (lambda s=seed, k=KIND[c]: network_unit(k, s)))
done_seeds = [s for s in a.seeds if all((c, s) in R for c in a.configs)]
if "greedy" in a.configs and done_seeds:
    T = fs.summary(R, a.configs, done_seeds); print(T.to_string()); T.to_csv(f"{cache}/summary.csv")
