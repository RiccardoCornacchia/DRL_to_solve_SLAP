"""Warehouse state and moves. Same logic as RollEnv in Notebook 6, generalized:
  * distances come from a matrix D (along the aisles for footwear, walking distance for pharma);
  * a position may hold several product types (capacity): a move either relocates a product type to a position
    with free capacity or swaps it with a product type in the target position;
  * every product type can be chosen (ds.movable is all True in both warehouses; a restriction is an ablation only);
  * moves="swap_only" disables relocations to free capacity (comparison of move sets).
Score F = sum of M**p (p = 2: squared Frobenius norm, our default; p = 1: linear form, as in the Koopmans-Beckmann
quadratic assignment), with M = W * (D_pp + gamma (De_p + De_q)) off the diagonal and beta * sp * De_p on the diagonal.
Budget K = number of product types whose FINAL position differs from the starting one."""
import numpy as np

# Score configuration shared by the whole package: set by knowledge.set_surrogate().
SURROGATE_PARAMS = dict(gamma=0.3, beta=5.0, p=2)

class RollEnv:
    def __init__(self, ds, W, sp, pl_start, K, gamma=None, beta=None, p=None, moves="general"):
        """moves: "general" (relocation to free capacity or swap) or "swap_only" (swaps only)."""
        gamma = SURROGATE_PARAMS["gamma"] if gamma is None else gamma
        beta = SURROGATE_PARAMS["beta"] if beta is None else beta
        p = SURROGATE_PARAMS["p"] if p is None else p
        self.ds = ds; self.D = ds.D; self.d_exit = ds.d_exit; self.cap = ds.capacity
        self.W = W; self.sp = sp / (sp.max() + 1e-12); self.pl_ref = pl_start.copy(); self.K = K
        self.gamma = gamma; self.beta = beta; self.p = p; self.moves = moves
    def full_M(self, pl):
        Dpp = self.D[np.ix_(pl, pl)]; De = self.d_exit[pl]
        M = self.W * (Dpp + self.gamma * (De[:, None] + De[None, :]))
        np.fill_diagonal(M, self.beta * self.sp * De)
        return M
    def reset(self):
        self.pl = self.pl_ref.copy(); self.M = self.full_M(self.pl); self.F2 = float((self.M ** self.p).sum())
        self.rowsum = np.abs(self.M).sum(1)       # row sums updated in O(P) per move instead of recomputed in O(P^2)
        self.moved = set()
        self.occ = {s: [] for s in range(self.ds.L)}
        for p, s in enumerate(self.pl): self.occ[int(s)].append(p)
        self.free = {s for s in range(self.ds.L) if len(self.occ[s]) < self.cap[s]}
        return self
    def misplacement(self, tau=1.0):
        """Sampling weights of the greedy: the misplacement of every product type (its weight in F) raised to tau and
        normalized; tau = 0 gives uniform weights."""
        if tau == 0.0: return np.ones_like(self.rowsum) / len(self.rowsum)
        m = np.maximum(self.rowsum, 1e-12) ** tau
        return m / (m.sum() + 1e-12)
    def _row(self, p, pl):
        lp = pl[p]
        row = self.W[p] * (self.D[lp, pl] + self.gamma * (self.d_exit[lp] + self.d_exit[pl])); row[p] = 0.0
        return row, self.beta * self.sp[p] * self.d_exit[lp]
    def _delta_swap(self, a, b):
        pl2 = self.pl.copy(); pl2[a], pl2[b] = pl2[b], pl2[a]
        na, da_ = self._row(a, pl2); nb, db_ = self._row(b, pl2)
        oa = self.M[a].copy(); ob = self.M[b].copy(); oda, odb = oa[a], ob[b]; oa[a] = 0.0; ob[b] = 0.0
        p = self.p
        old = 2 * (oa ** p).sum() + 2 * (ob ** p).sum() - 2 * oa[b] ** p + oda ** p + odb ** p
        new = 2 * (na ** p).sum() + 2 * (nb ** p).sum() - 2 * na[b] ** p + da_ ** p + db_ ** p
        return float(old - new)
    def delta_put(self, a, s):
        """Improvement of F if product type a goes to position s (None if impossible).
        Returns (delta, partner): partner = swapped product type, or None for a move to free capacity."""
        s = int(s)
        if s == self.pl[a]: return None, None
        if s in self.free and self.moves == "general":
            pl2 = self.pl.copy(); pl2[a] = s
            nr, nd = self._row(a, pl2); orow = self.M[a].copy(); od = orow[a]; orow[a] = 0.0
            p = self.p
            return float((2 * (orow ** p).sum() + od ** p) - (2 * (nr ** p).sum() + nd ** p)), None
        cands = [b for b in self.occ[s] if self.ds.movable[b]]
        if not cands: return None, None
        best = max(cands, key=lambda b: self._delta_swap(a, b))
        return self._delta_swap(a, best), best
    def put(self, a, s):
        d, b = self.delta_put(a, s)
        if d is None: return 0.0, False
        s = int(s)
        if b is None:
            ma = {p for p in (self.moved | {a}) if (s if p == a else self.pl[p]) != self.pl_ref[p]}
            if len(ma) > self.K: return 0.0, False
            olds = int(self.pl[a]); self.pl[a] = s; old_a = self.M[a].copy()
            row, diag = self._row(a, self.pl); self.M[a, :] = row; self.M[:, a] = row; self.M[a, a] = diag
            self.rowsum += np.abs(self.M[a]) - np.abs(old_a); self.rowsum[a] = np.abs(self.M[a]).sum()
            self.occ[olds].remove(a); self.occ[s].append(a)
            if len(self.occ[s]) >= self.cap[s]: self.free.discard(s)
            if len(self.occ[olds]) < self.cap[olds]: self.free.add(olds)
        else:
            sa, sb = int(self.pl[a]), int(self.pl[b]); ma = set(self.moved)
            for p, tgt in [(a, sb), (b, sa)]:
                ma.add(p) if tgt != self.pl_ref[p] else ma.discard(p)
            if len(ma) > self.K: return 0.0, False
            self.pl[a], self.pl[b] = sb, sa; old_a = self.M[a].copy(); old_b = self.M[b].copy()
            for p in (a, b):
                row, diag = self._row(p, self.pl); self.M[p, :] = row; self.M[:, p] = row; self.M[p, p] = diag
            dm = (np.abs(self.M[a]) - np.abs(old_a)) + (np.abs(self.M[b]) - np.abs(old_b)); self.rowsum += dm
            self.rowsum[a] = np.abs(self.M[a]).sum(); self.rowsum[b] = np.abs(self.M[b]).sum()
            self.occ[sa].remove(a); self.occ[sa].append(b); self.occ[sb].remove(b); self.occ[sb].append(a)
        self.F2 -= d; self.moved = ma
        return d, True
