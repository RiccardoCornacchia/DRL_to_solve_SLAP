import numpy as np
from scipy import stats
def paired_tests(a, b):
    """a, b: paired arrays (same seed, same month). Returns a dict: t and p_t (paired t-test),
    wilcoxon and p_w (Wilcoxon signed-rank test on the differences), mean_diff (mean of a - b)."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    t, p = stats.ttest_rel(a, b)
    try: w, pw = stats.wilcoxon(a - b)
    except ValueError: w, pw = np.nan, np.nan
    return dict(t=float(t), p_t=float(p), wilcoxon=float(w), p_w=float(pw), mean_diff=float((a - b).mean()))
