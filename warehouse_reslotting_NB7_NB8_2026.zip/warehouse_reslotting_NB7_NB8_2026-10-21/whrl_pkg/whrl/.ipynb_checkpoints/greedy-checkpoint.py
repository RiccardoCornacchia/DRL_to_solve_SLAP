"""Reference optimizer without learning. WHO: sampled in proportion to its current misplacement (its weight
in F). WHERE: the best of a few candidate positions (random, near the depot, near its partners). Moves that worsen
F are accepted (to escape local minima) and the best layout seen is returned."""
import numpy as np

def candidates(env, a, rng, n_rand=12, n_exit=8, n_partner=6):
    fa = np.array(sorted(env.free)); occ_slots = np.array([s for s in range(env.ds.L) if env.occ[s]])
    cs = set()
    if len(fa):
        cs |= set(rng.choice(fa, size=min(n_rand, len(fa)), replace=False).tolist())
        cs |= set(fa[np.argsort(env.d_exit[fa])[:n_exit]].tolist())
    if len(occ_slots): cs |= set(rng.choice(occ_slots, size=min(n_rand, len(occ_slots)), replace=False).tolist())
    for p in np.argsort(-env.W[a])[:n_partner]:
        if p != a: cs.add(int(env.pl[p]))
    cs.discard(int(env.pl[a]))
    return sorted(cs)

def optimize(env, steps=1500, rng=None, window=100, temperature="adaptive"):
    """Greedy local search. At every step a product type is sampled with probability proportional to its misplacement
    raised to a temperature tau (tau = 1: proportional; tau > 1: concentrated on the worst-placed product types;
    tau = 0: uniform); the best of a few candidate positions is executed; worsening moves are accepted; the best layout
    seen is returned.
    temperature: a number (fixed tau) or "adaptive" (Riccardo Cornacchia, October 2026): tau starts at 1.5 and, every
    `window` steps, decreases by 0.15 while the moves keep paying (more exploration), or rises by 0.30 when the gain of
    the last window fell below half of the previous one (back to the worst-placed product types)."""
    rng = rng or np.random.default_rng(0)
    env.reset(); best_F2, best_pl = env.F2, env.pl.copy()
    mov = np.where(env.ds.movable)[0]
    adaptive = temperature == "adaptive"
    tau0 = 1.5 if adaptive else float(temperature); tau = tau0
    tau_step_down, tau_step_up = 0.15, 0.30
    window_gain, prev_rate = [], None
    for step in range(steps):
        mp = env.misplacement(tau)[mov]; mp = mp / (mp.sum() + 1e-12)
        a = int(rng.choice(mov, p=mp))
        cs = candidates(env, a, rng)
        if not cs: continue
        ds = [env.delta_put(a, s)[0] for s in cs]; ds = [(-1e18 if d is None else d) for d in ds]
        j = int(np.argmax(ds))
        env.put(a, cs[j])
        if env.F2 < best_F2: best_F2, best_pl = env.F2, env.pl.copy()
        if adaptive:
            window_gain.append(ds[j])
            if (step + 1) % window == 0:
                rate = float(np.sum(window_gain)); window_gain = []
                if prev_rate is not None and rate < 0.5 * prev_rate and tau < tau0: tau = min(tau0, tau + tau_step_up)
                else: tau = max(0.0, tau - tau_step_down)
                prev_rate = rate
    env.pl = best_pl; return best_pl
