"""The network that chooses WHO to move. Tokens = movable product types; 6 descriptors per token; Transformer
encoder without positional encoding (a set, not a sequence); linear head -> one number per product type ->
softmax = probability of being chosen; -inf (probability zero) for product types forbidden by the budget.
WHERE is decided by the same verifier as the greedy (best improvement of F among candidate positions).
Training with REINFORCE: B parallel games on the same instance, reward = improvement of F per move,
baseline = batch mean (standardized)."""
import numpy as np, torch, torch.nn as nn
from .greedy import candidates
from .env import RollEnv

class ProductPolicy(nn.Module):
    def __init__(self, d_in=6, d=64, heads=4, layers=1, ff=256):
        super().__init__()
        self.inp = nn.Linear(d_in, d)
        enc = nn.TransformerEncoderLayer(d, heads, ff, dropout=0.0, batch_first=True)
        self.enc = nn.TransformerEncoder(enc, layers); self.out = nn.Linear(d, 1)
    def logits(self, X, mask):
        h = self.enc(self.inp(X)); return self.out(h).squeeze(-1).masked_fill(~mask, -1e9)
    def forward(self, X, mask):
        dist = torch.distributions.Categorical(logits=self.logits(X, mask)); a = dist.sample()
        return a, dist.log_prob(a), dist.probs
    def log_prob_of(self, X, mask, a):
        """Log-probability of given actions a (used to recompute the gradient of a recorded game, chunk by chunk)."""
        return torch.distributions.Categorical(logits=self.logits(X, mask)).log_prob(a)

def features(envs, sp, mov):
    xy_max = envs[0].ds.slot_xy.max(); de_max = envs[0].d_exit.max() + 1e-12
    F = np.zeros((len(envs), len(mov), 6), dtype=np.float32); sp_n = sp / (sp.max() + 1e-12)
    for i, e in enumerate(envs):
        pl = e.pl[mov]
        F[i, :, 0:2] = e.ds.slot_xy[pl] / xy_max; F[i, :, 2] = e.d_exit[pl] / de_max; F[i, :, 3] = sp_n[mov]
        m = e.rowsum[mov]; F[i, :, 4] = m / (m.max() + 1e-12)
        F[i, :, 5] = [1.0 if p in e.moved else 0.0 for p in mov]
    return torch.tensor(F)

def budget_mask(envs, mov):
    M_ = np.ones((len(envs), len(mov)), dtype=bool); pos = {p: i for i, p in enumerate(mov)}
    for i, e in enumerate(envs):
        if len(e.moved) >= e.K:
            M_[i, :] = False
            for p in e.moved:
                if p in pos: M_[i, pos[p]] = True
    return torch.tensor(M_)

def play(policy, envs, sp, mov, T, rng, train=False, record=None):
    """Plays T moves on every env. Returns per-step log-probabilities and rewards (for training).
    train=True keeps the computation graph of every move (memory grows with T: see make_trainer).
    record: if a list is given, every move is appended as (sampled action indices, [(product type, position) or None per env]),
    so that the same game can be replayed later without the random choices."""
    logps, rews = [], []
    for t in range(T):
        X, m = features(envs, sp, mov), budget_mask(envs, mov)
        if train: a_t, lp, _ = policy(X, m)
        else:
            with torch.no_grad(): a_t, lp, _ = policy(X, m)
        r = np.zeros(len(envs), dtype=np.float32); slots = [None] * len(envs)
        for i, e in enumerate(envs):
            a = int(mov[int(a_t[i])]); cs = candidates(e, a, rng)
            if not cs: continue
            ds = [e.delta_put(a, s)[0] for s in cs]; ds = [(-1e18 if d is None else d) for d in ds]
            s_ = cs[int(np.argmax(ds))]; d, ok = e.put(a, s_); r[i] = d if ok else 0.0; slots[i] = (a, s_)
        logps.append(lp); rews.append(r)
        if record is not None: record.append((a_t.detach().clone(), slots))
    return torch.stack(logps, 1), np.stack(rews, 1)

def policy_reorganize(policy, ds, W, sp, pl_start, K, n_games=6, T_moves=None, rng=None, gamma=None, beta=None):
    rng = rng or np.random.default_rng(0); T = T_moves or 4 * K; mov = np.where(ds.movable)[0]   # 4 moves per unit of budget (Notebook 6, 10.2): enough to spend the whole budget; no fixed cap, so that a large budget is never cut
    envs = [RollEnv(ds, W, sp, pl_start, K, gamma, beta).reset() for _ in range(n_games)]
    play(policy, envs, sp, mov, T, rng)
    return min(envs, key=lambda e: e.F2).pl.copy()

def moves_per_chunk(P, B, chunk_mb=512, heads=4, d=64, ff=256):
    """How many moves of a game can be back-propagated together within about chunk_mb of memory: the graph of one move
    holds the attention weights (B x heads x P x P) and the activations of the feed-forward (B x P x (ff + 3 d)), in float32,
    counted twice for safety."""
    per_move = B * (heads * P * P + P * (ff + 3 * d)) * 4 * 2
    return max(1, int(chunk_mb * 2 ** 20 / per_move))

def make_trainer(policy, ds, sampler, B=8, T=60, lr=1e-3, seed=0, T_by_regime=None, memory="chunked", chunk_mb=512):
    """sampler(rng) -> (W, sp, pl_start, K). T_by_regime: dict K -> game length in moves (games adapted to the regime).
    REINFORCE with the total return of the game as reward and the batch mean as baseline; the loss of a game is
    -(sum over the moves of the log-probability of the chosen product type) x advantage.
    memory="full": the graph of the whole game is kept and one backward is done at the end (memory grows with the game
    length x the number of product types squared: it is what runs out of memory on long games).
    memory="chunked" (default): the game is first played without graph, recording the moves; then the same moves are
    replayed on fresh copies of the environments, the log-probabilities are recomputed with the graph a few moves at a
    time (moves_per_chunk) and the gradient is accumulated chunk by chunk. The gradient is the same as with "full"
    (the loss is a sum over the moves), the memory is bounded by the chunk. The cost is one extra forward pass per move."""
    opt = torch.optim.Adam(policy.parameters(), lr=lr); rng = np.random.default_rng(seed); mov = np.where(ds.movable)[0]
    hist = []; chunk = moves_per_chunk(len(mov), B, chunk_mb)
    def step(n_iters, on_iter=None):
        for it in range(n_iters):
            W, sp, pl0, K = sampler(rng); Tk = (T_by_regime or {}).get(K, T)
            envs = [RollEnv(ds, W, sp, pl0, K).reset() for _ in range(B)]
            if memory == "full":
                lp, r = play(policy, envs, sp, mov, Tk, rng, train=True)
                R = torch.tensor(r.sum(1)); adv = (R - R.mean()) / (R.std() + 1e-6)
                loss = -(lp.sum(1) * adv).mean(); opt.zero_grad(); loss.backward(); opt.step()
            else:
                rec = []; _, r = play(policy, envs, sp, mov, Tk, rng, train=False, record=rec)     # pass 1: play, no graph
                R = torch.tensor(r.sum(1)); adv = (R - R.mean()) / (R.std() + 1e-6)
                envs2 = [RollEnv(ds, W, sp, pl0, K).reset() for _ in range(B)]                     # pass 2: replay with the graph, chunk by chunk
                opt.zero_grad()
                for c0 in range(0, Tk, chunk):
                    acc = 0.0
                    for t in range(c0, min(Tk, c0 + chunk)):
                        a_t, slots = rec[t]
                        X, m = features(envs2, sp, mov), budget_mask(envs2, mov)
                        acc = acc + policy.log_prob_of(X, m, a_t)
                        for i, e in enumerate(envs2):
                            if slots[i] is not None: e.put(*slots[i])
                    (-(acc * adv).mean()).backward()                                              # gradients add up across chunks
                opt.step()
            hist.append(float(R.mean()))
            if on_iter: on_iter(it, envs, float(R.mean()))
        return policy
    step.hist = hist; step.opt = opt; step.chunk = chunk
    return step
