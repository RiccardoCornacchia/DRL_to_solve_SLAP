"""Dataset adapters. Every adapter returns the SAME Dataset object, so the rest of the method does not know
which warehouse the data come from (the notebooks choose the dataset with one line).
Fields (all indexed by integers):
  types      : product type ids (P = len(types))
  D          : (L x L) distances between positions, in the native distance unit of the dataset
  d_exit     : (L) distance from each position to the depot
  slot_xy    : (L x 2) position coordinates on the floor plan, in distance units
  capacity   : (L) how many product types a position can hold
  pl_asis    : (P) current position of each product type
  footprint  : (P) bulk index in [0, 1] (enters the relocation cost)
  orders     : DataFrame with columns id, date, refs (list of product type indices), month
  movable    : (P) bool, the product types the optimizer may relocate (all of them, in both warehouses)
  time_model : dict(s_per_cell, s_per_pick, source) converting distance units into seconds
  unit_m     : metres per distance unit (measured for footwear, estimated for pharma)
Shared modelling decisions (identical in the two warehouses):
  * every product type has ONE position in the model (single home); how far the real warehouse is from this is
    measured by the adapter (notes: positions_per_type, main_share) and reported by the notebooks;
  * distances are the realistic walking distances of each dataset (distance="realistic": along the aisles for
    footwear, on the floor around the shelves for pharma); the Manhattan distance on the coordinates is a check only;
  * the capacity of a position is its current occupancy plus extra_capacity (0 by default);
  * all product types are movable: the budget, not a filter, limits the relocations.
"""
from dataclasses import dataclass, field
import json
import numpy as np, pandas as pd

@dataclass
class Dataset:
    name: str
    types: list
    D: np.ndarray
    d_exit: np.ndarray
    slot_xy: np.ndarray
    capacity: np.ndarray
    pl_asis: np.ndarray
    footprint: np.ndarray
    orders: pd.DataFrame
    movable: np.ndarray
    time_model: dict | None
    unit_m: float
    notes: dict = field(default_factory=dict)
    @property
    def P(self): return len(self.types)
    @property
    def L(self): return self.D.shape[0]
    @property
    def months(self): return sorted(self.orders["month"].unique())
    def seconds(self, units):
        """Distance units -> seconds of walking, with the time model of the dataset."""
        return float(units) * self.time_model["s_per_cell"]
    def hours(self, units): return self.seconds(units) / 3600.0

def _manhattan(xy, depot):
    D = np.abs(xy[:, None, :] - xy[None, :, :]).sum(-1).astype(np.float32)
    return D, np.abs(xy - depot).sum(1).astype(np.float32)

# ----------------------------------------------------------------------------- footwear
def load_footwear(path, levels=(1, 2), distance="realistic", extra_capacity=0, walk_speed=1.27):
    """distance: "realistic" (= "aisles": walking along the real aisles and corridors, from the navigation points of
    the dataset) or "manhattan" (sum of the horizontal and vertical displacements on the floor-plan coordinates). walk_speed (m/s) converts distance units into seconds: the dataset has
    no measured times, so the time model is a convention (7.6 cm per unit at 1.27 m/s = 0.0598 s per unit), chosen so
    that the relocation cost of 60,000 units equals one hour of labour."""
    loc = pd.read_csv(f"{path}/Storage_Location.csv"); loc["originalLocation"] = loc["originalLocation"].str.strip()
    co = pd.read_csv(f"{path}/Customer_Order.csv", sep=";", encoding="utf-8-sig"); co.columns = [c.strip() for c in co.columns]
    co["Reference"] = co["Reference"].str.strip(); co["creationDate"] = pd.to_datetime(co["creationDate"], dayfirst=True)
    pw = pd.read_csv(f"{path}/Picking_Wave.csv", sep=";", encoding="utf-8-sig"); pw.columns = [c.strip() for c in pw.columns]
    pw["reference"] = pw["reference"].str.strip(); pw["locations"] = pw["locations"].str.strip()
    prod = pd.read_csv(f"{path}/Product.csv", sep=";"); prod.columns = [c.strip() for c in prod.columns]
    DEPOT = np.array([403.0, -29.0]); UNIT_M = 0.076
    loc12 = loc[loc.z.isin(levels)]
    slots_xy = loc12[["x", "y"]].drop_duplicates().to_numpy(float)
    slot_index = {tuple(p): i for i, p in enumerate(slots_xy)}
    loc2slot = {r.originalLocation: slot_index[(float(r.x), float(r.y))] for r in loc12.itertuples()}
    refs = sorted(co["Reference"].unique()); ref2idx = {r: i for i, r in enumerate(refs)}; P = len(refs)
    L = len(slots_xy)
    D, d_exit = _manhattan(slots_xy, DEPOT)
    if distance in ("aisles", "realistic"):
        from .footwear_extras import load_navigation, aisle_distances
        D, d_exit = aisle_distances(slots_xy, DEPOT, load_navigation(path))
    # single home: the most-picked position on the picking levels; conflicts resolved by pick frequency
    pw12 = pw[pw["locations"].isin(loc2slot)]
    pref = pw12.groupby("reference")["locations"].agg(lambda s: s.mode().iloc[0]).map(loc2slot).to_dict()
    freq = pw.groupby("reference").size()
    pl = np.full(P, -1, int); used = set()
    for r in sorted(refs, key=lambda r: -freq.get(r, 0)):
        want = pref.get(r)
        if want is not None and want not in used: pl[ref2idx[r]] = want; used.add(want); continue
        anchor = slots_xy[want] if want is not None else DEPOT
        free = [s for s in range(L) if s not in used]
        best = min(free, key=lambda s: np.abs(slots_xy[s] - anchor).sum()); pl[ref2idx[r]] = best; used.add(best)
    # how far the real warehouse is from the single-home model (scattered storage)
    npos = pw12.groupby("reference")["locations"].nunique().reindex(refs).fillna(0).to_numpy(int)
    main_share = pw12.groupby("reference")["locations"].agg(lambda s: s.value_counts(normalize=True).iloc[0]).reindex(refs).fillna(1.0).to_numpy(float)
    # bulk index: from the product Size column when present, otherwise constant
    size = pd.to_numeric(prod.set_index("Reference").get("Size", pd.Series(dtype=float)), errors="coerce") if "Size" in prod.columns else None
    fp = np.full(P, 0.5)
    if size is not None and size.notna().any():
        s = size.reindex(refs).fillna(size.median()).to_numpy(float); fp = (s - s.min()) / (s.max() - s.min() + 1e-12)
    orders = (co.groupby("orderNumber").agg(refs=("Reference", lambda s: sorted({ref2idx[x] for x in set(s)})), date=("creationDate", "min"))
                .sort_values("date").reset_index().rename(columns={"orderNumber": "id"}))
    orders["month"] = orders["date"].dt.to_period("M")
    cap = np.ones(L, int) + int(extra_capacity)
    tm = dict(s_per_cell=UNIT_M / walk_speed, s_per_pick=None, source=f"convention: {UNIT_M*100:.1f} cm per unit at {walk_speed} m/s")
    ext = (slots_xy[:, 0].max() - slots_xy[:, 0].min()) * UNIT_M, (slots_xy[:, 1].max() - slots_xy[:, 1].min()) * UNIT_M
    return Dataset("footwear", refs, D, d_exit, slots_xy, cap, pl, fp, orders, np.ones(P, bool), tm, UNIT_M,
                   notes=dict(depot=DEPOT, levels=levels, distance=distance, extra_capacity=extra_capacity, n_positions_plan=int(loc["originalLocation"].nunique()),
                              extent_m=ext, extent_note="measured: coordinates of the dataset, 7.6 cm per unit",
                              positions_per_type=npos, main_share=main_share,
                              kappa=60_000.0, kappa_note="60,000 distance units = 4.56 km = about 1 hour of labour at 1.27 m/s (convention: no measured times)"))

# ----------------------------------------------------------------------------- pharma
def load_pharma(path, distance="realistic", extra_capacity=0, min_picks_movable=0):
    """distance: "realistic" (= "floor": walking on the floor of the plan, around shelves and walls, from the QAP
    instance shipped with the dataset) or "manhattan" (on the grid coordinates, ignoring the obstacles). min_picks_movable: 0 = every product type is movable (default, as for
    footwear); a positive value keeps the old restriction for ablations only."""
    rp = pd.read_csv(f"{path}/righe_prelievo.csv", sep=";", parse_dates=["inizio", "fine"])
    locs = pd.read_csv(f"{path}/istanza_qap/locazioni.csv", sep=";").sort_values("indice")
    asg = pd.read_csv(f"{path}/istanza_qap/assegnazione_attuale.csv", sep=";")
    sl = pd.read_csv(f"{path}/slotting_attuale.csv", sep=";")
    inst = json.load(open(f"{path}/istanza_qap/istanza.json"))
    L = len(locs); loc2idx = dict(zip(locs["locazione"], locs["indice"]))
    slot_xy = locs[["colonna", "riga"]].to_numpy(float)
    DEPOT = np.array([float(inst["deposito"]["colonna"]), float(inst["deposito"]["riga"])])
    if distance == "manhattan": D, dexit = _manhattan(slot_xy, DEPOT)
    else: D = np.load(f"{path}/istanza_qap/D.npy").astype(np.float32); dexit = np.load(f"{path}/istanza_qap/dexit.npy").astype(np.float32)
    # product types whose main position is not on the floor plan take their most-picked mapped position;
    # if they have none, they leave the instance
    rp_m = rp[rp["locazione"].isin(loc2idx)]
    alt = rp_m.groupby(["articolo", "locazione"]).size().reset_index(name="n").sort_values("n", ascending=False).drop_duplicates("articolo").set_index("articolo")["locazione"]
    asg = asg.copy(); miss = asg["indice_locazione"].isna()
    asg.loc[miss, "indice_locazione"] = asg.loc[miss, "articolo"].map(alt).map(loc2idx)
    asg = asg.dropna(subset=["indice_locazione"])
    refs = sorted(asg["articolo"].unique()); ref2idx = {r: i for i, r in enumerate(refs)}; P = len(refs)
    pl = np.full(P, -1, int)
    for r in asg.itertuples(): pl[ref2idx[r.articolo]] = int(r.indice_locazione)
    # capacity = current occupancy (shared positions) + extra_capacity
    cap = np.bincount(pl, minlength=L).astype(int); cap[cap == 0] = 1; cap += int(extra_capacity)
    # bulk index: proxy = median packs per pick (log-normalized)
    conf = rp.groupby("articolo")["confezioni_prelevate"].median().reindex(refs).fillna(1.0).to_numpy(float)
    lc = np.log1p(conf); fp = (lc - lc.min()) / (lc.max() - lc.min() + 1e-12)
    rp = rp[rp["articolo"].isin(ref2idx)]
    orders = (rp.groupby("transazione").agg(refs=("articolo", lambda s: sorted({ref2idx[x] for x in set(s)})), date=("inizio", "min"))
                .sort_values("date").reset_index().rename(columns={"transazione": "id"}))
    orders["month"] = orders["date"].dt.to_period("M")
    npicks = rp.groupby("articolo")["transazione"].nunique().reindex(refs).fillna(0).to_numpy()
    movable = npicks >= min_picks_movable if min_picks_movable > 0 else np.ones(P, bool)
    sl = sl.set_index("articolo").reindex(refs)
    npos = sl["n_locazioni"].fillna(1).to_numpy(int); main_share = sl["quota_locazione_principale"].fillna(1.0).to_numpy(float)
    UNIT_M = 0.65                                                       # estimate: 0.55 s per cell at 1.1-1.3 m/s -> 0.60-0.70 m
    tm = dict(s_per_cell=0.548, s_per_pick=71.08, walk_share=0.29, source="measured: linear model on the recorded pick times")
    g = inst["griglia"]
    return Dataset("pharma", refs, D, dexit, slot_xy, cap, pl, fp, orders, movable, tm, UNIT_M,
                   notes=dict(depot=DEPOT, distance=distance, extra_capacity=extra_capacity, n_positions_plan=1430, grid=g,
                              extent_m=(g[1] * UNIT_M, g[0] * UNIT_M), extent_note="estimate: no metric size in the dataset, 1 cell = 0.60-0.70 m from the measured 0.55 s per cell",
                              positions_per_type=npos, main_share=main_share, npicks=npicks, min_picks_movable=min_picks_movable,
                              kappa=600.0 / 0.548, kappa_note="convention: 10 minutes of labour per relocated product type = 600 s = 1,095 distance units at 0.548 s per unit (moving the whole stock of the product type, a possible swap, the update of the management system); the measured handling time of one pick, 2 x 71 s = 142 s, is a lower bound", kappa_measured_lower_bound=2 * 71.08 / 0.548))

DATASETS = {"footwear": load_footwear, "pharma": load_pharma}

def load_dataset(name, path, **kw):
    """Dataset switch: load_dataset('footwear', path) or load_dataset('pharma', path)."""
    return DATASETS[name](path, **kw)
