"""Descriptive analyses shared by the two notebooks: how the demand changes over time, how far the real layout is from
the single-home model, and the conversion of distance units into metres and hours."""
import numpy as np, pandas as pd
from scipy.stats import spearmanr

def monthly_popularity(ds):
    """{month: array P} orders containing each product type in that month."""
    o = ds.orders
    return {m: np.bincount(np.concatenate(list(o[o["month"] == m]["refs"])), minlength=ds.P) for m in ds.months}

def demand_stability(ds, top=50):
    """One row per pair of consecutive months: share of the `top` most-picked product types of the first month that are
    still among the `top` of the next month, and Spearman correlation of the monthly order counts per product type.
    1 = identical demand; lower = more churn."""
    mv = monthly_popularity(ds); months = ds.months; rows = []
    for a, b in zip(months[:-1], months[1:]):
        ta, tb = set(np.argsort(-mv[a])[:top]), set(np.argsort(-mv[b])[:top])
        rows.append(dict(from_month=str(a), to_month=str(b), top_kept=len(ta & tb) / top, spearman=float(spearmanr(mv[a], mv[b]).correlation)))
    return pd.DataFrame(rows)

def layout_profile(ds):
    """How far the real warehouse is from the single-home model: positions from which each product type is picked
    (min, mean, max), share of its picks served by its most-used position, and product types per position."""
    npos, share = ds.notes["positions_per_type"], ds.notes["main_share"]
    occ = np.bincount(ds.pl_asis, minlength=ds.L)
    return dict(positions_per_type=(int(npos.min()), float(npos.mean()), int(npos.max())),
                types_with_several_positions=int((npos > 1).sum()),
                main_position_share=(float(share.min()), float(share.mean()), float(share.max())),
                types_per_position=(int(occ[occ > 0].min()), float(occ[occ > 0].mean()), int(occ.max())),
                free_positions=int((occ < ds.capacity).sum()))

def size_summary(ds):
    """Floor-plan size in distance units and metres, and the time model, in one line."""
    xy = ds.slot_xy; ext_u = (xy[:, 0].max() - xy[:, 0].min(), xy[:, 1].max() - xy[:, 1].min()); em = ds.notes["extent_m"]
    return (f"floor plan: {ext_u[0]:.0f} x {ext_u[1]:.0f} distance units = {em[0]:.0f} x {em[1]:.0f} m ({ds.notes['extent_note']}) | "
            f"1 unit = {100*ds.unit_m:.1f} cm = {ds.time_model['s_per_cell']:.3f} s of walking ({ds.time_model['source']})")
