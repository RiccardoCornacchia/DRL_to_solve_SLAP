"""Judge (true routes over the orders), metrics and protocol over time.
Protocol: warm-up of `warm` months, an initial reorganization with budget K0, then every month an intervention
with budget Km computed on the orders of the last `window` months. Km = K0 gives the 'from scratch every month' variant."""
import numpy as np
from dataclasses import dataclass
from .knowledge import build_knowledge

class Judge:
    """True distance: for every order the closed route depot -> positions -> depot
    (nearest neighbour + 2-opt) on the dataset matrix D."""
    def __init__(self, ds): self.ds = ds
    def tour(self, slots):
        slots = sorted(set(int(s) for s in slots)); n = len(slots) + 1
        if n == 1: return 0.0
        if n == 2: return 2.0 * float(self.ds.d_exit[slots[0]])
        Dl = np.zeros((n, n), dtype=np.float32)
        Dl[1:, 1:] = self.ds.D[np.ix_(slots, slots)]; Dl[0, 1:] = self.ds.d_exit[slots]; Dl[1:, 0] = self.ds.d_exit[slots]
        un = set(range(1, n)); tour = [0]; cur = 0
        while un:
            nxt = min(un, key=lambda j: Dl[cur, j]); tour.append(nxt); un.discard(nxt); cur = nxt
        improved = True
        while improved:
            improved = False
            for i in range(1, n - 1):
                for j in range(i + 1, n):
                    if j - i == 1: continue
                    A_, B_, C_ = tour[i - 1], tour[i], tour[j]; E_ = tour[(j + 1) % n]
                    if Dl[A_, C_] + Dl[B_, E_] + 1e-9 < Dl[A_, B_] + Dl[C_, E_]:
                        tour[i:j + 1] = tour[i:j + 1][::-1]; improved = True
        return float(Dl[tour[:-1], tour[1:]].sum() + Dl[tour[-1], tour[0]])
    def distance(self, pl, orders):
        return float(sum(self.tour(pl[o]) for o in orders["refs"]))
    def month_distance(self, pl, month):
        return self.distance(pl, self.ds.orders[self.ds.orders["month"] == month])

def move_cost(ds, moved_types, kappa=None, c0=None):
    """Labour cost of relocations: kappa * (c0 + bulk index) per relocated unit (c0 and kappa from the adapter unless given)."""
    kappa = ds.notes["kappa"] if kappa is None else kappa
    c0 = ds.notes.get("c0", 0.5) if c0 is None else c0
    return float(sum(kappa * (c0 + ds.footprint[p]) for p in moved_types))

@dataclass
class Protocol:
    warm: int = 3; K0: int = 90; Km: int = 10; window: int = 3; eval_months: list | None = None
    def months_eval(self, ds):
        m = ds.months; return self.eval_months if self.eval_months is not None else m[self.warm:]

def run_rolling(ds, opt_fn, proto, judge, kappa=None, verbose=False, log=None):
    """opt_fn(W, sp, pl_start, K) -> layout. Returns a dict with monthly distances, cost,
    number of relocations and the sequence of layouts (for the videos)."""
    months = ds.months; ev = proto.months_eval(ds); wi = months.index(ev[0])
    W, sp = build_knowledge(ds.orders[ds.orders["month"].isin(months[max(0, wi - proto.window):wi])], ds.P)
    pl_cur = opt_fn(W, sp, ds.pl_asis, proto.K0)
    moved = list(np.where(pl_cur != ds.pl_asis)[0]); cost = move_cost(ds, moved, kappa); n_moves = len(moved)
    dist, pls = [], [pl_cur.copy()]
    for i, m in enumerate(ev):
        if i > 0:
            mi = months.index(m); win = months[max(0, mi - proto.window):mi]
            W, sp = build_knowledge(ds.orders[ds.orders["month"].isin(win)], ds.P)
            pl_new = opt_fn(W, sp, pl_cur, proto.Km)
            mv = list(np.where(pl_new != pl_cur)[0]); cost += move_cost(ds, mv, kappa); n_moves += len(mv)
            pl_cur = pl_new; pls.append(pl_cur.copy())
        d = judge.month_distance(pl_cur, m); dist.append(d)
        if verbose: print(f"  {m}: distanza {d:,.0f}")
        if log is not None: log.append((m, d))
    return dict(dist=np.array(dist), cost=cost, n_moves=n_moves, placements=pls)

def summarize(ds, res, D_static, name=""):
    """Metrics of one protocol run. gross = share of distance saved w.r.t. never reorganizing; labor = relocation cost;
    net = distance saved minus labor (distance units); last_two_months = distance of the last two months;
    n_moves = relocations; net_hours_saved = net saving in hours of walking (time model of the dataset: measured for pharma, convention for footwear)."""
    td = res["dist"].sum(); gross = (D_static - td) / D_static; net = D_static - td - res["cost"]
    out = dict(name=name, gross=gross, labor=res["cost"], net=net, last_two_months=res["dist"][-2:].sum(), n_moves=res["n_moves"])
    s = ds.time_model["s_per_cell"]; out["net_hours_saved"] = (D_static - td - res["cost"]) * s / 3600   # same unit as net, in hours of walking
    return out
