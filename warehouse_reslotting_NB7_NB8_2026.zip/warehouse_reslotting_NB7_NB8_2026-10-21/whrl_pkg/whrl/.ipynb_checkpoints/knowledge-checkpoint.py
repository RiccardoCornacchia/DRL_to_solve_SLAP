"""From orders to knowledge: popularity (support) and dependencies W between product types.
W = ALPHA * confidence + (1 - ALPHA) * support, both normalized to [0, 1] and symmetrized. Pairs come from FP-Growth
(mlxtend) with max_len=2; without mlxtend the direct pair count is used, which for max_len=2 is exactly equivalent."""
import numpy as np
from collections import Counter

def build_counts(orders, P):
    """Raw co-picks between product types: C[i, j] = orders containing both i and j; c[i] = orders containing i.
    With the linear form (p=1), gamma=0 and beta=2, the environment computes the linear quadratic-assignment index
    (Koopmans-Beckmann) over product types, divided by max(c)."""
    C = np.zeros((P, P), np.float32); c = np.zeros(P, np.float64)
    for its in orders["refs"]:
        its = np.asarray(its); c[its] += 1; C[np.ix_(its, its)] += 1
    np.fill_diagonal(C, 0)
    return (C / c.max()).astype(np.float32), c

def build_W(orders, P, alpha=0.7, min_support=0.0005, min_conf=0.005, use_mlxtend=True, mode="fpgrowth"):
    if mode == "counts": return build_counts(orders, P)
    refs_lists = list(orders["refs"]); n = len(refs_lists)
    sp = np.zeros(P); cm = np.zeros((P, P)); sm = np.zeros((P, P))
    try:
        if not use_mlxtend: raise ImportError
        from mlxtend.preprocessing import TransactionEncoder
        from mlxtend.frequent_patterns import fpgrowth, association_rules
        import pandas as pd
        te = TransactionEncoder(); oh = pd.DataFrame(te.fit_transform(refs_lists), columns=te.columns_)
        fr = fpgrowth(oh, min_support=min_support, use_colnames=True, max_len=2)
        for _, r in fr[fr.itemsets.apply(len) == 1].iterrows(): sp[list(r.itemsets)[0]] = r.support
        ru = association_rules(fr, metric="confidence", min_threshold=min_conf)
        ru = ru[(ru.antecedents.apply(len) == 1) & (ru.consequents.apply(len) == 1)]
        for _, r in ru.iterrows():
            a = list(r.antecedents)[0]; b = list(r.consequents)[0]
            cm[a, b] = max(cm[a, b], r.confidence); sm[a, b] = max(sm[a, b], r.support)
    except ImportError:
        c1 = Counter(); c2 = Counter()
        for its in refs_lists:
            for a in its: c1[a] += 1
            for i in range(len(its)):
                for j in range(i + 1, len(its)): c2[(its[i], its[j])] += 1
        for a, v in c1.items(): sp[a] = v / n
        for (a, b), v in c2.items():
            s = v / n
            if s < min_support: continue
            ca, cb = v / c1[a], v / c1[b]
            if ca >= min_conf: cm[a, b] = ca; sm[a, b] = s
            if cb >= min_conf: cm[b, a] = cb; sm[b, a] = s
    n01 = lambda M: M / M.max() if M.max() > 0 else M
    W = alpha * n01(np.maximum(cm, cm.T)) + (1 - alpha) * n01(np.maximum(sm, sm.T))
    np.fill_diagonal(W, 0.0)
    return W.astype(np.float32), sp



# ---------------------------------------------------------------- choice of the score
# "rules_squared": the score of Notebooks 1-6 (W = 0.7 confidence + 0.3 support from FP-Growth, depot cross terms gamma = 0.3,
#             depot attraction beta = 5, sum of the SQUARES of the entries of M).
# "copicks_linear": the index of the QAP instance shipped with the pharmaceutical dataset, rewritten per product type:
#             raw co-picks, no cross terms, depot weight 2, LINEAR sum of the entries of M, i.e.
#             sum_{a<b} C_ab D_ab + sum_a n_a d_exit_a (up to a constant).
# "copicks_linear_b5": the candidate single score for both warehouses found by the sensitivity analysis:
#             raw co-picks, linear sum, depot weight 5 (same depot weight as rules_squared), no cross terms.
SURROGATES = {"rules_squared": dict(weights="rules", gamma=0.3, beta=5.0, p=2, alpha=0.7),
              "copicks_linear": dict(weights="copicks", gamma=0.0, beta=2.0, p=1, alpha=None),
              "copicks_linear_b5": dict(weights="copicks", gamma=0.0, beta=5.0, p=1, alpha=None)}
CURRENT = {"kind": "rules_squared"}

def register_surrogate(name, weights, gamma, beta, p, alpha=0.7):
    """Adds a variant of the score (weights = "rules" or "copicks")."""
    SURROGATES[name] = dict(weights=weights, gamma=gamma, beta=beta, p=p, alpha=alpha); return SURROGATES[name]

def set_surrogate(kind):
    """Selects the score used by RollEnv and build_knowledge: a name of SURROGATES."""
    from . import env
    CURRENT["kind"] = kind; env.SURROGATE_PARAMS.update({k: SURROGATES[kind][k] for k in ("gamma", "beta", "p")}); return SURROGATES[kind]

def current_surrogate(): return CURRENT["kind"], SURROGATES[CURRENT["kind"]]

def build_knowledge(orders, P, **kw):
    """Weights (W, sp) for the score currently selected with set_surrogate()."""
    cfg = SURROGATES[CURRENT["kind"]]
    if cfg["weights"] == "copicks": return build_counts(orders, P)
    kw.setdefault("alpha", cfg["alpha"]); return build_W(orders, P, **kw)
