"""Real picking sequences (pharmaceutical dataset, file liste_prelievo.csv): the route actually walked by the
operators versus the shortest route computed by the judge, and the savings of a new layout under two routing
assumptions."""
import csv, pandas as pd

def load_pick_lists(path):
    """order id -> (measured working time in seconds, product type codes in the chronological order of picking)."""
    out = {}
    with open(path) as f:
        r = csv.reader(f, delimiter=";"); next(r)
        for row in r:
            seq = [p for p in row[2:] if p]
            if seq: out[row[0]] = (float(row[1]), seq)
    return out

def _positions(seq, pl, t2i):
    ps = [int(pl[t2i[a]]) for a in seq if a in t2i]
    return [p for k, p in enumerate(ps) if k == 0 or p != ps[k - 1]]      # consecutive picks at the same position cost no walking

def walked_length(ds, seq, pl, t2i):
    """Length of the route that follows the given picking sequence: depot -> positions in that order -> depot."""
    ps = _positions(seq, pl, t2i)
    if not ps: return 0.0
    return float(ds.d_exit[ps[0]] + sum(ds.D[a, b] for a, b in zip(ps[:-1], ps[1:])) + ds.d_exit[ps[-1]])

def shortest_length(judge, seq, pl, t2i):
    """Length of the shortest route through the same positions (the judge)."""
    return judge.tour([int(pl[t2i[a]]) for a in set(seq) if a in t2i])

def route_study(ds, judge, lists):
    """One row per order: measured time, picks, walked length (real sequence), shortest length (judge)."""
    t2i = {t: i for i, t in enumerate(ds.types)}; rows = []
    for oid, (t, seq) in lists.items():
        rows.append(dict(order=oid, time_s=t, picks=len(seq), walked=walked_length(ds, seq, ds.pl_asis, t2i), shortest=shortest_length(judge, seq, ds.pl_asis, t2i)))
    df = pd.DataFrame(rows); return df[df.shortest > 0].reset_index(drop=True)

def savings_two_routings(ds, judge, lists, order_ids, pl_before, pl_after):
    """Relative saving of a new layout under two assumptions: the route is re-optimized for the new layout (the judge),
    or the operators keep picking the product types in the same order as before."""
    t2i = {t: i for i, t in enumerate(ds.types)}; sub = [lists[o][1] for o in order_ids if o in lists]
    S0 = sum(shortest_length(judge, s, pl_before, t2i) for s in sub); S1 = sum(shortest_length(judge, s, pl_after, t2i) for s in sub)
    R0 = sum(walked_length(ds, s, pl_before, t2i) for s in sub); R1 = sum(walked_length(ds, s, pl_after, t2i) for s in sub)
    return dict(orders=len(sub), saving_reoptimized_route=(S0 - S1) / S0, saving_same_sequence=(R0 - R1) / R0)
