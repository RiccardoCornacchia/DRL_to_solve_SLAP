"""Videos (MP4, ffmpeg) understandable without knowing the project: floor plan seen from above, shelves as tiles
coloured by how often their content is ordered, the depot, the picker's walk for one real order along the aisles,
the product type moved at each step, and counters with the real distance or walking time."""
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.animation import FFMpegWriter
from .env import RollEnv
from .greedy import candidates

def tour_order(judge, pl, order):
    slots = [int(pl[p]) for p in order]; uniq = sorted(set(slots)); n = len(uniq) + 1
    if n <= 2: return uniq
    Dl = np.zeros((n, n)); Dl[1:, 1:] = judge.ds.D[np.ix_(uniq, uniq)]; Dl[0, 1:] = judge.ds.d_exit[uniq]; Dl[1:, 0] = judge.ds.d_exit[uniq]
    un = set(range(1, n)); t = [0]; cur = 0
    while un:
        nxt = min(un, key=lambda j: Dl[cur, j]); t.append(nxt); un.discard(nxt); cur = nxt
    return [uniq[i - 1] for i in t[1:]]

def episode_trace(ds, W, sp, pl0, K, chooser, rng, n_moves):
    """Plays n_moves moves with chooser(env) -> product type; records (type, from, to, delta, F, layout)."""
    env = RollEnv(ds, W, sp, pl0, K).reset(); trace = []
    for _ in range(n_moves):
        a = chooser(env); cs = candidates(env, a, rng)
        if not cs: continue
        ds_ = [env.delta_put(a, s)[0] for s in cs]; ds_ = [(-1e18 if d is None else d) for d in ds_]
        s = cs[int(np.argmax(ds_))]; frm = int(env.pl[a]); d, ok = env.put(a, s)
        if ok: trace.append(dict(type=a, frm=frm, to=int(env.pl[a]), delta=d, F2=env.F2, pl=env.pl.copy(), moved=len(env.moved)))
    return trace

def depot_xy_of(ds):
    return ds.notes["depot"] if "depot" in ds.notes else ds.slot_xy[np.argmin(ds.d_exit)] - np.array([0, 3])


# ======================================================================================
# Two short simulation videos per dataset: large labels, no static scenes.
#   1) simulation: one reorganization played move by move by the trained network
#   2) learning:   the network at increasing training checkpoints, next to the greedy rule
# ======================================================================================
import os, pickle
from collections import deque
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import Rectangle, FancyBboxPatch
from matplotlib.collections import PatchCollection
SALES = LinearSegmentedColormap.from_list("sales", ["#f4ecdf", "#eab676", "#cc5a3d", "#6e1c14"])
SHELF_EMPTY, ROUTE_C, MOVE_C, PARTNER_C, TXT, MUTE = "#dcd8d1", "#1b6a8a", "#c0392b", "#7f8c8d", "#1c1c1c", "#6f6f6f"

class Floor:
    """Everything needed to draw the warehouse: one tile per position, the packing station, walking paths."""
    def __init__(self, ds, map_csv=None):
        import pandas as pd
        self.ds = ds; xy = ds.slot_xy.astype(float)
        self.base = xy
        if map_csv:                                   # pharma: all 1,430 positions of the floor plan (for obstacles and empty shelves)
            mp = pd.read_csv(map_csv, sep=";"); rc = [c for c in mp.columns if "riga" in c][0]; cc = [c for c in mp.columns if "colonna" in c][0]
            self.base = mp[[cc, rc]].to_numpy(float)
        ext = self.base.max(0) - self.base.min(0); self.rot = ext[1] > ext[0]
        def step(v):
            u = np.unique(np.round(v, 3)); d = np.diff(u); d = d[d > 1e-6]; return float(d.min()) if len(d) else 1.0
        self.sx, self.sy = step(self.base[:, 0]), step(self.base[:, 1])
        self.depot = np.array([55.0, 25.0]) if ds.name == "pharma" else np.asarray(ds.notes["depot"], float)
        if ds.name == "pharma": self._grid()
        else: self._aisles()
    def disp(self, pts):
        pts = np.atleast_2d(np.asarray(pts, float)); return pts[:, ::-1] if self.rot else pts
    # ---- footwear: racks run along x, aisles between rack columns, cross-aisles at the gaps in x
    def _aisles(self):
        xs = np.unique(np.round(self.base[:, 0], 3)); gaps = np.diff(xs); big = gaps > 1.5 * self.sx
        self.cross = np.r_[xs[0] - self.sx, (xs[:-1][big] + xs[1:][big]) / 2, xs[-1] + self.sx, self.depot[0]]
        self.yset = set(np.round(self.base[:, 1], 3))
    def _aisle_y(self, p):
        y = round(float(p[1]), 3); side = -1 if round(y + self.sy, 3) in self.yset else 1
        return p[1] + side * 0.6 * self.sy
    def _leg_fw(self, a, b):
        ya = a[1] if np.allclose(a, self.depot) else self._aisle_y(a); yb = b[1] if np.allclose(b, self.depot) else self._aisle_y(b)
        xc = self.cross[np.argmin(np.abs(a[0] - self.cross) + np.abs(self.cross - b[0]))]
        return [a, (a[0], ya), (xc, ya), (xc, yb), (b[0], yb), b]
    # ---- pharma: walk on the floor squares that are not shelves (breadth-first search on the 118 x 63 plan)
    def _grid(self):
        self.occ = set(map(tuple, self.base.astype(int))); self.W_, self.H_ = int(self.base[:, 0].max()) + 2, int(self.base[:, 1].max()) + 2
    def _free_nb(self, c):
        x, y = c
        return [(x + dx, y + dy) for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)) if 0 <= x + dx < self.W_ and 0 <= y + dy < self.H_ and (x + dx, y + dy) not in self.occ]
    def _leg_ph(self, a, b):
        a = tuple(int(v) for v in a); b = tuple(int(v) for v in b)
        src = [a] if a not in self.occ else self._free_nb(a); dst = set([b] if b not in self.occ else self._free_nb(b))
        if not src or not dst: return [a, b]
        prev = {s: None for s in src}; q = deque(src); end = None
        while q:
            c = q.popleft()
            if c in dst: end = c; break
            for n in self._free_nb(c):
                if n not in prev: prev[n] = c; q.append(n)
        if end is None: return [a, b]
        path = [end]
        while prev[path[-1]] is not None: path.append(prev[path[-1]])
        return [a] + path[::-1] + [b]
    def walk(self, stops):
        """Polyline (display coordinates) of the picker's walk: packing station -> stops -> packing station."""
        pts = [self.depot] + [self.ds.slot_xy[s] for s in stops] + [self.depot]; out = []
        leg = self._leg_ph if self.ds.name == "pharma" else self._leg_fw
        for a, b in zip(pts[:-1], pts[1:]): out += leg(np.asarray(a, float), np.asarray(b, float))
        return self.disp(np.array(out, float))

def _tile_values(ds, pl, pop):
    v = np.zeros(ds.L); np.add.at(v, pl, pop); return v

def _draw_floor(ax, fl, pl, pop, route=None, stops=None, move=None, partner=None, title=None, vmax=None):
    ax.clear(); ax.set_facecolor("white")
    val = _tile_values(fl.ds, pl, pop); vmax = vmax or max(np.quantile(val[val > 0], 0.97), 1e-9)
    w, h = (fl.sy, fl.sx) if fl.rot else (fl.sx, fl.sy)
    base = fl.disp(fl.base); rects = [Rectangle((x - 0.46 * w, y - 0.46 * h), 0.92 * w, 0.92 * h) for x, y in base]
    ax.add_collection(PatchCollection(rects, facecolor=SHELF_EMPTY, edgecolor="none", zorder=1))
    occ = np.where(val > 0)[0]; P = fl.disp(fl.ds.slot_xy[occ])
    cols = SALES(np.sqrt(np.clip(val[occ] / vmax, 0, 1)) * 0.92 + 0.08)
    ax.add_collection(PatchCollection([Rectangle((x - 0.46 * w, y - 0.46 * h), 0.92 * w, 0.92 * h) for x, y in P], facecolor=cols, edgecolor="none", zorder=2))
    if route is not None:
        ax.plot(route[:, 0], route[:, 1], color=ROUTE_C, lw=3.2, alpha=0.9, zorder=4, solid_capstyle="round", solid_joinstyle="round")
        S = fl.disp(fl.ds.slot_xy[stops]); ax.scatter(S[:, 0], S[:, 1], s=110, facecolor="white", edgecolor=ROUTE_C, lw=2.6, zorder=5)
    for arr, col, lw in ((move, MOVE_C, 3.6), (partner, PARTNER_C, 2.2)):
        if arr is None: continue
        p0, p1 = fl.disp(fl.ds.slot_xy[arr[0]])[0], fl.disp(fl.ds.slot_xy[arr[1]])[0]
        ax.annotate("", xy=p1, xytext=p0, arrowprops=dict(arrowstyle="-|>,head_width=0.6,head_length=1.0", color=col, lw=lw, connectionstyle="arc3,rad=0.25"), zorder=6)
        ax.add_patch(Rectangle((p1[0] - 0.9 * w, p1[1] - 0.9 * h), 1.8 * w, 1.8 * h, fill=False, edgecolor=col, lw=3, zorder=7))
    d = fl.disp(fl.depot)[0]
    ax.text(d[0], d[1], "PACKING", color="white", fontsize=11, fontweight="bold", ha="center", va="center", zorder=9,
            bbox=dict(boxstyle="round,pad=0.45", facecolor=TXT, edgecolor="none"))
    allp = np.vstack([base, fl.disp(fl.depot)]); pad = 4 * max(w, h)
    ax.set_xlim(allp[:, 0].min() - pad, allp[:, 0].max() + pad); ax.set_ylim(allp[:, 1].min() - pad, allp[:, 1].max() + pad)
    ax.set_aspect("equal"); ax.axis("off")
    if title: ax.set_title(title, fontsize=17, color=TXT, loc="left", fontweight="bold", pad=8)
    return vmax

def _legend(fig, x, y, fs=14, empty=True):
    ax = fig.add_axes([x, y, 0.30, 0.30]); ax.axis("off"); ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    for i, c in enumerate(np.linspace(0.1, 1, 6)): ax.add_patch(Rectangle((0.02 + 0.045 * i, 0.86), 0.04, 0.08, color=SALES(c)))
    ax.text(0.32, 0.90, "darker = ordered more often", fontsize=fs, va="center", color=TXT)
    k = 0.70
    if empty: ax.add_patch(Rectangle((0.02, k - 0.04), 0.04, 0.08, color=SHELF_EMPTY)); ax.text(0.32, k, "empty shelf position", fontsize=fs, va="center", color=TXT); k -= 0.18
    ax.add_patch(FancyBboxPatch((0.02, k - 0.04), 0.22, 0.08, boxstyle="round,pad=0.01", color=TXT)); ax.text(0.13, k, "PACKING", color="white", fontsize=9, ha="center", va="center", fontweight="bold")
    ax.text(0.32, k, "start and end of every walk", fontsize=fs, va="center", color=TXT); k -= 0.18
    ax.plot([0.02, 0.26], [k, k], color=ROUTE_C, lw=3.2); ax.text(0.32, k, "walk for one real order", fontsize=fs, va="center", color=TXT); k -= 0.18
    ax.annotate("", xy=(0.26, k), xytext=(0.02, k), arrowprops=dict(arrowstyle="-|>", color=MOVE_C, lw=3)); ax.text(0.32, k, "product moved by the AI", fontsize=fs, va="center", color=TXT)

def _stops(judge, pl, order): return tour_order(judge, pl, order)

def _fmt_dist(ds, u):
    if ds.time_model: return f"{u * ds.time_model['s_per_cell'] / 3600:,.1f} h of walking"
    return f"{u * ds.unit_m / 1000:,.1f} km"

def _leg_dist(ds, u):
    return f"{u * ds.unit_m:,.0f} m" if ds.unit_m else f"{u:,.0f} steps"

def _caption(ds, W, pop, prev, cur, a):
    moved = [p for p in np.where(prev != cur)[0] if p != a]; frm, to = int(prev[a]), int(cur[a])
    dd = float(ds.d_exit[to] - ds.d_exit[frm]); pct = 100 * pop[a]; top = pop[a] >= np.quantile(pop[pop > 0], 0.8)
    part = [q for q in np.argsort(-W[a])[:3] if W[a, q] > 0]
    near = lambda pl: np.mean([ds.D[pl[a], pl[q]] for q in part]) if part else np.nan
    closer = part and near(cur) < 0.85 * near(prev)
    if dd < 0 and top: s = f"A best seller (in {pct:.1f}% of orders) moves {_leg_dist(ds, -dd)} closer to the packing station"
    elif closer: s = f"A product (in {pct:.1f}% of orders) moves next to the products it is usually ordered with"
    elif dd > 0 and not top: s = f"A less popular product ({pct:.2f}% of orders) makes room near the packing station"
    else: s = f"A product (in {pct:.1f}% of orders) moves to a better spot"
    if moved: s += " (swap: grey arrow)"
    return s, (moved[0] if moved else None)

def video_simulation(ds, judge, fl, W, sp, pl0, K, chooser, pop, kpi_orders, pool, path, label, n_detail=24, stride=6, fps=10, seed=0):
    rng = np.random.default_rng(seed); trace = episode_trace(ds, W, sp, pl0, K, chooser, rng, K)
    final = trace[-1]["pl"] if trace else pl0
    cand = [list(r) for r in pool["refs"]]
    gain = [(judge.tour(pl0[o]) - judge.tour(final[o])) / max(judge.tour(pl0[o]), 1e-9) for o in cand]
    order = cand[int(np.argmax(gain))]; d_start = judge.distance(pl0, kpi_orders); o_start = judge.tour(pl0[order])
    fig = plt.figure(figsize=(16, 9), dpi=120); w = FFMpegWriter(fps=fps, bitrate=6000)
    frames = [(0, None, 2.5)] + [(i, trace[i - 1], 1.1) for i in range(1, min(n_detail, len(trace)) + 1)]
    frames += [(i, trace[i - 1], 0.5) for i in range(n_detail + stride, len(trace) + 1, stride)]
    if frames[-1][0] != len(trace): frames.append((len(trace), trace[-1], 0.5))
    frames.append((len(trace), trace[-1] if trace else None, 3.5))
    vmax = None
    with w.saving(fig, path, dpi=120):
        for n, (i, tr, hold) in enumerate(frames):
            fig.clf(); pl = pl0 if tr is None else tr["pl"]; prev = pl0 if i <= 1 else trace[i - 2]["pl"]
            ax = fig.add_axes([0.02, 0.13, 0.66, 0.72]); stops = _stops(judge, pl, order)
            cap, partner = ("Starting layout: the warehouse as it is today", None) if tr is None else _caption(ds, W, pop, prev, pl, tr["type"])
            if n == len(frames) - 1: cap = f"Done: {len(set(np.where(pl != pl0)[0]))} product types moved, all other shelves untouched"
            show_move = tr is not None and n != len(frames) - 1
            vmax = _draw_floor(ax, fl, pl, pop, fl.walk(stops), stops, (tr["frm"], tr["to"]) if show_move else None,
                               (int(prev[partner]), int(pl[partner])) if (show_move and partner is not None) else None, vmax=vmax)
            fig.text(0.02, 0.955, "An AI reorganizes a real warehouse, one product at a time", fontsize=26, fontweight="bold", color=TXT, va="top")
            fig.text(0.02, 0.895, f"{label}  ·  {ds.P:,} product types  ·  budget: {K} product types may change place", fontsize=15, color=MUTE, va="top")
            dk = judge.distance(pl, kpi_orders); oo = judge.tour(pl[order])
            fig.text(0.70, 0.80, "PRODUCTS MOVED", fontsize=14, color=MUTE); fig.text(0.70, 0.735, f"{len(set(np.where(pl != pl0)[0]))} / {K}", fontsize=34, fontweight="bold", color=TXT)
            fig.text(0.70, 0.66, f"WALKING FOR {len(kpi_orders)} REAL ORDERS", fontsize=14, color=MUTE); fig.text(0.70, 0.595, _fmt_dist(ds, dk), fontsize=34, fontweight="bold", color=TXT)
            fig.text(0.70, 0.555, f"{100 * (dk - d_start) / d_start:+.1f}% compared with today", fontsize=15, color=MOVE_C if dk < d_start else MUTE)
            _legend(fig, 0.70, 0.12, fs=13, empty=True)
            fig.text(0.02, 0.075, cap, fontsize=19, color=TXT, va="top")
            fig.text(0.02, 0.035, f"Highlighted order ({len(order)} products): walk {_leg_dist(ds, o_start)} → {_leg_dist(ds, oo)}", fontsize=16, color=ROUTE_C, va="top")
            for _ in range(max(1, int(hold * fps))): w.grab_frame()
    plt.close(fig); return order

def learning_checkpoints(ds, judge, policy, trainer, W, sp, pl0, K, sample_orders, n_ckpts, iters_per_ckpt, cache_path, rng, legacy=None, B=8, T=60):
    """Checkpoints of a training run: layout produced, distance on sample orders, training reward. Resumable."""
    import torch
    from .policy import policy_reorganize, play
    ck = pickle.load(open(cache_path, "rb")) if os.path.exists(cache_path) else (pickle.load(open(legacy, "rb")) if legacy and os.path.exists(legacy) else [])
    if ck: policy.load_state_dict(ck[-1]["state"])
    F0 = RollEnv(ds, W, sp, pl0, K).reset().F2; mov = np.where(ds.movable)[0]
    def reward_of(state):
        pol = type(policy)(); pol.load_state_dict(state); envs = [RollEnv(ds, W, sp, pl0, K).reset() for _ in range(B)]
        _, r = play(pol, envs, sp, mov, T, np.random.default_rng(11)); return float(100 * r.sum(1).mean() / F0)
    for c in ck:
        if "reward" not in c: c["reward"] = reward_of(c["state"]); pickle.dump(ck, open(cache_path, "wb"))
    while len(ck) < n_ckpts + 1:
        if ck: trainer(iters_per_ckpt)
        pl = policy_reorganize(policy, ds, W, sp, pl0, K, n_games=3, rng=rng); st = {k: v.clone() for k, v in policy.state_dict().items()}
        ck.append(dict(it=len(ck) * iters_per_ckpt, pl=pl, d=judge.distance(pl, sample_orders), state=st, reward=reward_of(st)))
        pickle.dump(ck, open(cache_path, "wb"))
    return ck

def video_learning(ds, judge, fl, pl0, pl_greedy, ckpts, sample_orders, order, pop, path, label, K, B=8, fps=10, hold=1.6):
    d0, dg = judge.distance(pl0, sample_orders), judge.distance(pl_greedy, sample_orders)
    games = [c["it"] * B for c in ckpts]; fig = plt.figure(figsize=(16, 9), dpi=120); w = FFMpegWriter(fps=fps, bitrate=6000); vmax = None
    with w.saving(fig, path, dpi=120):
        for j, c in enumerate(ckpts):
            fig.clf()
            fig.text(0.02, 0.965, "The AI learns which products are worth moving", fontsize=26, fontweight="bold", color=TXT, va="top")
            fig.text(0.02, 0.91, f"{label}  ·  same orders, same budget ({K} product types) for both", fontsize=15, color=MUTE, va="top")
            fig.text(0.02, 0.868, "Greedy: a fixed rule that always moves the product that looks worst placed right now.   AI: a neural network that learns by trial and error which products to move.", fontsize=13, color=MUTE, va="top")
            axg = fig.add_axes([0.01, 0.44, 0.48, 0.36]); axn = fig.add_axes([0.51, 0.44, 0.48, 0.36])
            sg, sn = _stops(judge, pl_greedy, order), _stops(judge, c["pl"], order)
            vmax = _draw_floor(axg, fl, pl_greedy, pop, fl.walk(sg), sg, title="Hand-written rule (greedy)", vmax=vmax)
            _draw_floor(axn, fl, c["pl"], pop, fl.walk(sn), sn, title=f"AI after {games[j]:,} practice games", vmax=vmax)
            fig.text(0.02, 0.405, f"Walking for {len(sample_orders)} real orders: {_fmt_dist(ds, dg)}", fontsize=17, color=TXT, fontweight="bold")
            fig.text(0.52, 0.405, f"Walking for {len(sample_orders)} real orders: {_fmt_dist(ds, c['d'])}", fontsize=17, color=MOVE_C if c["d"] < dg else TXT, fontweight="bold")
            a1 = fig.add_axes([0.06, 0.08, 0.40, 0.25]); a2 = fig.add_axes([0.56, 0.08, 0.40, 0.25])
            a1.plot(games[:j + 1], [k["reward"] for k in ckpts[:j + 1]], color=MOVE_C, lw=3, marker="o", ms=6)
            a1.set_xlim(0, max(games[-1], 1)); lo, hi = min(k["reward"] for k in ckpts), max(k["reward"] for k in ckpts); a1.set_ylim(lo - 0.1 * (hi - lo + 1e-9), hi + 0.1 * (hi - lo + 1e-9))
            a1.set_title("Training reward: how much each practice game improves the layout (%)", fontsize=14, loc="left", color=TXT)
            a2.plot(games[:j + 1], [_fmt_num(ds, k["d"]) for k in ckpts[:j + 1]], color=MOVE_C, lw=3, marker="o", ms=6, label="AI")
            a2.axhline(_fmt_num(ds, dg), color=TXT, lw=2, ls="--", label="hand-written rule"); a2.axhline(_fmt_num(ds, d0), color=MUTE, lw=2, ls=":", label="no reorganization")
            a2.set_xlim(0, max(games[-1], 1)); a2.set_title(f"Walking for {len(sample_orders)} real orders ({_unit(ds)}, lower is better)", fontsize=14, loc="left", color=TXT)
            a2.legend(frameon=False, fontsize=12, loc="upper right")
            for a in (a1, a2):
                a.tick_params(labelsize=12); a.set_xlabel("practice games played by the AI", fontsize=13)
                for s_ in ("top", "right"): a.spines[s_].set_visible(False)
            for _ in range(int((3.0 if j == len(ckpts) - 1 else hold) * fps)): w.grab_frame()
    plt.close(fig)

def _unit(ds): return "hours" if ds.time_model else "km"
def _fmt_num(ds, u): return u * ds.time_model["s_per_cell"] / 3600 if ds.time_model else u * ds.unit_m / 1000
