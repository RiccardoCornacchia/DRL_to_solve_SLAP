"""Choice of the budget K without prohibitive cost.
  brute_force_curve : net(K) for every K of a list (the exact, expensive reference);
  golden_section    : maximum of a unimodal function with O(log n) evaluations;
  bisection_marginal: bisection on the sign of the marginal gain net(K + delta) - net(K), O(log n);
  threshold_estimator: estimate WITHOUT reorganizations: counts the product types whose best single move is worth
                       more than its relocation cost (marginal gain > marginal cost)."""
import numpy as np, time, math
from .env import RollEnv
from .greedy import candidates

def brute_force_curve(eval_net, Ks):
    """eval_net(K) -> net. Returns (Ks, nets, seconds)."""
    t0 = time.time(); vals = [eval_net(int(k)) for k in Ks]; return np.array(Ks), np.array(vals), time.time() - t0

def memoized(eval_net, memo):
    def f(k):
        k = int(k)
        if k not in memo:
            memo[k] = eval_net(k)
        return memo[k]
    return f

def golden_section(eval_net, lo, hi, tol=4, memo=None):
    memo = {} if memo is None else memo
    f = memoized(eval_net, memo)
    g = (math.sqrt(5) - 1) / 2
    a, b = lo, hi; c = round(b - g * (b - a)); d = round(a + g * (b - a))
    while b - a > tol:
        if f(c) >= f(d): b, d = d, c; c = round(b - g * (b - a))
        else: a, c = c, d; d = round(a + g * (b - a))
    best = max(memo, key=memo.get)
    return best, memo

def bisection_marginal(eval_net, lo, hi, delta=5, memo=None):
    memo = {} if memo is None else memo
    f = memoized(eval_net, memo)
    while hi - lo > delta:
        mid = (lo + hi) // 2
        if f(mid + delta) > f(mid): lo = mid
        else: hi = mid
    best = max(memo, key=memo.get)
    return best, memo

def threshold_estimator(ds, W, sp, pl_start, kappa=None, c0=None, rng=None, scale=None):
    """For every movable product type: best improvement of F with a single move (verifier, O(c n) per type).
    The improvement is converted into distance units with 'scale' (units per point of F), estimated by the caller on
    a pilot reorganization; then the product types with gain > cost are counted. Cost: O(c n^2) + sort."""
    rng = rng or np.random.default_rng(0); kappa = ds.notes["kappa"] if kappa is None else kappa; c0 = ds.notes.get("c0", 0.5) if c0 is None else c0
    env = RollEnv(ds, W, sp, pl_start, 10 ** 9).reset(); mov = np.where(ds.movable)[0]
    gains = np.zeros(len(mov))
    for i, a in enumerate(mov):
        cs = candidates(env, a, rng); ds_ = [env.delta_put(a, s)[0] for s in cs]
        gains[i] = max([d for d in ds_ if d is not None] + [0.0])
    costs = np.array([kappa * (c0 + ds.footprint[a]) for a in mov])
    if scale is None: scale = 1.0
    order = np.argsort(-gains); K_hat = int((gains[order] * scale > costs[order]).sum())
    return K_hat, gains, costs
