"""Full-scale statistical protocol (the one of Notebook 6, section 10.8) as reusable functions.

1. Validation separate from test (temporal split). The evaluation months are split into a validation period (the first
   n_val months, used ONLY to choose the checkpoint and to stop early) and a test period (the remaining months, used
   only for the reported numbers, computed once with the chosen checkpoint).
2. Early stopping and selection on validation. Training proceeds by checkpoints; at each checkpoint the net saving of
   the validation period is measured; training stops when it has not improved for `patience` consecutive checkpoints;
   the reported network is the checkpoint with the best validation net saving.
3. Multiple seeds. Every configuration is trained and evaluated with several seeds (network initialization, sampling of
   the training instances, moves of the games, search of the greedy).
4. Paired statistical tests. For every seed and test month the monthly net saving is recorded; the pairs
   (configuration, greedy) with the same seed and month feed a paired t-test and a Wilcoxon signed-rank test.

Cost attribution: the initial reorganization and the retouches of the validation months are charged to the validation
period; the test period is charged only with the retouches of its own months.
Training instances are built only from the months BEFORE the first evaluation month, so validation and test stay clean.
Every unit of work (configuration, seed) is cached in its own file: runs resume after an interruption, and seeds can be
split across machines by copying the cache folder.
"""
import os, pickle, time
import numpy as np, pandas as pd
from .env import RollEnv
from .knowledge import build_knowledge
from .rolling import move_cost
from .greedy import optimize
from .stats import paired_tests


# ------------------------------------------------------------------ protocol over time, split into validation and test
def rolling_months(ds, judge, opt_fn, eval_months, K0, Km, window=3, upto=None):
    """Incremental protocol over eval_months: budget K0 at the start, Km every following month, knowledge built from the
    orders of the last `window` months. Returns one (distance, relocation cost) pair per month; the cost of the
    initial reorganization is charged to the first month. upto=n stops after the first n months."""
    months = list(ds.months); o = ds.orders; n = upto or len(eval_months)
    def knowledge_before(m):
        j = months.index(m); return build_knowledge(o[o.month.isin(months[max(0, j - window):j])], ds.P)
    W, sp = knowledge_before(eval_months[0]); pl = opt_fn(W, sp, ds.pl_asis, K0)
    cost0 = move_cost(ds, np.where(pl != ds.pl_asis)[0]); out = []
    for i, m in enumerate(eval_months[:n]):
        c = cost0 if i == 0 else 0.0
        if i > 0:
            W, sp = knowledge_before(m); new = opt_fn(W, sp, pl, Km); c += move_cost(ds, np.where(new != pl)[0]); pl = new
        out.append((judge.month_distance(pl, m), c))
    return out

class Split:
    """Temporal split of the evaluation months (first n_val = validation, rest = test) and monthly distances of the
    current layout, which are the reference for every net saving."""
    def __init__(self, ds, judge, eval_months, n_val=3):
        self.eval = list(eval_months); self.val, self.test = self.eval[:n_val], self.eval[n_val:]
        self.static = {m: judge.month_distance(ds.pl_asis, m) for m in self.eval}

def net_validation(ds, judge, split, opt_fn, K0, Km, window=3):
    """Net saving of the validation period (protocol stopped at the end of the validation months)."""
    rows = rolling_months(ds, judge, opt_fn, split.eval, K0, Km, window, upto=len(split.val))
    return float(sum(split.static[m] - d - c for m, (d, c) in zip(split.val, rows)))

def test_report(ds, judge, split, opt_fn, K0, Km, window=3):
    """Full protocol over all evaluation months; returns (test net saving, monthly net savings of the test months)."""
    rows = rolling_months(ds, judge, opt_fn, split.eval, K0, Km, window)
    per = np.array([split.static[m] - d - c for m, (d, c) in zip(split.test, rows[len(split.val):])])
    return float(per.sum()), per


# ------------------------------------------------------------------ optimizers with the signature (W, sp, start, K) -> layout
def greedy_steps(K, base):
    """Steps of the greedy: at least `base`, and at least 3 per unit of budget, so that a large budget can be used."""
    return int(max(base, 3 * K))

def greedy_opt(ds, K0, steps_initial=1500, steps_monthly=1000, seed=0, moves="general"):
    # a fresh random stream from the same seed at every call: the result depends only on the inputs, not on the call order
    return lambda W, sp, pl0, K: optimize(RollEnv(ds, W, sp, pl0, K, moves=moves), steps=greedy_steps(K, steps_initial if K >= K0 else steps_monthly), rng=np.random.default_rng(seed))

def network_opt(policy, ds, n_games=6, seed=0):
    from .policy import policy_reorganize                      # imported here: the greedy path works without PyTorch
    return lambda W, sp, pl0, K: policy_reorganize(policy, ds, W, sp, pl0, K, n_games=n_games, rng=np.random.default_rng(seed))   # same rule as the greedy


# ------------------------------------------------------------------ training instances
def instance_pool(ds, train_months, kind, n=30, window_days=7, seed=0):
    """Pool of training instances (W, sp) built only from train_months (the months before the evaluation period).
    kind = "static" (one instance from all training months), "monthly" (one per month),
    "weekly_bootstrap" (n windows of window_days days, each with its orders resampled with replacement)."""
    o = ds.orders[ds.orders.month.isin(train_months)]
    if kind == "static": return [build_knowledge(o, ds.P)]
    if kind == "monthly": return [build_knowledge(o[o.month == m], ds.P) for m in train_months]
    if kind == "weekly_bootstrap":
        rng = np.random.default_rng(seed); d0, d1 = o["date"].min(), o["date"].max(); span = (d1 - d0) - pd.Timedelta(days=window_days); pool = []
        for _ in range(n):
            start = d0 + span * float(rng.random()); w = o[(o["date"] >= start) & (o["date"] < start + pd.Timedelta(days=window_days))]
            pool.append(build_knowledge(w.sample(len(w), replace=True, random_state=int(rng.integers(1 << 30))), ds.P))
        return pool
    raise ValueError(kind)

def make_sampler(pool, starts, K0, Km):
    """sampler(rng) for make_trainer: half of the games in the regime of the initial reorganization (starting from
    starts[0], the current layout), half in the monthly regime (starting from one of the other archived layouts)."""
    def sampler(rng):
        W, sp = pool[int(rng.integers(len(pool)))]
        if rng.random() < 0.5 or len(starts) == 1: return W, sp, starts[0], K0
        return W, sp, starts[int(rng.integers(1, len(starts)))], Km
    return sampler


# ------------------------------------------------------------------ training with selection on validation
def train_select(ds, judge, split, sampler, seed, K0, Km, checkpoints, patience=2, cache_path=None, B=8, T=60, n_games=6, log=print, chunk_mb=512):
    """Trains a network with checkpoints, early stopping and selection on the VALIDATION net saving (never on the test).
    Resumable: after every checkpoint the full state (weights, optimizer, best checkpoint, validation curve) is saved
    to cache_path. Returns (best network, state)."""
    import torch
    from .policy import ProductPolicy, make_trainer
    torch.manual_seed(seed)
    pol = ProductPolicy(); tr = make_trainer(pol, ds, sampler, B=B, T=T, seed=seed, T_by_regime={K0: 2 * K0, Km: max(1, 2 * Km)}, chunk_mb=chunk_mb)   # training games: 2 moves per unit of budget, no fixed cap
    st = dict(done=0, best_net=-np.inf, best_state=None, best_ck=0, bad=0, curve=[], stopped=False)
    if cache_path and os.path.exists(cache_path):
        try: st = torch.load(cache_path, weights_only=False)                 # PyTorch >= 1.13
        except TypeError: st = torch.load(cache_path)                         # older PyTorch
        pol.load_state_dict(st["state"]); tr.opt.load_state_dict(st["opt"])
    for ck in checkpoints:
        if st["stopped"]: break
        if ck <= st["done"]: continue
        t0 = time.time(); tr(ck - st["done"]); st["done"] = ck
        nv = net_validation(ds, judge, split, network_opt(pol, ds, n_games, seed), K0, Km)
        st["curve"].append((ck, nv))
        if nv > st["best_net"]: st.update(best_net=nv, best_state={k: v.clone() for k, v in pol.state_dict().items()}, best_ck=ck, bad=0)
        else: st["bad"] += 1
        st["stopped"] = st["bad"] >= patience; st["state"], st["opt"] = pol.state_dict(), tr.opt.state_dict()
        if cache_path: torch.save(st, cache_path)
        log(f"  seed {seed} | checkpoint {ck} | validation net {nv:+,.0f} | best {st['best_net']:+,.0f} at {st['best_ck']} | {time.time() - t0:.0f}s" + (" | early stop" if st["stopped"] else ""))
    best = ProductPolicy(); best.load_state_dict(st["best_state"]); return best, st


# ------------------------------------------------------------------ units of work and final table
def run_unit(cache_dir, config, seed, fn):
    """One unit of work (configuration, seed) cached in its own file; fn() -> dict(test=..., months=..., ckpt=...)."""
    os.makedirs(cache_dir, exist_ok=True); f = f"{cache_dir}/{config.replace(' ', '_')}__seed{seed}.pkl"
    if os.path.exists(f): return pickle.load(open(f, "rb"))
    r = fn(); pickle.dump(r, open(f, "wb")); return r

def summary(results, configs, seeds, baseline="greedy"):
    """Per configuration: mean and standard deviation over seeds of the test net saving, chosen checkpoints, and the
    paired tests against the baseline on the monthly test net savings (pairs with the same seed and month)."""
    base = np.concatenate([results[(baseline, s)]["months"] for s in seeds]); rows = []
    for c in configs:
        v = [results[(c, s)]["test"] for s in seeds]
        row = dict(configuration=c, test_net_mean=float(np.mean(v)), test_net_std=float(np.std(v)), checkpoints=[results[(c, s)].get("ckpt") for s in seeds])
        if c != baseline:
            pt = paired_tests(np.concatenate([results[(c, s)]["months"] for s in seeds]), base)
            row.update(mean_monthly_difference=pt["mean_diff"], t=pt["t"], p_t=pt["p_t"], p_wilcoxon=pt["p_w"])
        rows.append(row)
    return pd.DataFrame(rows).set_index("configuration")


# ------------------------------------------------------------------ budgets chosen on the validation months, protocols compared
def monthly_distances(ds, judge, pl, months):
    return np.array([judge.month_distance(pl, m) for m in months])

def initial_curve(ds, judge, opt_fn, months, Ks, window=3, cache=None):
    """One initial reorganization (from the current layout, knowledge from the `window` months before months[0]) for every
    budget in Ks. Returns {K: (monthly distances over `months`, relocation cost)}: the net over any horizon h is
    sum(static[:h]) - sum(dist[:h]) - cost. cache: dict reused across calls."""
    ms = list(ds.months); j = ms.index(months[0]); W, sp = build_knowledge(ds.orders[ds.orders.month.isin(ms[max(0, j - window):j])], ds.P)
    out = {} if cache is None else cache
    for K in Ks:
        K = int(K)
        if K in out: continue
        pl = ds.pl_asis.copy() if K == 0 else opt_fn(W, sp, ds.pl_asis, K)
        out[K] = (monthly_distances(ds, judge, pl, months), move_cost(ds, np.where(pl != ds.pl_asis)[0]), pl)
    return out

def net_from_curve(curve, static, K, h):
    d, c, _ = curve[int(K)]; return float(static[:h].sum() - d[:h].sum() - c)

def retouch_curve(ds, judge, opt_fn, pl_after, month, Ks, window=3, cache=None):
    """Value of a monthly retouch: start from pl_after (the layout after the initial reorganization), knowledge from the
    `window` months before `month`, and for every retouch budget the net saving on `month`:
    distance(pl_after, month) - distance(new layout, month) - relocation cost. 0 is always among the options."""
    ms = list(ds.months); j = ms.index(month); W, sp = build_knowledge(ds.orders[ds.orders.month.isin(ms[max(0, j - window):j])], ds.P)
    base = judge.month_distance(pl_after, month); out = {} if cache is None else cache
    for K in Ks:
        K = int(K)
        if K in out: continue
        if K == 0: out[K] = 0.0; continue
        pl = opt_fn(W, sp, pl_after, K); out[K] = float(base - judge.month_distance(pl, month) - move_cost(ds, np.where(pl != pl_after)[0]))
    return out

def choose_budgets(ds, judge, opt_fn, split, technique="golden", tol_frac=0.02, log=print):
    """The budget choice of the method, ONLY on the validation months, with a cheap search instead of trying every budget.
    technique: "golden" (golden-section search on the net curve, assumes one maximum; about 8-10 evaluations from 0 to P)
    or "bisection" (on the sign of the marginal gain net(K + delta) - net(K)). tol_frac: the search stops when the interval
    is narrower than tol_frac x P (and delta = tol_frac x P for the bisection).
    K0: the search on [0, P] of the net of one initial reorganization over the validation months. Km, after K0: the
    search on [0, P/2] of the net of one retouch on the second validation month, starting from the layout after K0;
    a retouch that does not pay (no positive net found) gives Km = 0.
    Returns a dict with K0, Km, every budget evaluated with its net (memo0, memom), the curve cache and the layout after K0."""
    from .budget import golden_section, bisection_marginal
    val = split.val; static = np.array([split.static[m] for m in val]); P = ds.P; tol = max(1, int(round(tol_frac * P)))
    search = (lambda f, lo, hi: golden_section(f, lo, hi, tol=tol)) if technique == "golden" else (lambda f, lo, hi: bisection_marginal(f, lo, hi, delta=tol))
    curve0 = {}
    def f0(K):
        K = int(K); initial_curve(ds, judge, opt_fn, val, [K], cache=curve0); return net_from_curve(curve0, static, K, len(val))
    K0, memo0 = search(f0, 0, P); K0 = int(K0)
    pl_after = curve0[K0][2]
    curve_m = {}
    def fm(K):
        K = int(K); return retouch_curve(ds, judge, opt_fn, pl_after, val[1], [K], cache=curve_m)[K]
    Km, memom = search(fm, 0, P // 2); Km = int(Km) if memom[int(Km)] > 0 else 0
    log(f"budgets chosen on validation {[str(m) for m in val]} with the {technique} search: K0 = {K0} ({len(memo0)} reorganizations evaluated) | Km = {Km} ({len(memom)} retouches evaluated)")
    return dict(K0=K0, Km=Km, curve0=curve0, memo0={int(k): float(v) for k, v in memo0.items()}, curve_m=curve_m, memom={int(k): float(v) for k, v in memom.items()}, pl_after=pl_after)

def protocol_rows(ds, judge, split, rows):
    """rows: [(distance, cost)] per evaluation month -> dict with gross, net, labour and net hours over the TEST months,
    plus the monthly nets (for the paired tests)."""
    test = split.test; n_val = len(split.val); st = np.array([split.static[m] for m in test])
    d = np.array([r[0] for r in rows[n_val:]]); c = np.array([r[1] for r in rows[n_val:]])
    net_m = st - d - c
    return dict(gross=float((st.sum() - d.sum()) / st.sum()), labour=float(c.sum()), net=float(net_m.sum()), net_hours=ds.hours(net_m.sum()), months=net_m,
                n_moves=None)

def compare_protocols(ds, judge, opt_factory, split, K0, Km, window=3):
    """Three protocols with the same optimizer and the same budgets: single-shot (K0 once, never again), hybrid
    (K0 then Km every month) and from scratch (no budget, every month). opt_factory() returns a fresh optimizer
    (same seed) for every protocol, so that the three runs share the same random stream. Costs of the validation
    months are not charged to the test months. Returns {name: protocol_rows(...)} and the raw monthly rows."""
    P = ds.P; out, raw = {}, {}
    for name, k0, km in (("single-shot", K0, 0), ("hybrid", K0, Km), ("from scratch", P, P)):
        rows = rolling_months(ds, judge, opt_factory(), split.eval, k0, km, window); raw[name] = rows; out[name] = protocol_rows(ds, judge, split, rows)
    return out, raw


# ------------------------------------------------------------------ synthetic training instances
def synthetic_orders(ds, train_months, n_orders, seed=0, mix=0.7):
    """Orders generated from a model fitted on train_months: order size from the empirical distribution, first product
    type drawn by popularity, each next one drawn (with probability `mix`) from the co-pick profile of the previous one,
    otherwise by popularity, without repeats. Returns a DataFrame with the columns of ds.orders."""
    rng = np.random.default_rng(seed); o = ds.orders[ds.orders.month.isin(train_months)]
    sizes = o["refs"].str.len().to_numpy(); pop = np.bincount(np.concatenate(list(o["refs"])), minlength=ds.P).astype(float) + 1e-9; pop /= pop.sum()
    C = np.zeros((ds.P, ds.P), np.float32)
    for its in o["refs"]:
        its = np.asarray(its); C[np.ix_(its, its)] += 1
    np.fill_diagonal(C, 0); rows = []
    for i in range(n_orders):
        s = int(rng.choice(sizes)); cur = int(rng.choice(ds.P, p=pop)); items = [cur]
        while len(items) < s:
            prof = C[cur].copy(); prof[items] = 0
            if rng.random() < mix and prof.sum() > 0: nxt = int(rng.choice(ds.P, p=prof / prof.sum()))
            else:
                q = pop.copy(); q[items] = 0; nxt = int(rng.choice(ds.P, p=q / q.sum()))
            items.append(nxt); cur = nxt
        rows.append(dict(id=f"syn{seed}_{i}", date=pd.NaT, refs=sorted(items), month=None))
    return pd.DataFrame(rows)

def _pool_synthetic(ds, train_months, n, seed):
    n_orders = int(len(ds.orders[ds.orders.month.isin(train_months)]) / max(1, len(train_months)))
    return [build_knowledge(synthetic_orders(ds, train_months, n_orders, seed=seed * 1000 + i), ds.P) for i in range(n)]

_old_instance_pool = instance_pool
def instance_pool(ds, train_months, kind, n=30, window_days=7, seed=0):
    """Pool of training instances (W, sp) built only from train_months (the months before the evaluation period).
    kind = "static" (one instance from all training months), "monthly" (one per month), "weekly_bootstrap" (n windows
    of window_days days, orders resampled with replacement) or "synthetic" (n sets of generated orders, see
    synthetic_orders)."""
    if kind == "synthetic": return _pool_synthetic(ds, train_months, n, seed)
    return _old_instance_pool(ds, train_months, kind, n=n, window_days=window_days, seed=seed)
