"""whrl: Warehouse Re-slotting with RL. The METHOD lives here and does not depend on the dataset:
data.py (adapters) -> knowledge.py (score weights) -> env.py (state, moves, incremental score) ->
greedy.py / policy.py (who to move) -> rolling.py (protocol over time, judge, metrics) -> budget.py (budget choice)
-> fullscale.py (budgets on validation, protocols, full-scale statistical protocol) -> analysis.py (shared descriptive analyses)
-> routes.py (real picking sequences) -> video.py (videos) -> stats.py (statistical tests)."""
from .data import load_dataset, DATASETS, Dataset
from .knowledge import build_W, build_counts, build_knowledge, set_surrogate, SURROGATES
from .env import RollEnv
from .greedy import optimize, candidates
from .rolling import Judge, run_rolling, Protocol
from .budget import brute_force_curve, golden_section, bisection_marginal, threshold_estimator
from .stats import paired_tests
from .analysis import demand_stability, layout_profile, size_summary
