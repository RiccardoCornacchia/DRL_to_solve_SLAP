"""Extra files of the footwear dataset: the navigation points (distances along the real aisles) and the layouts of the
four static storage policies studied by the dataset authors (Random, Class-based, Dedicated, Hybrid)."""
import csv, io, numpy as np, pandas as pd

def load_navigation(path):
    """label -> (x, y) of the 44 navigation points (file Support_Points_Navigation.csv, rows separated by carriage returns).
    LC-*, CC-* and RC-* are the points of the left, central and right main corridors (x = 66, 403, 686); the y values are
    the cross aisles; CC-01 at (403, -29) is the depot."""
    rows = [r for r in open(f"{path}/Support_Points_Navigation.csv").read().replace("\r", "\n").split("\n")[1:] if r.strip()]
    return {r.split(";")[1].strip(): tuple(float(v) for v in r.split(";")[0].strip("()").split(",")[:2]) for r in rows}

def aisle_distances(slots_xy, depot, nav):
    """Walking distance along the aisles. Every position is served by its nearest cross aisle (a y value of the
    navigation points); the picker stops in the aisle in front of the position. Between two positions on the same aisle
    the distance is the difference in x; otherwise the picker walks along the aisle to a main corridor, along the
    corridor to the other aisle, and along that aisle to the other position. A corridor can be used only where it
    exists (the right corridor only for y >= 631). Returns (D, d_exit)."""
    corr = {}
    for lab, (x, y) in nav.items(): corr.setdefault(lab[:2], {"x": x, "ys": set()})["ys"].add(y)
    ys = np.array(sorted({y for _, y in nav.values()}))
    pts = np.vstack([np.asarray(slots_xy, float), np.asarray(depot, float)[None]])
    ax, ay = pts[:, 0], ys[np.abs(pts[:, 1][:, None] - ys[None]).argmin(1)]        # stop point: (x, y of the nearest aisle)
    n = len(pts); D = np.full((n, n), np.inf)
    same = ay[:, None] == ay[None]
    D[same] = np.abs(ax[:, None] - ax[None])[same]
    for c in corr.values():
        ok = np.isin(ay, list(c["ys"]))                                              # the corridor reaches this aisle
        via = np.abs(ax - c["x"])[:, None] + np.abs(ay[:, None] - ay[None]) + np.abs(ax - c["x"])[None]
        m = ok[:, None] & ok[None] & ~same
        D[m] = np.minimum(D[m], via[m])
    D = D.astype(np.float32)
    return D[:-1, :-1], D[-1, :-1]

def load_static_policies(path, ds):
    """name -> layout (position of every product type) for each static policy of the dataset authors.
    Each file lists, for every location code, up to 18 stored boxes as 'product type;size'. A product type is placed
    at the position (point of the floor plan) holding most of its boxes; ties go to the position closer to the depot;
    conflicts are resolved as for the current layout (the most picked product type keeps the position, the other goes to
    the nearest free position); product types absent from the file keep their current position if free."""
    loc = pd.read_csv(f"{path}/Storage_Location.csv"); loc["originalLocation"] = loc["originalLocation"].str.strip()
    xy = np.asarray(ds.slot_xy, float)
    code2slot = {r.originalLocation: int(np.abs(xy - [r.x, r.y]).sum(1).argmin()) for r in loc.itertuples()}
    t2i = {t: i for i, t in enumerate(ds.types)}; picks = np.bincount(np.concatenate(list(ds.orders["refs"])), minlength=ds.P)
    out = {}
    for name, fn in [("Random", "Random_Storage.csv"), ("Class-based", "Class_Based_Storage.csv"), ("Dedicated", "Dedicated_Storage.csv"), ("Hybrid", "Hybrid_Storage.csv")]:
        raw = open(f"{path}/{fn}", encoding="utf-8-sig").read().replace("\r\n", "\n").replace("\r", "\n")
        sep = ";" if raw.split("\n")[0].count(";") > raw.split("\n")[0].count(",") else ","
        counts = {}
        for row in list(csv.reader(io.StringIO(raw), delimiter=sep))[1:]:
            if not row or row[0].strip() not in code2slot: continue
            s = code2slot[row[0].strip()]
            for cell in row[1:]:
                ref = cell.split(";")[0].strip()
                if ref in t2i: counts.setdefault(t2i[ref], {}).setdefault(s, 0); counts[t2i[ref]][s] += 1
        pl = np.full(ds.P, -1); used = set()
        for p in sorted(range(ds.P), key=lambda p: -picks[p]):
            if p in counts:
                c = counts[p]; want = max(c, key=lambda s: (c[s], -ds.d_exit[s]))
            else: want = int(ds.pl_asis[p])
            if want not in used: pl[p] = want; used.add(want); continue
            free = [s for s in range(ds.L) if s not in used]; best = min(free, key=lambda s: ds.D[want, s]); pl[p] = best; used.add(best)
        out[name] = pl
    return out
