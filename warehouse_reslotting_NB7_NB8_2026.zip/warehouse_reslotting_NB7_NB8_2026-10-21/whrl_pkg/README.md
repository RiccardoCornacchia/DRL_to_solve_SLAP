# whrl: the package of the method

`whrl` (Warehouse Re-slotting with Reinforcement Learning) contains all the code of the method. The notebooks import it
instead of defining the functions in their cells, so the same code serves both warehouses.

## Install once

```
pip install -e whrl_pkg
```

`-e` (editable) means that Python reads the files directly from this folder: when you change a file, the change is
used the next time the module is imported. In a notebook, either restart the kernel after editing, or put these two
lines in the first cell so that edited modules are reloaded automatically:

```
%load_ext autoreload
%autoreload 2
```

## What is where

| File | Contents |
|---|---|
| `whrl/data.py` | dataset adapters: every dataset becomes the same `Dataset` object |
| `whrl/knowledge.py` | from orders to the weights of the score; choice of the score (`set_surrogate`) |
| `whrl/env.py` | warehouse state, moves (general or swaps only), budget, incremental score (`RollEnv`) |
| `whrl/greedy.py` | the greedy |
| `whrl/policy.py` | the network, the practice games, REINFORCE training, reorganization played by the network |
| `whrl/rolling.py` | the judge (true picking routes), relocation cost, protocol over time |
| `whrl/fullscale.py` | budgets chosen on the validation months, the three protocols (single-shot, hybrid, from scratch), the training pools (monthly, weekly bootstrap, synthetic) and the full-scale statistical protocol of Notebook 6: validation/test split, checkpoints with early stopping, multiple seeds, paired tests |
| `whrl/analysis.py` | shared descriptive analyses: churn of the demand, distance of the real layout from the single-home model, floor-plan size and time model |
| `whrl/budget.py` | the techniques to choose the budget |
| `whrl/routes.py` | real picking sequences (pharmaceutical dataset) |
| `whrl/footwear_extras.py` | navigation points (distances along the aisles) and static policies of the footwear dataset |
| `whrl/video.py` | the videos |
| `whrl/stats.py` | paired t-test and Wilcoxon test |
| `scripts/run_full_scale.py` | command-line runner of the full-scale protocol |
| `scripts/compare_surrogates.py` | comparison between the two scores |

## Moving notebook code into a module

Code copied from a notebook into a `.py` file usually fails for one reason: in a notebook a function can use any
variable defined in an earlier cell (`orders`, `months`, `rng`, `pl_asis`, `month_dist`, ...), while a module only sees
what it imports or receives as arguments. The rules that make the conversion work:

1. **Every function receives what it uses as arguments.** For example, Notebook 6 has `rolling_split(opt_fn, upto)`,
   which reads `orders`, `months`, `pl_asis` and `month_dist` from the notebook; in `whrl/fullscale.py` it becomes
   `rolling_months(ds, judge, opt_fn, eval_months, K0, Km, window, upto)`, where `ds` carries the data and `judge`
   computes the distances.
2. **Imports at the top of the file, relative inside the package**: `from .env import RollEnv`, not `from env import ...`.
3. **No global random generator.** Instead of `global rng`, a function creates `np.random.default_rng(seed)` or
   receives a generator as an argument.
4. **Nothing runs at import time.** The module only defines functions; the work is done by a script or a notebook that
   calls them.

## Running the notebooks

`build_nb.py` generates the two notebooks from one flow; `Warehouse_NB7_Footwear.ipynb` and `Warehouse_NB8_Pharma.ipynb` differ only in the line `DATASET = ...` and in the checks of section 9. Open them in Jupyter from the folder that contains `whrl_pkg/`, `footwear/` and `pharma/` and run the cells in order. Environment variables (set them before starting Jupyter, or with `os.environ[...]` in the first cell):

| Variable | Default | Meaning |
|---|---|---|
| `QUICK` | `1` | reduced grids and iterations; `0` = full scale of every cell |
| `RUN_NETWORK` | `1` | run the cells that need PyTorch |
| `RUN_VIDEOS` | `1` | render the videos (needs `RUN_NETWORK`) |
| `RUN_FULL` | `0` | run the full-scale statistical protocol inside the notebook (section 10) |
| `SURROGATE` | unset | force a score (`rules_squared`, `copicks_linear`, `copicks_linear_b5`) instead of the one chosen on validation |
| `SEEDS` | `0 1 2 3 4` | seeds of the full-scale protocol |

Every heavy result is saved in `cache_<dataset>/` as soon as it is computed (one `.pkl` per unit of work, `.pt` training checkpoints every few iterations, readable `.json` copies of every table); an interrupted run resumes where it stopped. To recompute a result, delete its file. `run_nb.py <notebook>` executes a notebook from the command line, cell by cell, saving after every cell.

## Running the full-scale protocol

From the folder that contains `footwear/` and `pharma/`:

```
# 0) run the notebook first: it chooses the score and the budgets on validation and saves them in cache_<dataset>/
# 1) check that everything works (a few minutes)
python whrl_pkg/scripts/run_full_scale.py --dataset footwear --seeds 0 --configs greedy zero-shot --checkpoints 5 10 --cache smoke_test

# 2) full scale, splitting the seeds across machines
python whrl_pkg/scripts/run_full_scale.py --dataset pharma --seeds 0 1      # machine A
python whrl_pkg/scripts/run_full_scale.py --dataset pharma --seeds 2 3 4    # machine B

# 3) after copying the two cache folders into one, the final table
python whrl_pkg/scripts/run_full_scale.py --dataset pharma --seeds 0 1 2 3 4 --summary-only
```

Each (configuration, seed) is saved in its own file inside the cache folder (default `full_scale_<dataset>_<score>`);
training saves its state at every checkpoint, so an interrupted run resumes where it stopped. The final table is printed
and saved as `summary.csv`: mean and standard deviation of the test net saving over the seeds, the checkpoint chosen on
validation for every seed, and the paired tests against the greedy on the monthly test net savings.

Default settings: validation = first 3 evaluation months, test = the remaining ones; checkpoints at 150, 300, 450, 600,
900, 1200, 1500, 1800 and 2100 iterations; early stopping after 2 checkpoints without improvement; configurations
greedy, zero-shot (one instance), monthly (one instance per training month), weekly-bootstrap (weekly windows with
orders resampled with replacement) and synthetic (orders generated from a model fitted on the training months).
Training instances are built only from the 3 months before the evaluation period. The score and the budgets are read
from the notebook cache (`cache_<dataset>/score_choice.json`, `budgets.json`); `--k0`, `--km` and `--surrogate` override them.
