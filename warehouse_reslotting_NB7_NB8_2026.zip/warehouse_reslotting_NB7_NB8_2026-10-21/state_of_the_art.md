# Stato dell'arte: lavori sul dataset delle calzature e lavori simili (28 settembre 2026)

## In breve

Questo documento raccoglie cosa esiste in letteratura vicino al nostro lavoro: la riorganizzazione periodica di un magazzino esistente, spostando pochi tipi di prodotto per volta sotto un budget, con una rete neurale che impara quali spostare. I risultati principali sono tre.

1. **Sul dataset delle calzature non esistono lavori di altri gruppi.** Ci sono solo i quattro lavori degli autori del dataset, e nessuno di loro riorganizza nel tempo o usa l'apprendimento per rinforzo.
2. **Il confronto tra riorganizzazione incrementale e riorganizzazione da capo non è nuovo.** Kofler e colleghi lo hanno studiato nel 2011 con il nome di *healing* contro *re-warehousing*, e lo hanno sviluppato in lavori successivi. Va citato, e non possiamo presentarlo come nostra novità.
3. **Imparare quali pochi tipi di prodotto spostare sotto un budget non risulta coperto.** Lo stesso vale per la scelta economica del budget. Il lavoro più vicino da leggere con attenzione è quello di Pan e colleghi (IEEE TKDE, 2025).

## 1. Termini usati

* **Tipo di prodotto**: il modello (per esempio un modello di scarpa). **Posizione**: un punto di stoccaggio sugli scaffali.
* **Trasloco**: il cambio di posizione di un tipo di prodotto. **Budget**: il numero massimo di tipi di prodotto spostabili in un intervento.
* **Netto**: distanza risparmiata dagli operatori meno il costo di manodopera dei traslochi.
* **SLAP** (*Storage Location Assignment Problem*): il problema di decidere in quale posizione tenere ogni tipo di prodotto.
* **Re-warehousing**: riorganizzare l'intero magazzino, come se lo si riempisse da zero.
* **Healing**: correggere la disposizione con pochi traslochi alla volta, ripetuti nel tempo.
* **Apprendimento per rinforzo**: un modello che impara per tentativi, ricevendo una ricompensa per le proprie scelte.

## 2. Come è stata fatta la ricerca

Ricerche mirate su motori generali e su Semantic Scholar e OpenAlex, con cinque interrogazioni:
* lavori che usano il dataset delle calzature;
* riorganizzazione con numero limitato di traslochi;
* *healing* contro *re-warehousing*;
* apprendimento per rinforzo applicato all'assegnazione e alla riassegnazione delle posizioni;
* il lavoro di Pan e colleghi.

**Limite.** Non è una revisione sistematica. Per il paper servirebbe partire dalle citazioni dei lavori chiave, cioè da chi cita Kofler et al. 2011 e Waubert de Puiseau et al. 2022 (sezione 8).

## 3. Lavori sul dataset delle calzature

Tutti i lavori sono del gruppo dell'École de Technologie Supérieure di Montréal, autore del dataset.

| Lavoro | Cosa fa | Relazione con il nostro lavoro |
|---|---|---|
| de Assis et al., IEEE Access, 2024 | ottimizza il percorso degli operatori con la disposizione attuale | non cambia la disposizione; noi la cambiamo e misuriamo i percorsi |
| Gomez Gnone, de Assis, Ouhimmou, de Paula Ferreira, IFAC-PapersOnLine, 2025 | confronta quattro politiche statiche di stoccaggio (Random, Class-Based, Dedicated, Hybrid) nel magazzino dinamico dell'azienda | sono l'unico confronto esterno possibile: misurate con il nostro giudice sono tutte battute dal nostro protocollo incrementale (sezione 6.5 del report di progetto) |
| de Assis, de Paula Ferreira, Ouhimmou, Data in Brief 61, 111837, 2025 | descrive il dataset: pianta, posizioni, ordini, ondate di prelievo, disposizioni delle quattro politiche | è la fonte dei dati |
| de Assis et al., Procedia Computer Science 232, 2024, 2790-2799 | rassegna sull'uso del machine learning nella gestione dei magazzini | contesto; non usa il dataset per esperimenti di riorganizzazione |

**Conclusione.** Nessun lavoro sul dataset riorganizza la disposizione nel tempo sotto un budget, né usa l'apprendimento per rinforzo.

## 4. Riorganizzazione periodica con pochi traslochi

È il filone più vicino al nostro protocollo nel tempo.

* **Kofler, Beham, Wagner, Affenzeller, Achleitner, "Re-warehousing vs. healing: Strategies for warehouse storage location assignment", 3rd IEEE International Symposium on Logistics and Industrial Informatics (LINDI), 2011, pp. 77-82.** Su un magazzino di esempio, pochi interventi di riordino ogni giorno portano in qualche mese a una buona disposizione complessiva, con risultati competitivi con la riorganizzazione completa. *In comune con noi*: il confronto tra incrementale e da capo. *Cosa aggiungiamo*: il netto come metrica di decisione, con la manodopera espressa nella stessa unità della distanza; dati reali di due magazzini; un protocollo di valutazione con semi multipli e test statistici; la scelta di quali tipi di prodotto spostare fatta da una rete addestrata.
* **Kofler et al., "The multi-period storage location assignment problem", IEEE APCAST, 2012, pp. 38-41; e "Affinity Based Slotting in Warehouses with Dynamic Order Patterns", capitolo Springer, 2014.** Estendono il problema a più periodi con domanda che cambia, e confrontano regole di assegnazione, in particolare una basata sull'affinità tra tipi di prodotto (quanto spesso compaiono negli stessi ordini). *In comune con noi*: la domanda che cambia nel tempo e l'uso delle dipendenze tra tipi di prodotto.
* **Kofler et al., "Robust Storage Assignment in Warehouses with Correlated Demand", capitolo Springer, 2015.** Osserva che riorganizzare conviene solo se il guadagno di efficienza supera lo sforzo dei traslochi. *In comune con noi*: è l'idea alla base del nostro netto, che va quindi presentato come una formalizzazione e non come un'idea nuova.
* **Tesi "Optimising the Storage Location Assignment Problem Under Dynamic Conditions" (stesso gruppo).** Modello multi-periodo che mette a confronto il costo dei traslochi con gli spostamenti iterativi dei tipi di prodotto; strategie di trasloco robuste battono quelle greedy.
* **Xu et al., "Research on Dynamic Storage Location Assignment of Picker-to-Parts Picking Systems under Traversing Routing Method", Complexity, 2020.** Sposta periodicamente una piccola parte dei tipi di prodotto invece di riottimizzare tutto, cercando il massimo guadagno con il minimo costo di adeguamento.
* **"A dynamic storage location assignment model for a progressive bypass zone picking system with an S/R crane", Journal of the Operational Research Society 73(5).** Propone un modello di riassegnazione per quando la capacità di trasloco è limitata: sposta coppie di tipi di prodotto in ordine di priorità. *In comune con noi*: il budget sui traslochi. *Differenza*: magazzino automatizzato a zone e regole di priorità, senza apprendimento.

**Conclusione.** L'idea di riorganizzare poco e spesso invece di tutto e raramente, e l'idea che i traslochi debbano ripagarsi, esistono da almeno quindici anni. Non ho trovato in questo filone lavori che imparino quali tipi di prodotto spostare, né che scelgano il budget con tecniche a basso costo.

## 5. Apprendimento per rinforzo per l'assegnazione delle posizioni

* **Waubert de Puiseau et al., "Dynamic Storage Location Assignment in Warehouses Using Deep Reinforcement Learning", Technologies 10(6), 129, 2022.** Un agente decide dove mettere la merce *in arrivo*. È addestrato su un anno di dati reali e, su due mesi nuovi, riduce i costi del 6,3% rispetto alla classificazione ABC manuale usata dall'azienda. *Differenza*: assegna gli arrivi, non riorganizza i tipi di prodotto già a scaffale.
* **Lavori citati da Waubert de Puiseau et al.** Kim e colleghi, per i blocchi dei cantieri navali, addestrano due agenti: uno assegna la posizione iniziale, l'altro esegue i traslochi. È il precedente più vicino all'idea di un agente che decide i traslochi, ma in un dominio diverso e senza budget sul numero di traslochi. Rimélé e colleghi assegnano i pallet in arrivo a una di sei zone.
* **Pan et al., "Large-Scale Storage Location Assignment via Hierarchical Reinforcement Learning: A Rank and Assign Approach", IEEE Transactions on Knowledge and Data Engineering 37(11), 6506-6520, 2025.** Assegnazione su larga scala in due passi: prima si ordina, poi si assegna. **È il lavoro da leggere per primo**: va verificato se tratta anche le riassegnazioni con un budget, perché in quel caso sarebbe il confronto diretto più vicino.
* **"Solving the Storage Location Assignment Problem Using Reinforcement Learning", ICMAI 2023.** Apprendimento per rinforzo per l'assegnazione, pensato per adattarsi a parametri che cambiano durante l'esercizio. Istanze piccole.
* **"Data-driven reinforcement learning-based optimization of shared warehouse storage locations", Computers & Industrial Engineering, 2025.** Ottimizzazione delle posizioni in magazzini condivisi, con dati che cambiano in tempo reale. Da leggere per capire se prevede un costo o un limite ai traslochi.

**Conclusione.** L'apprendimento per rinforzo è usato soprattutto per assegnare gli arrivi o per riassegnare tutto. Non ho trovato un metodo che, dato un magazzino esistente e un budget, impari quali pochi tipi di prodotto spostare.

## 6. Altri filoni utili per il contesto

* **Assegnazione delle posizioni e percorsi insieme, risolti in modo esatto**: "The Storage Location Assignment and Picker Routing Problem: A Generic Branch-Cut-and-Price Algorithm", arXiv 2407.13570, 2024. Calcola in modo esatto la distanza di ogni ordine per ogni assegnazione, su istanze piccole. È il contrappunto al nostro approccio, che cerca con un punteggio veloce e giudica con i percorsi veri.
* **Politiche classiche**: popolarità (ABC), classi, stoccaggio correlato. Sono le basi di confronto usuali, e sul nostro dataset le rappresentano le quattro politiche statiche degli autori.

## 7. Cosa possiamo rivendicare e cosa no

Per ciascun elemento, lo stato: *nuovo* (nessun precedente trovato), *noto* (esiste un precedente da citare), *da verificare* (serve leggere un lavoro specifico).

| Elemento del nostro lavoro | Precedente più vicino | Stato |
|---|---|---|
| Confronto tra riorganizzazione incrementale e da capo | Kofler et al. 2011 (healing contro re-warehousing) | noto: citarlo; il nostro contributo è la misura con il netto, su dati reali, con test statistici e due magazzini |
| Riorganizzare conviene solo se il risparmio supera il costo dei traslochi | Kofler et al. 2015 | noto come idea; il netto con la manodopera nella stessa unità della distanza e il costo misurato in secondi (farmaceutico) sono la nostra formalizzazione |
| Budget sul numero di traslochi | modello di riassegnazione con capacità limitata (JORS) | noto come vincolo; nuovo in combinazione con l'apprendimento |
| Rete che impara *quali* tipi di prodotto spostare sotto un budget, con la posizione di arrivo calcolata esattamente | Kim et al. (agente dei traslochi, blocchi navali); Pan et al. 2025 | nuovo per quanto trovato; da verificare con Pan et al. 2025 |
| Scelta del budget con bisezione, sezione aurea o stima senza riorganizzazioni | nessuno trovato | nuovo |
| Ricerca con un punteggio veloce e giudizio con i percorsi veri, con pesi calibrati sul giudice | l'indice classico dell'assegnazione quadratica è noto | la formula è nota; la separazione tra punteggio e giudice e la calibrazione dei pesi sono il nostro contributo |
| Confronto con le politiche statiche degli autori del dataset | lavoro IFAC 2025 degli autori | nuovo: nessuno le ha confrontate con una riorganizzazione a budget |
| Due magazzini reali con lo stesso codice, protocollo statistico con semi multipli | nessuno trovato su questo problema | contributo di solidità |

Da non rivendicare: la novità del Transformer o dell'algoritmo di addestramento (REINFORCE), e la superiorità su metodi che nessuno ha applicato a questo problema.

**Da correggere nei materiali del progetto.** Il report di stato (`REPORT.md`, sezione 7.2) e il Notebook 7 (sezione 9) presentano il protocollo incrementale come novità: vanno allineati alla tabella qui sopra, citando Kofler et al. 2011.

## 8. Prossimi passi per Riccardo

| # | Cosa | Stima |
|---|---|---|
| 1 | Leggere Pan et al. 2025 (IEEE TKDE) e verificare se gestiscono riassegnazioni con un budget e quali dati usano | mezza giornata |
| 2 | Cercare su Google Scholar chi cita Kofler et al. 2011 e Waubert de Puiseau et al. 2022, tenendo i lavori che riorganizzano un magazzino esistente o usano l'apprendimento per rinforzo | un giorno |
| 3 | Leggere il lavoro di Kim e colleghi sui blocchi navali e il lavoro di Computers & Industrial Engineering 2025, per capire se prevedono un costo o un limite ai traslochi | mezza giornata |
| 4 | Aggiungere i riferimenti di questo documento al capitolo sullo stato dell'arte della tesi | mezza giornata |

## 9. Riferimenti

* de Assis, R. F., de Paula Ferreira, W., Ouhimmou, M. (2025). Order picking dataset from a warehouse of a footwear manufacturing company. *Data in Brief*, 61, 111837.
* de Assis, R. F., et al. (2024). Optimising warehouse order picking: Real case application in the shoe manufacturing industry. *IEEE Access*, 12.
* de Assis, R. F., et al. (2024). Machine Learning in Warehouse Management: A Survey. *Procedia Computer Science*, 232, 2790-2799.
* Gomez Gnone, D., de Assis, R. F., Ouhimmou, M., de Paula Ferreira, W. (2025). Enhancing Warehouse Efficiency: A Study on Storage Allocation Assignment in a Footwear Manufacturing Company. *IFAC-PapersOnLine*.
* Kofler, M., Beham, A., Wagner, S., Affenzeller, M., Achleitner, W. (2011). Re-warehousing vs. healing: Strategies for warehouse storage location assignment. *3rd IEEE International Symposium on Logistics and Industrial Informatics (LINDI)*, 77-82.
* Kofler, M., Beham, A., Wagner, S., Affenzeller, M., Achleitner, W. (2012). The multi-period storage location assignment problem. *IEEE APCAST 2012*, 38-41.
* Kofler, M., Beham, A., Wagner, S., Affenzeller, M. (2014). Affinity Based Slotting in Warehouses with Dynamic Order Patterns. Capitolo Springer, doi 10.1007/978-3-319-01436-4_7.
* Kofler, M., Beham, A., Wagner, S., Affenzeller, M. (2015). Robust Storage Assignment in Warehouses with Correlated Demand. Capitolo Springer, doi 10.1007/978-3-319-15720-7_29.
* Xu et al. (2020). Research on Dynamic Storage Location Assignment of Picker-to-Parts Picking Systems under Traversing Routing Method. *Complexity*, doi 10.1155/2020/1621828.
* A dynamic storage location assignment model for a progressive bypass zone picking system with an S/R crane. *Journal of the Operational Research Society*, 73(5), doi 10.1080/01605682.2021.1892462.
* Waubert de Puiseau, C., et al. (2022). Dynamic Storage Location Assignment in Warehouses Using Deep Reinforcement Learning. *Technologies*, 10(6), 129.
* Pan, W., Chen, M., Lin, B., Wang, Y., Zhao, X., He, X., Ye, J. (2025). Large-Scale Storage Location Assignment via Hierarchical Reinforcement Learning: A Rank and Assign Approach. *IEEE Transactions on Knowledge and Data Engineering*, 37(11), 6506-6520, doi 10.1109/TKDE.2025.3609173.
* Solving the Storage Location Assignment Problem Using Reinforcement Learning (2023). *Proceedings of the 8th International Conference on Mathematics and Artificial Intelligence (ICMAI)*, doi 10.1145/3594300.3594314.
* Data-driven reinforcement learning-based optimization of shared warehouse storage locations (2025). *Computers & Industrial Engineering*.
* The Storage Location Assignment and Picker Routing Problem: A Generic Branch-Cut-and-Price Algorithm (2024). arXiv 2407.13570.

Per i lavori senza autori indicati, gli autori vanno completati dalla pagina dell'editore prima di citarli nella tesi.
