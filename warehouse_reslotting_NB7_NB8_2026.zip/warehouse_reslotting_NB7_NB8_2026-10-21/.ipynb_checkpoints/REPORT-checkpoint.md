> **Aggiornamento del 21 ottobre 2026.** Questa versione parte dalla base di codice di Riccardo (greedy con temperatura adattiva, tenuto e documentato in §4.1) e applica quattro decisioni: (1) la rete si allena solo sui mesi di warm-up e il confronto rete/greedy della scala piena viene rifatto in entrambi i magazzini (il 12% del Notebook 6 è scartato, vedi sotto); (2) il costo del trasloco farmaceutico sale da 142 secondi a 10 minuti per tipo di prodotto (i 142 secondi misurati sono il tempo di una singola scatola, un limite inferiore), e di conseguenza i budget scelti sulla validazione cambiano: nel farmaceutico K₀ scende da 2.385 a 798 tipi di prodotto e Kₘ resta 0; nelle calzature 133 e 0. I budget sono scelti con la sezione aurea, circa dieci riorganizzazioni per budget, in entrambi i magazzini; (3) i netti sono riportati come sono, con una riga di ritocco forzato in §6 e la stabilità della domanda (§2.2) come causa del ritocco nullo; (4) la scelta del budget usa una griglia fine, un valore ogni 2% dei tipi di prodotto. Le lunghezze delle partite della rete sono legate al budget (2 × K in allenamento, 4 × K in uso, nessun tetto). I dettagli, con i numeri, sono in `CHANGELOG.md`.
>
> **Aggiornamento del 13 ottobre 2026 (leggere prima del resto).** I due notebook sono stati rigenerati da un unico generatore (`build_nb.py`) con **lo stesso metodo in entrambi i magazzini**: le differenze di metodo discusse nelle settimane scorse sono state tolte. Le decisioni condivise sono elencate in testa a ciascun notebook e qui sotto. Di conseguenza **tutti i risultati numerici riportati nelle sezioni 4-9 di questo report sono superati** e vanno ricalcolati con i notebook nuovi (modalità rapida, poi scala piena con la sezione 10): restano valide le descrizioni dei dataset (sezione 3) e le definizioni.
>
> Decisioni condivise dai due notebook:
> 1. una sola posizione per tipo di prodotto (casa unica); il notebook misura quanto il magazzino reale se ne discosta (§2.3): nelle calzature ogni tipo di prodotto è prelevato in media da 44 posizioni e la posizione più usata copre il 25% dei prelievi (scattered ricondotto a casa unica, limite da dichiarare); nel farmaceutico la posizione principale copre il 98% dei prelievi;
> 2. distanza di cammino realistica di ciascun dataset per ottimizzatore e giudice in entrambi (lungo i corridoi per le calzature, dai punti di navigazione; sul pavimento attorno agli scaffali per il farmaceutico, dalla pianta); la distanza di Manhattan sulle coordinate è usata solo come secondo giudice di controllo (§9.1), e nel farmaceutico si rivela fuorviante (ignora muri e scaffali);
> 3. capacità di una posizione = occupazione attuale (`EXTRA_CAPACITY = 0`), con l'ablazione a +1 in §4.1;
> 4. **tutti i tipi di prodotto sono spostabili** in entrambi i magazzini: la restrizione ai 586 del farmaceutico è stata tolta (era una scelta non motivata, che rendeva irraggiungibili 473 posizioni su 972); i 586 coprivano il 90% dei prelievi, non il 70% scritto più avanti;
> 5. due insiemi di mosse confrontati (generale e solo scambio), stessa capacità dei dati;
> 6. **lo stesso punteggio candidato** in entrambi (`rules_squared`, `copicks_linear`, `copicks_linear_b5`), scelto sui mesi di validazione con la stessa regola (§3.4); nessun punteggio è più fissato per magazzino;
> 7. **budget scelti sui mesi di validazione** con la stessa bisezione (§4.2): K₀ sul netto della riorganizzazione iniziale, Kₘ sul netto del ritocco (0 se il ritocco non si ripaga). I valori 90/10 delle calzature e 150/20 del farmaceutico non si usano più; in §7.1 il budget ottimo è mostrato in funzione dell'orizzonte di utilizzo (cresce con i mesi in cui la disposizione resta in uso);
> 8. costo di un trasloco κ × (0,5 + indice di ingombro) in entrambi, con κ misurato dove ci sono i tempi (farmaceutico) e convenzionale dove non ci sono (calzature: 60.000 unità = un'ora a 1,27 m/s); il confronto tra protocolli è ripetuto con κ/2 e 2κ;
> 9. conversione delle unità in secondi in entrambi (modello misurato nel farmaceutico, convenzione dichiarata nelle calzature), quindi ogni netto è dato anche in ore;
> 10. valutazione: 3 mesi di warm-up, validazione (primi 3 mesi di valutazione) separata dal test; protocollo statistico di scala piena identico (§10), con le configurazioni greedy, zero-shot, mensile, settimanale con bootstrap e sintetica.
>
> **Dati di addestramento della rete nel Notebook 6 (solo calzature): un errore, ora corretto.** Nella sezione 10.8 del Notebook 6 la validazione era aprile-giugno e il test luglio-ottobre, ma le reti erano allenate su ordini che arrivavano dentro quei mesi: la zero-shot sugli ordini fino al 22 agosto (l'80% delle date, rimasto da una valutazione precedente in cui il test era l'ultimo 20%), la multi-istanza mensile su finestre fino a settembre, quella settimanale con bootstrap su finestre fino a fine ottobre. Il greedy non era toccato, perché ogni mese usa solo gli ordini dei tre mesi precedenti. Il confronto della scala piena (rete migliore del greedy del 12%) metteva quindi a confronto una rete che aveva visto ordini dei mesi di test con un greedy che non li aveva visti, e va rifatto con i notebook nuovi prima di essere usato. Il farmaceutico non è interessato: non ha mai avuto un Notebook 6, e i notebook 7 e 8 hanno sempre allenato la rete solo sui mesi di warm-up. Nei notebook nuovi la regola è nel codice: tutti gli scenari di addestramento (zero-shot, mensile, settimanale con bootstrap, sintetico) sono costruiti solo dai tre mesi di warm-up.
>
> Correzioni ai notebook precedenti: il caso "1 mese" della scelta del budget non sceglieva il ritocco (partiva dalla disposizione attuale) ed è sostituito dalla curva del ritocco (§7.3); le riorganizzazioni di bisezione e sezione aurea sono ora contate per tecnica (§7.2); la reward della sezione 4 è misurata a regime fisso (quota del punteggio tolta nella riorganizzazione iniziale); aggiunti il churn della domanda (§2.2), il confronto single-shot/ibrido/da zero sui soli mesi di test (§6), gli insiemi di mosse (§4.1), le istanze sintetiche (§4.4) e la dimensione in metri dei magazzini.
>
> Nella modalità rapida eseguita per controllo (greedy, un seme, versione del 21 ottobre): il punteggio scelto sulla validazione è `copicks_linear_b5` in entrambi i magazzini; calzature K₀ = 133 e Kₘ = 0, farmaceutico K₀ = 798 e Kₘ = 0 (nessun ritocco si ripaga, con un'ora per trasloco nelle calzature e dieci minuti nel farmaceutico); il budget ottimo cresce con i mesi di uso (calzature: 37 con un mese, 114 con due, 131 con tre o quattro, 139 da cinque; farmaceutico: 94, 561, 795, 935, 1.309 con 1, 2, 3, 4, 5-6 mesi). I numeri definitivi arrivano dalle esecuzioni a scala piena.

# Riorganizzazione del magazzino con reinforcement learning: stato del lavoro (27 settembre 2026)

Questo documento è autosufficiente: descrive cosa è stato fatto dopo la riunione del 22 settembre 2026 con il Prof. Moro, perché, con quali risultati, e cosa resta da fare. Presuppone solo la conoscenza dei Notebook 1-6 e della run definitiva sulle calzature (sezione 1).

## 1. Contesto

**Il problema.** Decidere in quale posizione degli scaffali tenere ogni tipo di prodotto, così che gli operatori camminino meno per preparare gli ordini. Il vincolo è che si possono spostare pochi tipi di prodotto per volta, perché ogni spostamento costa manodopera.

**Cosa era già stabilito (Notebook 1-6, dataset delle calzature).** La pipeline completa:
* dagli ordini si ricavano popolarità e dipendenze tra tipi di prodotto (FP-Growth);
* un punteggio veloce guida la ricerca, il calcolo dei percorsi veri giudica il risultato;
* due ottimizzatori decidono quali tipi di prodotto spostare: il greedy e la rete;
* il protocollo nel tempo prevede una riorganizzazione iniziale con budget 90, poi un ritocco mensile con budget 10.

La run definitiva (5 semi, fino a 2.100 iterazioni di addestramento con scelta del checkpoint sui mesi di validazione, test statistici appaiati) ha dato questo risultato: tutte le configurazioni della rete ottengono tra 17,2 e 17,4 milioni di unità di distanza di netto sui mesi di test, contro 15,5 milioni del greedy. È circa il 12% in più, con t tra +10 e +21 e p praticamente nullo. Addestrare la rete su più scenari di domanda (multi-istanza) non aggiunge nulla rispetto a un solo scenario (zero-shot), perché nelle calzature la domanda cambia lentamente.

**Cosa ha chiesto la riunione del 22 settembre.**
1. Mostrare quanto rende il rollout incrementale (90 tipi di prodotto all'inizio, poi 10 al mese) rispetto a rifare la riorganizzazione da capo ogni mese (90 ogni mese), in efficacia ed efficienza.
2. Video comprensibili da chiunque, che mostrino la rete mentre impara, a confronto col greedy.
3. Un modo economico per scegliere il budget: provare tutti i valori costa troppo, e nessun passo della soluzione deve avere costo esponenziale.
4. Lo stato dell'arte sul dataset delle calzature e la novità del nostro lavoro.
5. Un secondo notebook sul nuovo dataset farmaceutico (privato), con lo stesso metodo e un'esplorazione dettagliata dei dati. Il dataset include i tempi reali di prelievo e una modellazione a matrici del problema, da confrontare con la nostra.
6. Documentazione più chiara.

## 2. Come leggere questo documento

### 2.1 Glossario (usato in modo esclusivo)

* **Magazzino**: l'edificio con gli scaffali. **Pianta**: la sua rappresentazione vista dall'alto.
* **Posizione**: un punto di stoccaggio sugli scaffali, con coordinate sulla pianta; può contenere uno o più tipi di prodotto.
* **Deposito**: il punto da cui l'operatore parte e a cui torna a ogni ordine (nei video: "packing station").
* **Livello di scaffale**: il ripiano, cioè l'altezza a cui si trova una posizione sullo scaffale. Due posizioni nello stesso punto della pianta ma a livelli diversi hanno la stessa distanza dal deposito.
* **Tipo di prodotto**: il modello (un modello di scarpa, un articolo farmaceutico). È ciò che il metodo assegna a una posizione, sposta e conta nel budget.
* **Prodotto**: la singola unità fisica di un tipo di prodotto (un paio di scarpe nella sua scatola, una confezione di farmaco). **Giacenza**: i prodotti di un tipo presenti sugli scaffali in un dato momento.
* **Ordine**: l'insieme dei tipi di prodotto che un operatore preleva in un unico giro. **Prelievo**: prendere uno o più prodotti di un tipo da una posizione.
* **Co-prelievo**: due tipi di prodotto sono co-prelevati quando compaiono nello stesso ordine; il numero di co-prelievi di una coppia è il numero di ordini in cui compaiono entrambi.
* **Percorso di prelievo**: il giro deposito, posizioni dei tipi di prodotto dell'ordine, deposito, calcolato come giro più corto.
* **Unità di distanza**: nelle calzature 1 unità = 7,6 cm lungo i corridoi. Nel farmaceutico la pianta è divisa in quadrati uguali (118 x 63) e 1 unità = il lato di un quadrato; la misura in metri non è fornita, e dal passo medio misurato si stimano 60-70 cm.
* **Trasloco**: il cambio di posizione di un tipo di prodotto, cioè lo spostamento di tutta la sua giacenza. **Budget K**: il numero massimo di tipi di prodotto che possono cambiare posizione in un intervento.
* **Greedy**: l'ottimizzatore di riferimento, una regola fissa senza apprendimento. A ogni passo sposta il tipo di prodotto che in quel momento peggiora di più il punteggio, nella migliore tra alcune posizioni candidate.
* **Rete**: la rete neurale (un Transformer) che impara per tentativi, con l'algoritmo REINFORCE, quale tipo di prodotto spostare. La posizione di arrivo la sceglie la stessa regola del greedy.
* **Punteggio**: la formula veloce che stima quanto è buona una disposizione e guida la ricerca (sezione 4). **Giudice**: la misura vera, la somma dei percorsi di prelievo di tutti gli ordini.
* **Risparmio lordo**: quota di distanza risparmiata rispetto a non riorganizzare mai. **Netto**: distanza risparmiata meno il costo di manodopera dei traslochi, in unità di distanza.
* **Iterazione di addestramento**: 8 partite di prova giocate dalla rete sullo stesso scenario, seguite da un aggiornamento dei suoi parametri. Una partita dura 120 mosse nel regime della riorganizzazione iniziale e 20 (calzature) o 40 (farmaceutico) mosse nel regime del ritocco mensile.

### 2.2 Modalità QUICK e scala piena

I notebook hanno due modalità.
* **QUICK** serve a verificare che tutto funzioni in poco tempo su un portatile: un solo seme; rete zero-shot addestrata per 40 iterazioni (320 partite); rete dei video addestrata per 150 iterazioni (1.200 partite), con checkpoint ogni 10 iterazioni, in entrambi i magazzini.
* **Scala piena** alza la rete delle celle dei notebook a 600 iterazioni e i checkpoint dei video a 30 da 20 iterazioni. Il protocollo statistico completo del Notebook 6 (validazione separata dal test, checkpoint con early stopping fino a 2.100 iterazioni, 5 semi, test appaiati) è nel modulo `fullscale.py` e si esegue da riga di comando con `scripts/run_full_scale.py` (istruzioni in `whrl_pkg/README.md`).

Tutti i risultati nuovi di questo documento sono in modalità QUICK, quindi indicano una direzione ma non sono definitivi. L'unico risultato a scala piena è quello della sezione 1.

### 2.3 Il pacchetto `whrl`

Nei Notebook 1-6 tutto il codice stava nelle celle dei notebook. Ora il codice del metodo sta una volta sola in una cartella di file Python, `whrl_pkg/whrl/` (il nome sta per "warehouse re-slotting with reinforcement learning"). Si installa una volta con `pip install -e whrl_pkg`, e i due notebook lo usano con `from whrl import ...`. Così una correzione al metodo vale automaticamente per entrambi i magazzini, e i notebook contengono solo configurazione, esplorazione dei dati, esperimenti e commento.

| File | Contenuto |
|---|---|
| `data.py` | gli adattatori dei due dataset, che producono lo stesso oggetto (sezione 3.3) |
| `knowledge.py` | dagli ordini ai pesi del punteggio (FP-Growth oppure co-prelievi grezzi) e scelta del punteggio |
| `env.py` | lo stato del magazzino, le mosse (spostamento in una posizione libera o scambio), il budget, il calcolo incrementale del punteggio |
| `greedy.py` | il greedy e la scelta delle posizioni candidate |
| `policy.py` | la rete, le partite, l'addestramento REINFORCE, la riorganizzazione giocata dalla rete |
| `rolling.py` | il giudice (percorsi di prelievo), il costo dei traslochi, il protocollo nel tempo, le metriche |
| `budget.py` | le tecniche per scegliere il budget |
| `video.py` | i video |
| `routes.py` | le sequenze reali di prelievo: percorso reale contro percorso più corto (sezione 6.4) |
| `fullscale.py` | il protocollo statistico completo del Notebook 6: separazione tra mesi di validazione e di test, addestramento a checkpoint con early stopping e scelta del checkpoint sulla validazione, semi multipli, test appaiati |
| `footwear_extras.py` | punti di navigazione (distanza lungo i corridoi) e politiche statiche del dataset delle calzature |
| `stats.py` | i test statistici appaiati |
| `scripts/compare_surrogates.py` | l'esperimento di confronto tra punteggi (sezione 4) |
| `scripts/run_full_scale.py` | esecuzione da riga di comando del protocollo a scala piena, riprendibile e divisibile per semi tra più computer |

Il report è in italiano; notebook, codice, commenti e nomi dei file sono in inglese. I notebook sono generati da `build_nb.py`, che scrive entrambi a partire dallo stesso flusso: cambia solo la riga `DATASET = "footwear"` oppure `DATASET = "pharma"`. `run_nb.py` li esegue salvando il notebook dopo ogni cella. I risultati pesanti sono salvati su disco (cartelle `cache_<dataset>`), quindi un'esecuzione interrotta riparte da dove si era fermata, e i semi si possono dividere tra più computer.

## 3. Il dataset farmaceutico

### 3.1 I file dello zip

**In breve.** Lo zip contiene quattro gruppi di file (i nomi sono quelli del dataset, in italiano):
1. *I registri delle operazioni di dieci mesi*: ogni prelievo (quale tipo di prodotto, da quale posizione, quando, quanto è durato, quanti prodotti) in `righe_prelievo.csv`; ogni ordine con il suo tempo di lavoro in `transazioni_dettaglio.csv`; per ogni ordine, i tipi di prodotto nella sequenza reale in cui l'operatore li ha prelevati in `liste_prelievo.csv`.
2. *La descrizione del magazzino*: la pianta con tutte le posizioni (`mappa_magazzino.csv`), la posizione attuale di ogni tipo di prodotto (`slotting_attuale.csv`), la durata dei prelievi per livello di scaffale (`costo_livelli.csv`).
3. *Un problema di ottimizzazione già costruito* da chi ha preparato il dataset, nella cartella `istanza_qap`: distanze a piedi tra le posizioni, co-prelievi tra posizioni, distanze dal deposito, disposizione attuale, metadati (compreso un modello dei tempi).
4. *Documentazione e controlli*: `LEGGIMI.md`, `report_build.json`, `locazioni_non_mappate.csv`.

| File | Una riga è | Cosa contiene | Uso e motivo |
|---|---|---|---|
| `LEGGIMI.md` | | descrizione dei file, anonimizzazione (codici opachi per tipi di prodotto, posizioni, ordini), avvertenze | definisce le unità di misura |
| `righe_prelievo.csv` | un prelievo (441.190) | ordine, tipo di prodotto, posizione, livello di scaffale, inizio, fine, durata in secondi, quantità in pezzi, confezioni, categoria, macro-categoria | fonte principale: ordini, popolarità, co-prelievi, tempi, livelli |
| `transazioni_dettaglio.csv` | un ordine (58.616) | tempo di lavoro effettivo, numero di prelievi, numero di tipi di prodotto, quantità totali | statistiche sui tempi |
| `liste_prelievo.csv` | un ordine (58.616) | tempo di lavoro e tipi di prodotto nell'ordine cronologico in cui sono stati prelevati | validazione del giudice e robustezza dei risparmi (sezione 6.4) |
| `slotting_attuale.csv` | un tipo di prodotto | posizione principale, livello, prelievi, numero di posizioni e quota della principale | esplorazione, analisi dei tipi di prodotto duplicati (3.4) |
| `mappa_magazzino.csv` | una posizione (1.430) | coordinate sulla pianta (riga, colonna) | disegno della pianta e dei percorsi nei video |
| `costo_livelli.csv` | un livello di scaffale | durata mediana del prelievo per livello | solo esplorazione; base di un'estensione possibile |
| `locazioni_non_mappate.csv` | una posizione | l'unica posizione usata ma assente dalla pianta | il suo unico tipo di prodotto viene ricollocato nella sua posizione mappata più usata |
| `report_build.json` | | conteggi della costruzione del dataset, copertura dei prelievi mappati (99,96%) | controllo di coerenza |
| `istanza_qap/D.npy` | | distanze a piedi tra le 972 posizioni usate | distanza del giudice e del punteggio |
| `istanza_qap/dexit.npy` | | distanza a piedi di ogni posizione dal deposito | idem |
| `istanza_qap/F.npy` | | co-prelievi tra posizioni | punteggio alternativo (sezione 4) |
| `istanza_qap/assegnazione_attuale.csv` | un tipo di prodotto | posizione principale | disposizione di partenza |
| `istanza_qap/locazioni.csv` | una posizione (972) | coordinate, prelievi, tipi di prodotto contenuti, distanza dal deposito, punti di accesso | capacità delle posizioni |
| `istanza_qap/istanza.json` | | metadati: pianta 118 x 63, 5.021 quadrati percorribili, deposito scelto tra 223 candidati massimizzando la correlazione con i tempi misurati, modello dei tempi (71,08 s per prelievo più 0,548 s per unità di distanza, R² 0,77, cammino pari al 29% del tempo) | conversione della distanza in ore e prezzo del trasloco |

### 3.2 Come sono rappresentati i dati, rispetto alle calzature

**Che cos'è un ordine.**
* *Calzature.* Ci sono due livelli. Un *ordine del cliente* (`Customer_Order.csv`) elenca, riga per riga, un tipo di prodotto in una taglia e il numero di paia richieste. Per esempio l'ordine 124438 del cliente C0000016 ha 8 righe (le taglie sono scritte come nel dataset):

| Tipo di prodotto | Taglia | Paia |
|---|---|---|
| 8N10W9 | 9 | 6 |
| 2T1DJM | 13 | 1 |
| QVFB0Q | 105 | 1 |
| W25EZN | 13 | 1 |
| W25EZN | 11 | 1 |
| 0LNUOV | 10 | 1 |
| 0LNUOV | 85 | 1 |
| TNAHD4 | 10 | 1 |

  I tipi di prodotto distinti sono 6, perché W25EZN e 0LNUOV compaiono in due taglie ciascuno; le paia sono 13 (6 del primo modello e 1 per ciascuna delle altre 7 righe). Gli operatori però non prelevano un ordine alla volta: raggruppano più ordini di clienti in un'*ondata di prelievo* (`Picking_Wave.csv`) e fanno un giro unico. L'ordine 124438 è stato prelevato nell'ondata 43175. Le ondate sono 9.784, con min 1, mediana 3, media 4,1, max 24 ordini ciascuna. Noi usiamo come ordine l'ordine del cliente, e il giudice calcola un giro per ogni ordine del cliente. È una semplificazione: le distanze assolute risultano più alte di quelle reali, perché nella realtà più ordini condividono lo stesso giro. Il confronto tra disposizioni resta coerente, perché tutte sono valutate con la stessa ipotesi. Un giudice per ondata è un'estensione possibile.
* *Farmaceutico.* C'è un solo livello: una transazione è un giro reale di un operatore, con il suo tempo di lavoro misurato. Per esempio la transazione TRX18403 comprende il prelievo del tipo di prodotto ART0870 dalla posizione LOC1287, durato 212 secondi.

**Geometria: come si misura la distanza tra due posizioni.**
* *Calzature.* Il file delle posizioni dà per ogni posizione due coordinate, in unità da 7,6 cm, e il livello di scaffale. I corridoi sono descritti a parte, in forma schematica, dai punti di navigazione (tabella in fondo a questa sezione). Nel metodo la distanza tra due posizioni è la somma degli spostamenti orizzontale e verticale, perché nei corridoi ci si muove lungo due direzioni perpendicolari; la sezione 6.5 verifica i risultati anche con la distanza lungo i corridoi reali.
* *Farmaceutico.* La pianta è divisa in 118 x 63 quadrati uguali, e ogni posizione occupa un quadrato. Il dataset dà già, per ogni coppia di posizioni, la distanza a piedi contata camminando sui quadrati di pavimento e girando intorno agli scaffali. Esempio: LOC1011 (riga 6, colonna 38) e LOC1068 (riga 7, colonna 36) distano 3 quadrati contando in orizzontale e in verticale, ma 181 quadrati a piedi, perché in mezzo c'è uno scaffale da aggirare. In media la distanza a piedi è 2,4 volte quella in orizzontale e in verticale: usare la formula delle calzature qui sarebbe sbagliato.

**Livelli di scaffale.** Uno scaffale ha più ripiani sovrapposti, e il livello dice su quale ripiano si trova una posizione. Il livello non cambia la distanza a piedi (si cammina sul pavimento), ma può cambiare il tempo del prelievo. I due dataset hanno entrambi i livelli, e il metodo li tratta così.
* *Calzature.* Ci sono 4 livelli: 846 posizioni al livello 1, 846 al livello 2, 301 al livello 3 e 299 al livello 4. Nelle ondate di prelievo 94.812 prelievi avvengono al livello 1, 96.770 al livello 2, 1 al livello 3 e nessuno al livello 4; altri 23.609 prelievi (11%) riguardano codici di posizione assenti dal file delle posizioni. I livelli 3 e 4 sono quindi scorta, e il modello usa solo i livelli 1 e 2, fondendoli così:
  1. *Da due codici a un punto.* Il file delle posizioni dà, per ogni codice di posizione, le coordinate sulla pianta e il livello. Ai livelli 1 e 2 ci sono 846 punti della pianta, e ogni punto ha esattamente due codici, uno per livello. Per esempio C-22-13 (livello 1) e C-22-23 (livello 2) hanno entrambi le coordinate (136, 180): sono i due ripiani dello stesso punto.
  2. *Una posizione del modello per punto.* Nel modello una posizione è un punto della pianta: i due codici dello stesso punto diventano la stessa posizione. Le posizioni del modello sono quindi 846, e ognuna può contenere un solo tipo di prodotto.
  3. *La posizione di partenza di ogni tipo di prodotto.* Nelle ondate di prelievo si prende il codice di posizione (tra quelli dei livelli 1 e 2) da cui il tipo di prodotto è stato prelevato più spesso, e lo si sostituisce con il suo punto.
  4. *I conflitti.* Se due tipi di prodotto finiscono nello stesso punto, lo tiene quello prelevato più spesso e l'altro va nel punto libero più vicino. Su 208 tipi di prodotto, 156 ottengono il proprio punto e 37 lo trovano già occupato da un tipo più prelevato. Gli altri 15 non hanno nessun prelievo in codici di posizione presenti nel file: vanno nel punto libero più vicino al deposito. È una scelta di comodo, e questi tipi compaiono nel 1.2% degli ordini.

  *Perché si può fare.* Per la distanza a piedi il livello non conta: i due codici dello stesso punto sono alla stessa distanza da tutte le altre posizioni. E il dataset non ha tempi che dicano se prelevare al livello 2 costa più che al livello 1.

  *Cosa si perde.* In realtà ogni punto può ospitare due tipi di prodotto, uno per ripiano, mentre nel modello ne ospita uno solo. Il modello ha quindi la metà delle posizioni di prelievo reali, e meno spazio libero in cui spostare i tipi di prodotto: un'ipotesi prudente, che tende a sottostimare il risparmio ottenibile.
* *Farmaceutico.* I livelli sono L01, L02, L03, L04 e L06: l'85,1% dei prelievi avviene a L01, il 10,5% a L02, il 4,0% a L03, lo 0,3% a L04 e 159 prelievi a L06. La durata mediana di un prelievo è 71 s a L01, 73 s a L02, 75 s a L03, 92 s a L04 e 80 s a L06. Il metodo ignora il livello: la distanza è quella della pianta e il punteggio non premia i livelli bassi, così il metodo resta identico nei due magazzini. L'effetto è piccolo, perché l'85% dei prelievi è già al livello più comodo. Un'estensione possibile è aggiungere al punteggio un termine che porta i tipi di prodotto più prelevati al livello 1.

**Tipi di prodotto e posizioni.**
* *Calzature: un tipo di prodotto in molte posizioni.* Le scatole di uno stesso modello sono sparse su molte posizioni (min 1, media 47, max 175 per tipo di prodotto), di solito una per taglia, dove c'era posto. Nel Notebook 4 abbiamo provato due rappresentazioni. Nella prima, a *posizione unica*, ogni tipo di prodotto è rappresentato dalla posizione da cui è prelevato più spesso, e un trasloco sposta il tipo intero. Nella seconda, a *posizioni multiple*, ogni tipo di prodotto è rappresentato dalle sue 12 posizioni più usate (circa il 70% dei suoi prelievi), e un trasloco sposta una singola scatola. Il risparmio è dello stesso ordine di grandezza, e la seconda rende di più per singolo trasloco. Il metodo principale (Notebook 5-8) usa la posizione unica, perché è la formulazione comune ai due magazzini e mantiene il problema trattabile; le posizioni multiple restano come verifica.
* *Farmaceutico: una posizione per tipo di prodotto, ma posizioni condivise.* Ogni tipo di prodotto sta in una sola posizione (i casi apparentemente diversi sono un errore di registrazione, sezione 3.4), ma una posizione contiene di solito più tipi di prodotto diversi, uno accanto all'altro nello stesso vano di scaffale: in mediana 2, in media 2,5, fino a 19 (la posizione LOC0490). La conseguenza pratica: per portare un tipo di prodotto in una posizione già occupata bisogna scambiarlo con uno dei tipi di prodotto che ci sono, perché quasi nessuna posizione ha spazio libero.

**Varianti.** Nelle calzature ogni modello esiste in più taglie (in media 12,4 per tipo di prodotto), e ogni riga d'ordine specifica la taglia. Nel farmaceutico non ci sono varianti.

**Quantità.**
* *Calzature.* Ogni riga d'ordine dice quante paia si prelevano, per esempio 6 paia del modello 8N10W9 in taglia 9 nell'ordine 124438.
* *Farmaceutico.* Ogni prelievo riporta due numeri: le *confezioni* prelevate, cioè le scatole prese dallo scaffale, e i *pezzi*, cioè le unità contenute in quelle confezioni (il dataset non dice di che unità si tratti: compresse, fiale, flaconi). Esempio: nel prelievo di ART0870 della transazione TRX18403 l'operatore ha preso 9 confezioni, per un totale di 180 pezzi, cioè 20 pezzi per confezione.

**Come usiamo le quantità.** Il metodo decide dove mettere i tipi di prodotto, e il percorso di un ordine dipende solo da quali posizioni visitare, non da quanti prodotti si prendono in ciascuna: prendere 1 o 6 paia dalla stessa posizione richiede lo stesso cammino. Per questo gli ordini sono insiemi di tipi di prodotto e le quantità non entrano né nel punteggio né nel giudice. Servono in due punti. Nelle statistiche descrittive. E nel farmaceutico per stimare quanto è voluminoso un tipo di prodotto: la mediana delle confezioni per prelievo, riportata su una scala da 0 a 1 (indice di ingombro). L'indice aumenta il costo di trasloco dei tipi più voluminosi: costo di un trasloco = κ · (0,5 + indice di ingombro), dove κ è il costo di riferimento (sezione 5.6). Nelle calzature l'indice è uguale per tutti.

**Tempi.** Nelle calzature non ci sono. Nel farmaceutico c'è la durata di ogni prelievo e il tempo di lavoro di ogni ordine.

**Giacenza.** Spostare un tipo di prodotto significa spostare tutta la sua merce, quindi la fatica di un trasloco dipende da quanta merce c'è sullo scaffale. Nessuno dei due dataset però registra la giacenza: sappiamo cosa esce, non cosa resta. Per esempio sappiamo che in dieci mesi sono uscite 190.700 confezioni del tipo di prodotto più prelevato, ma non se nella sua posizione ce ne sono 3 o 300. Per questo nel modello un trasloco costa lo stesso per tutti i tipi di prodotto, a parte l'indice di ingombro, mentre in realtà spostare un tipo con molta merce costa di più. È un limite che si risolve solo con una fotografia delle giacenze fornita dall'azienda.

**Letteratura.** Le calzature sono un dataset pubblico con tre lavori degli autori; il farmaceutico è privato e non permette confronti esterni.

**I dati in più di ciascun dataset, e se li usiamo.**

| Dato | Dataset | Che cos'è | Lo usiamo? |
|---|---|---|---|
| Tempi reali | farmaceutico | durata di ogni prelievo e tempo di ogni ordine | sì: distanza convertita in ore, prezzo del trasloco in secondi, validazione del giudice (sezione 6.4) |
| Sequenze reali di prelievo | farmaceutico | ordine cronologico in cui l'operatore ha preso i tipi di prodotto | sì: sezione 6.4 |
| Distanze a piedi con ostacoli | farmaceutico | distanza tra posizioni girando intorno agli scaffali | sì: giudice e punteggio |
| Istanza QAP | farmaceutico | problema di assegnazione già costruito | sì: confronto tra punteggi e punteggio `copicks_linear` (sezione 4) |
| Durata per livello di scaffale | farmaceutico | quanto costa prelevare a ogni livello | no: solo esplorazione (vedi livelli di scaffale) |
| Categorie merceologiche | farmaceutico | categoria e macro-categoria di ogni tipo di prodotto | no |
| Taglie | calzature | variante di ogni modello | solo nelle statistiche: gli ordini accorpano le taglie dello stesso modello |
| Ondate di prelievo | calzature | gruppi di ordini prelevati in un giro unico, con la posizione di ogni prelievo | solo per ricavare la posizione attuale di ogni tipo di prodotto; il giudice usa gli ordini dei clienti |
| Disposizioni delle politiche statiche (`Random_Storage.csv`, `Class_Based_Storage.csv`, `Dedicated_Storage.csv`, `Hybrid_Storage.csv`) | calzature | per ogni posizione, fino a 18 scatole (tipo di prodotto e taglia) assegnate da ciascuna delle quattro politiche statiche studiate dagli autori | sì: confronto esterno con il nostro giudice (sezione 6.5) |
| Punti di navigazione (`Support_Points_Navigation.csv`) | calzature | 44 punti su 3 corridoi principali (x = 66, 403 e 686 unità; quello di destra solo da y = 631, perché il magazzino è a L), attraversati dai corridoi trasversali alle y dei punti; il punto centrale a y = −29 è il deposito | sì: calcolo della distanza lungo i corridoi reali, per verificare i risultati (sezione 6.5); l'ottimizzazione usa ancora la somma degli spostamenti |

### 3.3 Normalizzazione

Ogni dataset ha un adattatore (`data.py`) che produce lo stesso oggetto, e da lì in poi il metodo non sa da quale magazzino arrivano i dati. L'oggetto contiene:
* i tipi di prodotto;
* le distanze tra posizioni e dal deposito;
* la capacità di ogni posizione;
* la disposizione attuale, una posizione per tipo di prodotto;
* un indice di ingombro per il costo del trasloco;
* gli ordini come insiemi di tipi di prodotto distinti, con data e mese;
* quali tipi di prodotto si possono spostare;
* se disponibile, il modello dei tempi.

I formati di un nuovo magazzino si riducono a queste voci. Gli ordini a uno o due livelli diventano insiemi di tipi di prodotto dello stesso giro. Coordinate, pianta a quadrati, matrice o grafo di navigazione diventano una matrice di distanze a piedi. Tipi di prodotto sparsi, unici o condivisi diventano una posizione principale più una capacità per posizione. Le quantità entrano solo nell'indice di ingombro. I tempi, se ci sono, servono per le ore e per il prezzo del trasloco. Per un nuovo magazzino basta scrivere un adattatore.

### 3.4 Un errore di registrazione nel dataset farmaceutico: 76 tipi di prodotto in più posizioni

**Cosa si osserva.** Nel file `slotting_attuale.csv` 76 tipi di prodotto su 2.385 (3,2%) risultano stoccati in più posizioni: 74 in due posizioni, 2 in tre. A prima vista sembrerebbe merce divisa tra più scaffali, come nelle calzature.

**Perché è un errore di registrazione e non merce divisa.** Ogni volta che uno di questi tipi di prodotto viene prelevato, il file dei prelievi riporta una riga per ciascuna delle sue posizioni: succede in tutti i 4.654 ordini che li contengono. Nel 95% dei casi le righe gemelle hanno lo stesso istante di inizio, la stessa quantità e la stessa durata. Esempio: il tipo di prodotto ART1801 compare in 16 ordini, sempre nelle due posizioni LOC0097 (livello 2) e LOC1056 (livello 3); nella transazione TRX08907 entrambe le righe dicono 180 pezzi, 6 confezioni, 254 secondi. Un operatore non può prelevare lo stesso prodotto in due posizioni nello stesso istante: è la stessa operazione scritta due volte. La spiegazione più probabile è che l'anagrafica associ a questi tipi di prodotto due posizioni, una di prelievo e una di scorta a livelli diversi, e che l'estrazione dei dati abbia prodotto una riga per ciascuna. La spiegazione andrebbe confermata con l'azienda.

**Quanto pesa.** Le righe duplicate sono 5.176 su 441.190 (1,17%). I 76 tipi di prodotto sono quasi tutti poco prelevati: mediana 9 ordini in dieci mesi, con un solo tipo prelevato spesso (2.092 ordini).

**Come lo gestiamo.** Tre accorgimenti, tutti già nel codice.
1. *Ordini corretti.* Ogni ordine è l'insieme dei tipi di prodotto distinti che contiene, quindi le due righe dello stesso tipo nello stesso ordine diventano una sola.
2. *Una posizione di partenza per tipo di prodotto.* Usiamo quella indicata dall'istanza del dataset (`assegnazione_attuale.csv`). Per questi 76 tipi le posizioni gemelle hanno la stessa quota di prelievi (50% ciascuna, perché ogni prelievo compare in entrambe), quindi la scelta tra le due è arbitraria. Se è caduta sulla posizione di scorta, la distanza di partenza di quel tipo è leggermente sbagliata: per tipi così poco prelevati l'effetto sul totale è trascurabile.
3. *Co-prelievi corretti.* Le dipendenze tra tipi di prodotto le calcoliamo dagli ordini corretti, non dalla matrice F dei co-prelievi tra posizioni fornita nell'istanza. F è costruita dalle righe grezze, quindi conta ogni prelievo di questi tipi come un co-prelievo tra le loro due posizioni gemelle, che non esiste: nel nostro calcolo questo errore non entra.

## 4. Il punteggio che guida la ricerca: la modellazione a matrici del dataset e la nostra

**Perché conta.** Il greedy e la rete, a ogni mossa, confrontano molte disposizioni candidate. Per farlo usano il punteggio, una formula istantanea; il giudice, cioè il calcolo dei percorsi veri, interviene solo alla fine. Se il punteggio premia le disposizioni sbagliate, la ricerca va nella direzione sbagliata. Questa sezione confronta due punteggi e misura quanto il risultato dipende dai loro pesi.

### 4.1 La modellazione a matrici inclusa nello zip

Nello zip non c'è codice. C'è la cartella `istanza_qap`: un problema di assegnazione quadratica (QAP) già costruito. Contiene quattro oggetti:
* D, le distanze a piedi tra le 972 posizioni;
* F, i co-prelievi tra posizioni: F tra due posizioni è il numero di ordini in cui si preleva da entrambe;
* le distanze dal deposito;
* la disposizione attuale.

L'indice che definiscono è quello classico: la somma, su tutte le coppie di posizioni, dei co-prelievi per la distanza, più per ogni posizione i suoi prelievi per la distanza dal deposito. L'unità che si sposta è il contenuto di un'intera posizione. Sui 76 tipi di prodotto registrati in due posizioni, e sull'errore che questo introduce in F, vedi la sezione 3.4.

### 4.2 I due punteggi

Entrambi i punteggi si calcolano su una matrice con una riga e una colonna per ogni tipo di prodotto.
* Fuori dalla diagonale c'è, per ogni coppia di tipi di prodotto, il peso della coppia moltiplicato per la distanza tra le loro posizioni, più eventualmente un termine incrociato: γ volte le loro distanze dal deposito.
* Sulla diagonale c'è, per ogni tipo di prodotto, β volte la sua popolarità per la sua distanza dal deposito.

Il punteggio è la somma degli elementi della matrice (forma lineare) o dei loro quadrati. Più è basso, migliore è la disposizione. Nel codice i due punteggi hanno i nomi indicati tra parentesi.

| | Punteggio a regole di associazione, quadratico (`rules_squared`) | Punteggio a co-prelievi, lineare (`copicks_linear`) |
|---|---|---|
| Origine | il punteggio dei Notebook 1-6 | l'indice dell'istanza del dataset, riscritto per tipo di prodotto |
| Peso di una coppia di tipi di prodotto | α · confidenza + (1 − α) · supporto delle regole di associazione trovate da FP-Growth, con α = 0,7 | numero di ordini in cui i due tipi di prodotto compaiono insieme (co-prelievi grezzi) |
| Forma | somma dei quadrati: pesa di più i termini grandi, cioè i tipi di prodotto peggio collocati | somma lineare: ogni termine pesa quanto la distanza che rappresenta |
| Peso del deposito β | 5 | 2 |
| Termine incrociato γ | 0,3 | 0 |

Il *supporto* di una coppia è la quota degli ordini che la contengono. La *confidenza* è la probabilità che un ordine con il primo tipo di prodotto contenga anche il secondo. Una coppia rara ma sempre prelevata insieme ha supporto basso e confidenza alta.

L'istanza originale sposta il contenuto di un'intera posizione, noi un singolo tipo di prodotto. Il confronto resta esatto, perché l'indice dell'istanza si riscrive coppia per coppia di tipi di prodotto.

**Da dove vengono i numeri.** Nessuno dei valori di `rules_squared` era stato calibrato prima di questa analisi (sezione 4.4).
* α = 0,7 è stato fissato nel Notebook 1. Il mix tra confidenza e supporto era stato introdotto come unico iperparametro della matrice delle dipendenze, e il valore è stato scelto a mano per dare più peso alla confidenza.
* γ = 0,3 e β = 5 sono stati introdotti a mano nel Notebook 3. β serve a impedire che la ricerca porti lontano dal deposito interi gruppi di tipi di prodotto prelevati insieme.

In `copicks_linear`, invece, β = 2 e γ = 0 non sono scelte: riproducono l'indice dell'istanza. Con β = 2 ogni prelievo pesa la sua distanza dal deposito una volta. Per un ordine con due tipi di prodotto, la formula è esattamente la lunghezza del suo percorso: deposito, primo, secondo, deposito.

### 4.3 Il confronto, e come leggere le percentuali

**Esperimento.** Stesso greedy, stessa finestra di dati (i primi tre mesi), stessi budget, tre semi; cambia solo il punteggio ottimizzato. Ogni disposizione trovata è giudicata con i percorsi veri dei due mesi successivi.

**Come leggere le percentuali.** Il *risparmio lordo* è la quota della distanza camminata nei due mesi giudicati che la nuova disposizione risparmia rispetto a quella attuale. Più alto è meglio: 50% vuol dire metà del cammino, 0% nessun miglioramento, un valore negativo una disposizione peggiore di oggi. I valori dei due magazzini non si confrontano tra loro in assoluto: dipendono da quanto è mal disposto il magazzino di partenza e da quanta parte dei tipi di prodotto il budget permette di spostare.

| Risparmio lordo (più alto è meglio), media su 3 semi | `rules_squared` | `copicks_linear` |
|---|---|---|
| Calzature, K = 10 | 5,0% | 1,4% |
| Calzature, K = 30 | 16,7% | 10,8% |
| Calzature, K = 90 | 50,4% | 32,8% |
| Calzature, K = 150 | 69,3% | 58,9% |
| Farmaceutico, K = 30 | 0,8% | 1,2% |
| Farmaceutico, K = 90 | 1,8% | 3,6% |
| Farmaceutico, K = 150 | 2,8% | 5,4% |
| Farmaceutico, K = 300 | 4,0% | 7,5% |

Un secondo indicatore dice quanto ciascun punteggio ordina le disposizioni come il giudice, su tutte le disposizioni prodotte più quattro disposizioni casuali: è la correlazione di Spearman, dove 1 significa lo stesso ordine e più alto è meglio. Nelle calzature vale 0,97 per `rules_squared` e 0,92 per `copicks_linear`; nel farmaceutico 0,84 e 0,95.

**Lettura.** Con i pesi indicati nella tabella 4.2, `rules_squared` vince nelle calzature e `copicks_linear` vince nel farmaceutico, dove risparmia quasi il doppio. La sezione 4.4 mostra però che, nelle calzature, il divario non dipende dalla forma dei due punteggi ma dal peso del deposito.

### 4.4 Quanto contano i pesi: analisi di sensibilità

**Esperimento.** Stesso greedy, budget 90 nelle calzature e 150 nel farmaceutico, due semi, stessi due mesi giudicati. Si fanno variare:
* β: 0, 1, 2, 5, 10, 20;
* γ: 0 oppure 0,3;
* per `rules_squared`, α: 0,3, 0,7, 1, con β = 5 e γ = 0,3.

I numeri sono risparmi lordi, più alto è meglio. Tra i due semi le differenze arrivano fino a 4 punti nelle calzature (di solito 1-2) e restano di solito sotto 0,5 punti nel farmaceutico: scarti più piccoli non vanno letti come differenze reali.

Calzature (budget 90):

| | β = 0 | β = 1 | β = 2 | β = 5 | β = 10 | β = 20 |
|---|---|---|---|---|---|---|
| `rules_squared`, γ = 0,3 (valori attuali) | 16,9% | 26,0% | 42,2% | 51,2% | 51,3% | 48,7% |
| `rules_squared`, γ = 0 | −2,2% | 24,3% | 46,2% | 52,8% | 48,2% | 50,0% |
| `copicks_linear`, γ = 0 (valori attuali con β = 2) | 2,2% | 17,8% | 35,3% | 52,5% | 51,7% | 48,8% |
| `copicks_linear`, γ = 0,3 | 23,6% | 50,9% | 51,1% | 49,1% | 51,0% | 49,9% |

Farmaceutico (budget 150):

| | β = 0 | β = 1 | β = 2 | β = 5 | β = 10 | β = 20 |
|---|---|---|---|---|---|---|
| `rules_squared`, γ = 0,3 (valori attuali) | 2,8% | 2,5% | 2,6% | 2,7% | 3,1% | 0,9% |
| `rules_squared`, γ = 0 | 2,0% | 2,0% | 1,8% | 2,7% | 1,9% | 1,9% |
| `copicks_linear`, γ = 0 (valori attuali con β = 2) | 5,0% | 4,8% | 5,3% | 5,7% | 5,6% | 5,0% |
| `copicks_linear`, γ = 0,3 | 4,7% | 4,6% | 5,1% | 5,0% | 4,8% | 5,7% |

Effetto di α in `rules_squared` (β = 5, γ = 0,3):

| | α = 0,3 | α = 0,7 (attuale) | α = 1 |
|---|---|---|---|
| Calzature | 51,9% | 51,2% | 50,8% |
| Farmaceutico | 4,0% | 2,7% | 1,3% |

**Lettura.**
1. *β è il peso che conta, e β = 5 è un buon valore.* Nelle calzature, senza termine del deposito `rules_squared` risparmia il 17%. Con β tra 5 e 10 raggiunge un plateau intorno al 51%, e a β = 20 cala leggermente. Il valore scelto a mano, 5, sta sul plateau. Il motivo: il 73% degli ordini contiene un solo tipo di prodotto, e per questi ordini conta solo la distanza dal deposito. Nel farmaceutico β conta poco per entrambi i punteggi.
2. *Nelle calzature il divario della sezione 4.3 è dovuto a β, non alla forma.* Con β = 2, il valore dell'istanza, `copicks_linear` risparmia il 35%. Con β = 5 risparmia il 52,5%, quanto `rules_squared` (51,2%, dentro la variabilità tra semi). β = 2 è troppo basso quando la maggior parte degli ordini ha un solo tipo di prodotto: per questi ordini il percorso vale due volte la distanza dal deposito (andata e ritorno), mentre β = 2 la conta una volta sola.
3. *γ conta poco; α conta nel farmaceutico.* γ = 0,3 non migliora mai su γ = 0 in modo netto. α cambia il risultato di circa un punto nelle calzature, ma nel farmaceutico meno confidenza è meglio: 4,0% con α = 0,3 contro 1,3% con α = 1. La confidenza sovrappesa le coppie rare sempre prelevate insieme, che in questo magazzino valgono poco cammino.

**Conseguenza: un solo punteggio può servire entrambi i magazzini.** Il punteggio con co-prelievi grezzi, somma lineare, β = 5 e γ = 0:
* risparmia il 52,5% nelle calzature, contro il 51,2% di `rules_squared`;
* è la variante migliore nel farmaceutico, con il 5,7%;
* elimina due dei quattro numeri non appresi dai dati, α e γ; resta β = 5, che sta sul plateau in entrambi i magazzini.

I notebook usano ancora `rules_squared` per le calzature e `copicks_linear` con β = 2 per il farmaceutico, perché tutti i risultati di questo documento sono calcolati con essi. L'adozione del punteggio unico va confermata a scala piena (sezione 10). Il limite di questa analisi: greedy, un solo budget per magazzino, due semi.

### 4.5 Cosa è cambiato nel codice

* Il punteggio si sceglie con un solo parametro, `SURROGATE = "rules_squared"` oppure `"copicks_linear"`. Lo usano greedy, rete, protocollo nel tempo e scelta del budget, con una cache separata per dataset e punteggio. I calcoli incrementali sono verificati esatti per entrambe le forme.
* I notebook contengono il confronto della sezione 4.3 (loro sezione 3.1), le quattro varianti del punteggio (3.2) e l'analisi di sensibilità (3.3).
* Non è implementata l'idea di spostare interi contenuti di posizione: sarebbe un'alternativa di mosse per le posizioni condivise.

## 5. Statistiche dei due magazzini

**Cosa c'è in questa sezione.** Le statistiche descrittive dei due dataset, divise per tema: quanto sono grandi il magazzino e il catalogo, come sono fatti gli ordini, come si distribuisce la domanda tra i tipi di prodotto, quanto cambia nel tempo, e i tempi. Ogni riga è spiegata dove non è ovvia. In chiusura, le semplificazioni che il metodo adotta su ciascun dataset.

**I tre messaggi principali.**
1. *Il farmaceutico è molto più grande e con ordini molto più ricchi*: 11 volte più tipi di prodotto, 7 tipi di prodotto per ordine contro 1,9. Nelle calzature conta soprattutto avvicinare i tipi di prodotto più venduti al deposito; nel farmaceutico conta avvicinare tra loro i tipi di prodotto che finiscono negli stessi ordini.
2. *Nelle calzature la domanda è concentrata su pochi tipi di prodotto, nel farmaceutico è distribuita su molti*: nelle calzature i 20 tipi più venduti fanno metà dei prelievi, nel farmaceutico un quinto.
3. *Nel farmaceutico la domanda cambia meno nel tempo*: i tipi più venduti e le coppie più frequenti restano più simili da un mese all'altro, e i volumi mensili variano meno.

### 5.1 Dimensioni del magazzino e del catalogo

| | Calzature | Farmaceutico |
|---|---|---|
| Periodo | gen-ott 2023, 10 mesi | ott 2017-lug 2018, 10 mesi (luglio parziale, escluso dalla valutazione) |
| Dimensioni del magazzino | 109 x 44 m | pianta di 118 x 63 quadrati, di cui 5.021 percorribili |
| Tipi di prodotto | 208 | 2.385 |
| Varianti per tipo di prodotto | taglie: min 1, media 12,4, max 21 | nessuna |
| Posizioni | 2.292 su 4 livelli; nel modello 846 (livelli 1 e 2 fusi, vedi 3.2) | 1.430 nella pianta, di cui 972 usate nei prelievi |
| Posizioni occupate da un tipo di prodotto | min 1, media 47, max 175 | 1 (vedi 3.4) |
| Tipi di prodotto contenuti in una posizione | 1 nel modello | min 1, media 2,53, max 19 |
| Giacenza (prodotti sugli scaffali) | non registrata | non registrata |

### 5.2 Gli ordini

| | Calzature | Farmaceutico |
|---|---|---|
| Ordini | 32.634 ordini di clienti | 58.616 giri di prelievo |
| Prelievi | 215.192 | 441.190 righe, di cui 5.176 duplicate (3.4): 436.014 prelievi reali |
| Tipi di prodotto per ordine | min 1, media 1,88, max 37 | min 1, media 6,99, max 45 |
| Ordini con un solo tipo di prodotto | 73% | 29% |
| Prodotti per ordine | min 0, mediana 2, media 7,0, max 2.400 paia | min 0, mediana 16, media 50,9, max 8.005 confezioni |
| Prodotti prelevati in dieci mesi | 228.195 paia | 2.986.118 confezioni |
| Prodotti prelevati per tipo di prodotto in dieci mesi | min 1, mediana 310, media 1.097, max 18.070 paia | min 1, mediana 70, media 1.252, max 190.700 confezioni |

Gli ordini con 0 prodotti sono casi limite presenti nei dati: 2 ordini con 0 paia nelle calzature, e nel farmaceutico lo 0,2% dei prelievi di pezzi sfusi, meno di una confezione intera. Gli ordini molto grandi delle calzature (fino a 2.400 paia) sono ordini all'ingrosso di negozi.

### 5.3 Come si distribuisce la domanda tra i tipi di prodotto

La *concentrazione* dice quanta parte dei prelievi fanno i tipi di prodotto più venduti. Le *coppie co-prelevate* dicono quante coppie di tipi di prodotto finiscono spesso negli stessi ordini: sono le dipendenze che il punteggio usa per avvicinare tra loro i tipi di prodotto.

| | Calzature | Farmaceutico |
|---|---|---|
| Quota dei prelievi dei 20 tipi di prodotto più venduti | 49% | 20% |
| Quota dei prelievi dei 100 più venduti | 94% | 53% |
| Quota dei prelievi dei 586 più venduti (quelli spostabili nel farmaceutico) | tutti (i tipi sono 208) | 70% |
| Coppie di tipi di prodotto presenti insieme in almeno 1 ordine | 5.991 | 300.746 |
| ... in almeno 20 ordini | 1.130 | 30.440 |
| ... in almeno 100 ordini | 234 | 5.367 |
| Numero di ordini della coppia più frequente | 853 | 3.677 |

### 5.4 Come cambia la domanda nel tempo

Due misure, calcolate mese per mese.
* *Stabilità dei tipi più venduti.* Per ogni mese si conta in quanti ordini compare ciascun tipo di prodotto e si confronta questo elenco di conteggi con quello del primo mese, con la similarità del coseno: 1 significa stessa composizione della domanda, 0 nessuna sovrapposizione.
* *Stabilità delle coppie.* Per ogni mese si prendono le 50 coppie di tipi di prodotto presenti insieme nel maggior numero di ordini, e si confrontano mesi consecutivi: coppie in comune divise per coppie totali (indice di Jaccard). 1 significa le stesse 50 coppie, 0 nessuna in comune.

| | Calzature | Farmaceutico |
|---|---|---|
| Stabilità dei tipi più venduti | min 0,76, media 0,81 | min 0,87, media 0,92 |
| Stabilità delle coppie | min 0,49, media 0,62, max 0,72 | min 0,56, media 0,72, max 0,85 |
| Ordini al mese | da 2.319 (ottobre) a 4.670 (febbraio) | da 5.613 a 7.400 nei mesi interi |

### 5.5 Tempi

Solo nel farmaceutico: la durata di un prelievo ha mediana 72 s, il tempo di lavoro di un ordine ha mediana 361 s. Il cammino è il 29% del tempo totale (modello fornito nel dataset, confermato dalla sezione 6.4).

### 5.6 Semplificazioni adottate

* *Calzature.*
  * Solo i livelli di scaffale 1 e 2, fusi in 846 posizioni (3.2).
  * Distanza tra posizioni = somma degli spostamenti orizzontale e verticale; i risultati sono verificati anche con la distanza lungo i corridoi reali (6.5).
  * Ogni tipo di prodotto è rappresentato dalla posizione da cui è prelevato più spesso; la versione a posizioni multiple è stata provata nel Notebook 4 (3.2). La posizione attuale si ricava dai prelievi delle ondate, usando solo quelli con un codice di posizione presente nel file delle posizioni.
  * Un giro per ogni ordine del cliente, senza raggruppamento in ondate (3.2).
  * Indice di ingombro uguale per tutti, perché il dataset non dà le dimensioni delle scatole.
  * Costo di riferimento di un trasloco κ = 60.000 unità di distanza, per convenzione circa un'ora di manodopera.
* *Farmaceutico.*
  * Esclusa l'unica posizione assente dalla pianta; il suo tipo di prodotto è ricollocato nella sua posizione mappata più usata.
  * Righe duplicate e posizione di partenza dei 76 tipi di prodotto gestite come in 3.4.
  * Luglio 2018 escluso dalla valutazione perché parziale.
  * Spostabili solo i 586 tipi di prodotto con almeno 100 prelievi (70% dei prelievi); gli altri restano fermi ma contano nel punteggio.
  * Capacità di ogni posizione pari alla sua occupazione attuale, quindi un trasloco è uno scambio.
  * Livello di scaffale ignorato (3.2).
  * Costo di riferimento di un trasloco κ = 142 secondi (due manipolazioni misurate), pari a 260 unità di distanza.
* *Entrambi.* Senza giacenza il costo di un trasloco non cresce con la merce spostata (3.2).

## 6. I nuovi esperimenti (modalità QUICK)

### 6.1 Rollout incrementale contro rifacimento da capo

**La domanda.** Spostare pochi tipi di prodotto ogni mese rende quanto rifare la riorganizzazione da capo ogni mese? I due protocolli si confrontano con lo stesso ottimizzatore:
* *incrementale*: una riorganizzazione iniziale con budget K₀, poi un ritocco al mese con budget Kₘ (calzature 90 e 10, farmaceutico 150 e 20);
* *da capo*: K₀ a ogni mese.

I mesi di valutazione sono 7 nelle calzature (da aprile a ottobre 2023) e 6 nel farmaceutico (da gennaio a giugno 2018). Il costo di un trasloco è un'ora di manodopera nelle calzature (60.000 unità di distanza, per convenzione) e 142 secondi nel farmaceutico (due manipolazioni misurate, 260 unità di distanza).

**Come leggere la tabella.**
* *Traslochi per intervento*: quanti tipi di prodotto hanno cambiato posizione in ciascun intervento, in ordine di tempo. Il primo numero è la riorganizzazione iniziale, gli altri i ritocchi mensili; tra parentesi il totale.
* *Risparmio lordo*: quota della distanza camminata nei mesi di valutazione che si risparmia rispetto a non riorganizzare mai. Più alto è meglio.
* *Netto*: distanza risparmiata meno il costo di manodopera dei traslochi, anch'esso in unità di distanza. Positivo vuol dire che la riorganizzazione si ripaga, negativo che costa più di quanto fa risparmiare. Più alto è meglio. Nel farmaceutico è riportato anche in ore di lavoro (0,548 secondi per unità di distanza).
* *Distanza risparmiata per trasloco*: distanza risparmiata divisa per il numero totale di traslochi. Misura l'efficienza: più alto è meglio.

**Perché alcuni totali sono sotto il massimo.** Il budget è un tetto: in un intervento si possono spostare al più K tipi di prodotto, non esattamente K.
* Il greedy restituisce la migliore disposizione incontrata durante la ricerca, che può essere stata raggiunta prima di usare tutto il budget. Succede nel primo ritocco del farmaceutico (17 traslochi su 20) e nell'ultimo mese delle calzature da capo (89 su 90).
* La rete, dentro una partita, può spostare più volte lo stesso tipo di prodotto o riportarlo nella posizione di partenza, e queste mosse non consumano budget. Succede in agosto nelle calzature (9 su 10) e nel terzo mese del farmaceutico da capo (149 su 150).

Le differenze sono di uno o pochi traslochi e non cambiano le conclusioni.

Calzature (modalità QUICK; a scala piena la rete batte il greedy del 12% di netto, sezione 1):

| Protocollo | Traslochi per intervento (totale) | Risparmio lordo | Netto | Distanza risparmiata per trasloco |
|---|---|---|---|---|
| Greedy, incrementale (90 + 10 al mese) | 90, 10, 10, 10, 10, 10, 10 (150) | +58,2% | +21,7 milioni di unità | 204.411 unità |
| Greedy, da capo (90 ogni mese) | 90, 90, 90, 90, 90, 90, 89 (629) | +67,3% | −2,3 milioni di unità | 56.283 unità |
| Rete, incrementale (90 + 10 al mese) | 90, 10, 10, 10, 9, 10, 10 (149) | +49,7% | +17,2 milioni di unità | 175.495 unità |
| Rete, da capo (90 ogni mese) | 90, 90, 90, 90, 90, 90, 90 (630) | +60,1% | −6,1 milioni di unità | 50.246 unità |

Farmaceutico (modalità QUICK, punteggio `copicks_linear`):

| Protocollo | Traslochi per intervento (totale) | Risparmio lordo | Netto | Distanza risparmiata per trasloco |
|---|---|---|---|---|
| Greedy, incrementale (150 + 20 al mese) | 150, 17, 20, 20, 20, 20 (247) | +5,6% | +668 mila unità (+102 ore) | 2.881 unità |
| Greedy, da capo (150 ogni mese) | 150, 150, 150, 150, 150, 150 (900) | +8,2% | +884 mila unità (+135 ore) | 1.160 unità |
| Rete, incrementale (150 + 20 al mese) | 150, 20, 20, 20, 20, 20 (250) | +4,8% | +565 mila unità (+86 ore) | 2.438 unità |
| Rete, da capo (150 ogni mese) | 150, 150, 149, 150, 150, 150 (899) | +8,2% | +887 mila unità (+135 ore) | 1.163 unità |

**Lettura.**
* *Calzature: l'incrementale vince nettamente.* Il rifacimento da capo risparmia 9-10 punti di distanza in più, ma con 4,2 volte i traslochi: ogni trasloco rende circa un quarto. Non sposta meglio, sposta di più, e a un'ora per trasloco il netto diventa negativo.
* *Farmaceutico: il risultato è opposto, per il prezzo del trasloco.* L'incrementale resta più efficiente: ogni trasloco rende circa 2,5 volte di più. Ma un trasloco costa solo 142 secondi, quindi spostarne molti di più conviene anche se ciascuno rende meno. Il rifacimento da capo guadagna circa 135 ore di netto, contro 86-102 dell'incrementale.
* *La conclusione non è "rifare da capo".* Il budget mensile di 20 è troppo basso per questo magazzino. La tecnica di scelta del budget (6.2) indica per il singolo mese un budget ottimo di 334. L'esperimento giusto è l'incrementale con il budget mensile scelto dalla bisezione, contro il rifacimento da capo (sezione 10).
* *Rete sotto il greedy in QUICK.* Con 40 iterazioni la rete è sotto il greedy in entrambi i magazzini; a scala piena, sulle calzature, lo supera del 12%.

### 6.2 Scelta del budget con tecniche economiche

**Le quattro tecniche.**
1. *Provarli tutti*: una riorganizzazione per ogni K di un elenco fisso (0, 5, 10, 20, ... fino a tutti i tipi spostabili), ciascuna giudicata con i percorsi veri. È il riferimento costoso.
2. *Bisezione sul guadagno marginale*: si parte dall'intervallo tra 0 e tutti i tipi spostabili. Nel punto medio si confronta il netto con K e con K più un piccolo passo, e si tiene la metà in cui conviene proseguire. Servono circa log₂ n passi, cioè circa 10 riorganizzazioni con n = 208 o 586.
3. *Sezione aurea.* Serve a trovare il massimo di una curva che sale, raggiunge un massimo e poi scende, valutandola il meno possibile. Si tiene un intervallo di budget che contiene di sicuro il massimo, all'inizio da 0 a n, e al suo interno si valutano due budget: uno a circa il 38% della lunghezza e uno a circa il 62%. Se il netto è più alto nel punto a destra, il massimo non può trovarsi prima del punto a sinistra, e quel primo tratto si scarta; altrimenti si scarta l'ultimo tratto, dopo il punto a destra. Il nuovo intervallo è lungo il 62% del precedente. Con queste proporzioni (il rapporto aureo) il punto già valutato che resta nel nuovo intervallo cade esattamente dove serve uno dei due nuovi punti interni: a ogni passo basta una sola riorganizzazione nuova. Esempio con n = 208: si valutano K = 79 e K = 129; se il netto a 129 è più alto, il nuovo intervallo va da 79 a 208, e i suoi punti interni sono 129 (già valutato) e 159 (l'unica riorganizzazione nuova); e così via. Dopo 8-9 passi, cioè circa 10 riorganizzazioni in tutto, l'intervallo si riduce a pochi tipi di prodotto. La bisezione, per sapere se la curva sale o scende, a ogni passo valuta due budget vicini; la sezione aurea confronta invece due punti lontani, e a ogni passo ne valuta uno solo.
4. *Stima K̂, senza riorganizzazioni*: per ogni tipo di prodotto spostabile si calcola quanto migliorerebbe il punteggio con un solo trasloco nella posizione migliore. Il miglioramento si converte in distanza con una sola valutazione pilota, e si conta per quanti tipi di prodotto il guadagno supera il costo del trasloco. Ingressi: pesi del punteggio, popolarità, disposizione attuale, costo. Il tempo passato dall'ultima riorganizzazione entra attraverso il disallineamento della disposizione.

"Orizzonte intero" = una sola riorganizzazione giudicata su tutti i mesi di valutazione; "un mese" = giudicata sul mese successivo. Risultati con il greedy.

| | K migliore (netto) | Elenco fisso | Bisezione | Sezione aurea | Stima K̂ |
|---|---|---|---|---|---|
| Calzature, orizzonte intero | 187 (27,8 milioni) | 208, perde 2,1%; 8 riorganizzazioni, 10 s | 187, perde 0% | 178, perde 0,8% | 115, perde 7%; 0,5 s |
| Calzature, un mese | nessun K si ripaga entro il mese | | | | |
| Farmaceutico, orizzonte intero | 586 (761 mila, circa 116 ore) | 586, perde 0%; 10 riorganizzazioni, 105 s | 293, perde 15% | 367, perde 0,7% | 546, perde 5%; 1,5 s |
| Farmaceutico, un mese | 334 (125 mila, circa 19 ore) | 586, perde 8%; 10 riorganizzazioni, 25 s | 334, perde 0% | 505, perde 5% | 424, perde 15%; 1,5 s |

**Lettura.**
* Nessuna tecnica economica vince sempre, ma quelle logaritmiche e la stima K̂ restano quasi sempre entro il 15% dell'ottimo. Costano una decina di riorganizzazioni o nessuna, invece di una per ogni valore.
* Raccomandazione: K̂ come stima immediata, bisezione come raffinamento.
* Con la rete la curva costa una valutazione per K e nessun riaddestramento, perché il budget non è un ingresso della rete (entra come vincolo e come durata della partita).
* Nelle calzature, con un'ora per trasloco, un ritocco non si ripaga nel mese stesso ma sui mesi successivi. Il budget di riferimento resta 90, ma il netto sull'orizzonte cresce fino a circa 120: va verificato a scala piena.
* Nel farmaceutico, sull'orizzonte intero, conviene spostare tutti i 586 tipi spostabili: il budget diventa un vincolo operativo (quanto disturbo tollera il magazzino), non economico.

### 6.3 Costo computazionale dell'intera soluzione

n = numero di tipi di prodotto, c = posizioni candidate valutate per mossa (circa 30), m = ordini, t = tipi di prodotto per ordine (al massimo 37 e 45).

| Componente | Costo | Calzature (n = 208) | Farmaceutico (n = 2.385) |
|---|---|---|---|
| Pesi del punteggio da una finestra di ordini (solo coppie) | proporzionale a m · t², lineare nei dati | 0,3 s | 0,5 s |
| Preparazione del punteggio a inizio intervento | n², una volta per intervento | trascurabile | frazioni di secondo |
| Una mossa | c · n | 1,3 ms | 1,6 ms |
| Una riorganizzazione del greedy (1.000-1.500 mosse) | mosse · c · n | circa 2 s | circa 2-3 s |
| Una iterazione di addestramento della rete | partite · mosse · (c · n + rete) | circa 2 s | circa 8 s |
| Giudice su un mese di ordini (percorso più corto con euristica 2-opt) | m · t² per passata di miglioramento | meno di 0,1 s | circa 0,7 s |
| Budget: stima K̂ | c · n² più un ordinamento, nessuna riorganizzazione | 0,5 s | 1,5-1,9 s |
| Budget: bisezione | circa log₂ n riorganizzazioni | circa 10 | circa 10 |

Nessun passo ha costo esponenziale. FP-Growth è limitato alle coppie. Il percorso più corto usa un'euristica polinomiale e non la soluzione esatta. La scelta del budget richiede al più una decina di riorganizzazioni.

Il costo di una mossa passa da 1,3 a 1,6 ms moltiplicando i tipi di prodotto per 11, perché le somme per riga del punteggio si aggiornano in modo incrementale.

Resta quadratica solo la memoria delle matrici dense tipo per tipo, che oggi è irrilevante. Sono quasi vuote: 2.098 coppie non nulle nelle calzature e 31.136 nel farmaceutico, su 43 mila e 5,7 milioni possibili. Per magazzini con decine di migliaia di tipi di prodotto basterebbero matrici sparse.

### 6.4 Le sequenze reali di prelievo (farmaceutico)

Il file `liste_prelievo.csv` dà, per ogni ordine, i tipi di prodotto nell'ordine cronologico in cui l'operatore li ha prelevati, con il tempo di lavoro misurato. Sulla disposizione attuale calcoliamo per ogni ordine due lunghezze. La *lunghezza percorsa* segue la sequenza reale: deposito, posizioni in quell'ordine, deposito. La *lunghezza minima* è quella del percorso più corto calcolato dal giudice sulle stesse posizioni. Tre domande, tre risposte.

**Gli operatori seguono il percorso più corto?** Spesso, non sempre. Il rapporto tra lunghezza percorsa e lunghezza minima ha mediana 1,00, media 1,16 e 90° percentile 1,53. Nel 57% degli ordini il percorso reale è entro l'1% del più corto. Sull'insieme dei 58.616 ordini, però, gli operatori camminano il 24,6% in più del necessario, perché una minoranza di ordini è sequenziata molto male. Ordinare le liste di prelievo secondo il percorso più corto potrebbe quindi risparmiare fino a circa un quinto del cammino, indipendentemente da qualunque riorganizzazione. È un limite superiore: alcune sequenze possono avere ragioni pratiche (prodotti pesanti per primi, fragili per ultimi) che i dati non registrano.

**Il giudice misura bene il lavoro?** Sì. Insieme al numero di prelievi, la lunghezza minima spiega i tempi misurati quasi quanto la lunghezza realmente percorsa: R² 0,751 contro 0,755. La correlazione con il tempo è 0,76 per la lunghezza minima, 0,82 per quella percorsa, 0,86 per il numero di prelievi. La regressione stima 83 secondi per prelievo e 0,74 secondi per unità di distanza, coerente con il modello fornito nel dataset (71 s e 0,55 s). Valutare le disposizioni sul percorso più corto è quindi giustificato.

**I risparmi reggono se gli operatori mantengono la loro sequenza?** No, ed è una condizione pratica importante. Prendiamo le disposizioni prodotte dalla riorganizzazione iniziale (150 tipi di prodotto, punteggio `copicks_linear`) e misuriamo il risparmio sui 40.213 ordini dei mesi di valutazione:

| | Risparmio con percorso ricalcolato | Risparmio mantenendo la vecchia sequenza |
|---|---|---|
| Greedy | +5,0% | −5,9% |
| Rete | +3,5% | −7,4% |

Se il percorso viene ricalcolato per la nuova disposizione, si risparmia; se gli operatori continuano a prelevare i tipi di prodotto nello stesso ordine di prima, si cammina di più, perché la vecchia sequenza era costruita sulle vecchie posizioni. Il risparmio di una riorganizzazione si realizza solo se le liste di prelievo vengono riordinate per la nuova disposizione, come fa normalmente un sistema gestionale che ordina i prelievi per posizione. Va detto esplicitamente all'azienda.

### 6.5 Le politiche statiche degli autori e la distanza lungo i corridoi (calzature)

**Le politiche statiche.** Il dataset contiene le disposizioni delle quattro politiche di stoccaggio confrontate dagli autori (IFAC-PapersOnLine 2025):
* *Random*: scatole collocate a caso;
* *Class-based*: tipi di prodotto raggruppati in classi di movimentazione, le più richieste vicino al deposito;
* *Dedicated*: ogni tipo di prodotto e taglia in una posizione fissa riservata;
* *Hybrid*: una combinazione di posizioni riservate e condivise.

Ogni file elenca, per ogni posizione, fino a 18 scatole con tipo di prodotto e taglia. Sono l'unico confronto esterno possibile su questo dataset.

**Come le misuriamo.** Ogni disposizione viene ridotta alla stessa rappresentazione della disposizione attuale:
1. ogni tipo di prodotto va nella posizione che contiene più sue scatole, a parità nella più vicina al deposito;
2. i conflitti si risolvono come per la disposizione attuale (sezione 3.2);
3. la disposizione si applica una volta, all'inizio dei mesi di valutazione, e resta ferma.

I traslochi si contano rispetto alla disposizione attuale e costano quanto i nostri. Due cautele: le politiche potrebbero essere state costruite dagli autori conoscendo la domanda dell'intero periodo; e, come la disposizione attuale, sono ridotte a una posizione per tipo di prodotto.

**La distanza lungo i corridoi.** Il file dei punti di navigazione descrive i 3 corridoi principali e i corridoi trasversali che li collegano. Con questi punti la distanza si calcola lungo i corridoi reali:
* se due posizioni stanno sullo stesso corridoio trasversale, è la differenza delle loro coordinate orizzontali;
* altrimenti si percorre il corridoio trasversale fino a un corridoio principale, poi il corridoio principale fino all'altro corridoio trasversale, e infine questo fino all'altra posizione.

Rispetto alla somma degli spostamenti usata dal metodo, le distanze tra posizioni sono in media più lunghe del 21% (uguali solo per il 13% delle coppie), mentre la distanza dal deposito è quasi identica (media 1.029 contro 1.028 unità). Il metodo ottimizza ancora con la somma degli spostamenti; qui tutte le disposizioni sono misurate con entrambi i giudici.

Risultati sui 7 mesi di valutazione, rispetto alla disposizione attuale (più alto è meglio; modalità QUICK per greedy e rete):

| Disposizione | Traslochi | Risparmio lordo, somma degli spostamenti | Risparmio lordo, lungo i corridoi | Netto, somma degli spostamenti | Netto, lungo i corridoi |
|---|---|---|---|---|---|
| Greedy, incrementale | 150 | +58,2% | +57,5% | +21,7 milioni | +22,1 milioni |
| Rete, incrementale | 149 | +49,7% | +49,1% | +17,2 milioni | +17,6 milioni |
| Politica statica Hybrid | 208 | +41,2% | +40,7% | +9,2 milioni | +9,5 milioni |
| Politica statica Dedicated | 208 | +36,6% | +35,8% | +6,8 milioni | +6,9 milioni |
| Politica statica Class-based | 206 | +30,1% | +28,9% | +3,5 milioni | +3,3 milioni |
| Politica statica Random | 203 | +5,3% | +4,6% | −9,4 milioni | −9,7 milioni |

**Lettura.**
* *Il protocollo incrementale batte le quattro politiche statiche*, sia nel risparmio lordo sia nel netto, con meno traslochi (150 contro 203-208). La migliore politica statica, Hybrid, risparmia il 41% del cammino contro il 58% del greedy e il 50% della rete in modalità QUICK. Spostare tutti i tipi di prodotto in una volta costa così tanta manodopera che la politica Random ha un netto negativo.
* *Le conclusioni non dipendono dalla distanza.* Lungo i corridoi reali ogni risparmio cambia di meno di un punto e mezzo, e l'ordine tra le disposizioni resta lo stesso. Ottimizzare con la somma degli spostamenti è quindi una semplificazione sicura. Ottimizzare direttamente con la distanza lungo i corridoi è un esperimento per Riccardo (sezione 10).

## 7. Migliorie al notebook delle calzature (Notebook 7)

### 7.1 Video

Due video per magazzino, in inglese, senza scene statiche, con scritte grandi, comprensibili senza conoscere il progetto.
* **`<dataset>_1_simulation.mp4`**: una riorganizzazione giocata dalla rete, mossa per mossa. Nel video:
  * gli scaffali sono file di quadrati tutti uguali; più scuro = contenuto ordinato più spesso, grigio = posizione vuota;
  * il deposito è etichettato "PACKING";
  * la linea blu è il giro dell'operatore per un ordine reale, lungo i corridoi;
  * la freccia rossa indica il tipo di prodotto spostato, la grigia quello che gli cede il posto;
  * una riga spiega ogni mossa in parole semplici;
  * due contatori mostrano i tipi di prodotto spostati sul budget e la distanza (nel farmaceutico, le ore di cammino) su 500 ordini reali.
* **`<dataset>_2_learning.mp4`**: a sinistra la disposizione del greedy ("a fixed rule that always moves the product that looks worst placed"); a destra quella della rete a checkpoint crescenti di addestramento ("a neural network that learns by trial and error"). Sotto, la ricompensa di addestramento e la distanza vera su 300 ordini.

Numeri nei video:
* *Calzature, rete addestrata 150 iterazioni*: supera il greedy dopo circa 600 partite di prova e chiude a 24,2 km contro 26,4 km sugli ordini di controllo (57 km senza riorganizzare). La simulazione finisce con il 42% di cammino in meno.
* *Farmaceutico, rete addestrata 150 iterazioni*: la ricompensa sale dall'11% al 19%, ma sugli ordini di controllo la rete resta appena sopra il greedy (12,4 ore contro 12,3 su 300 ordini; 13,3 senza riorganizzare). La simulazione finisce con il 6,2% di cammino in meno su 500 ordini reali.

Entrambi vanno rigenerati a scala piena.

La ricompensa di addestramento è il calo del punteggio a ogni mossa, non la distanza vera: il percorso più corto costerebbe migliaia di calcoli per mossa. La distanza vera è usata solo per giudicare. Una ricompensa sui percorsi veri a fine partita è un'ablation da fare.

### 7.2 Stato dell'arte e novità

Sul dataset delle calzature esistono tre lavori, tutti degli autori:
* l'ottimizzazione del percorso di prelievo a disposizione fissa (IEEE Access 2024);
* il confronto di quattro politiche statiche di stoccaggio, Random, Class-based, Dedicated e Hybrid (IFAC-PapersOnLine 2025);
* la descrizione del dataset (Data in Brief 2025).

Nessuno riorganizza a budget nel tempo, nessuno usa apprendimento. L'unico confronto esterno possibile è con le quattro politiche statiche, i cui file sono nel dataset: misurate con il nostro giudice, sono tutte battute dal protocollo incrementale (sezione 6.5). Nella letteratura generale l'apprendimento per rinforzo applicato allo stoccaggio decide dove mettere i prodotti in arrivo (Puiseau et al. 2022) o riassegna tutto su magazzini piccoli (Troch et al. 2023, Rimélé et al. 2021).

Punti di forza e grado di novità:
* **Modellazione**: riorganizzazione periodica a budget di un magazzino esistente, con la manodopera sommata alla distanza e il netto come metrica. È nuova in questa letteratura ed è il punto su cui spingere.
* **Punteggio per cercare, percorsi veri per giudicare**: la ricerca usa una formula istantanea, il giudizio i percorsi veri. La separazione è nostra. La formula del punteggio invece non è nuova: la sezione 4 mostra che l'indice classico dei co-prelievi, con il peso del deposito calibrato sul giudice, funziona in entrambi i magazzini. Il contributo è la separazione tra punteggio e giudice e la calibrazione dei pesi sui percorsi veri, non una formula.
* **Rete che sceglie solo quale tipo di prodotto spostare**, con la posizione di arrivo calcolata esattamente: nuova come architettura per questo problema. Transformer e REINFORCE in sé non sono nuovi.
* **Greedy contro rete** a parità di budget e di posizione di arrivo: il vantaggio misurato è interamente dovuto alla scelta di chi spostare.
* **Rollout incrementale**, con il confronto contro il rifacimento da capo: nuovo come protocollo di valutazione.
* **Tecniche di addestramento a confronto**: uno scenario (zero-shot) contro più scenari (finestre mensili e settimanali, ricampionamento, scenari sintetici); archivio delle disposizioni di partenza come correttivo dell'exposure bias, analogo allo scheduled sampling usato contro il teacher forcing.
* **Scelta del budget** in circa log n riorganizzazioni o senza riorganizzazioni: nuova in questo contesto.
* **Ablation** (spazio delle mosse, costo, posizione singola contro sparsa, schedule, scala di addestramento, varietà di scenari, archivio, punteggio) e **due magazzini con lo stesso codice**: contributo di solidità.

### 7.3 Altre migliorie

* Codice del metodo nel pacchetto `whrl` (sezione 2.3), con esecuzione riprendibile.
* Glossario fisso.
* Documentazione introduttiva con il flusso del metodo in sette passi.
* Spiegazione del perché il budget non è un parametro della rete, e del parallelo con teacher forcing ed exposure bias.
* Sezione di confronto dei punteggi (3.1) e analisi di sensibilità dei pesi (3.3).
* Confronto con le politiche statiche degli autori e verifica con la distanza lungo i corridoi (9.1 e 9.2).

## 8. Il notebook farmaceutico (Notebook 8)

**Come è costruito.** È generato dallo stesso costruttore del Notebook 7, con `DATASET = "pharma"`. Metodo, flusso sperimentale, greedy, rete, protocollo, analisi del budget e video sono gli stessi, quindi tutte le migliorie della sezione 7 sono presenti.

**Cosa cambia, e perché:**
* *Esplorazione dedicata* (numeri delle sezioni del Notebook 8): 2.3 su posizioni condivise, tempi e livelli; 2.4 sui tipi di prodotto duplicati; 2.5 sulle sequenze reali di prelievo, con la 5.1 sulla robustezza dei risparmi.
* *Punteggio `copicks_linear`*: su questo magazzino rende quasi il doppio di `rules_squared` (sezione 4).
* *Solo i 586 tipi di prodotto più prelevati sono spostabili*: la coda lunga non si riorganizza, e la rete lavora su 586 elementi invece di 2.385.
* *Budget di partenza 150 e 20*: ordini più ricchi e molti più tipi di prodotto.
* *Capacità pari all'occupazione attuale*: i traslochi sono scambi.
* *Nessuna sezione sullo stato dell'arte*: il dataset è privato.
* *Due ablation specifiche*: una posizione di capacità in più per tipo di prodotto, e la soglia dei tipi spostabili.

**I tempi reali.** Sono usati per convertire la distanza in ore (0,548 s per unità) e per dare al trasloco un prezzo misurato (142 s).

Sono usati anche, insieme alle sequenze reali di prelievo, per validare il giudice e per verificare che i risparmi dipendono dal riordino delle liste di prelievo (sezione 6.4).

Non sono usati nemmeno nel punteggio, attraverso il costo per livello di scaffale (i livelli alti costano fino a 21 s in più per prelievo). È un'estensione possibile.

Il cammino è il 29% del tempo di prelievo: il guadagno in ore ha quindi un tetto, anche quando quello in distanza è grande.

## 9. I risultati a confronto tra i due magazzini

* **Calzature, scala piena**: la rete batte il greedy del 12% di netto, e la varietà di scenari di addestramento non aggiunge nulla.
* **Calzature, QUICK**:
  * il rollout incrementale batte il rifacimento da capo;
  * il protocollo incrementale batte le quattro politiche statiche degli autori, e i risultati non cambiano con la distanza lungo i corridoi (sezione 6.5);
  * la scelta economica del budget perde da 0 a 7%;
  * `rules_squared` batte `copicks_linear` con il peso del deposito dell'istanza (β = 2), ma con β = 5 i due si equivalgono (sezione 4.4);
  * nel video la rete supera il greedy con 150 iterazioni.
* **Farmaceutico, QUICK, punteggio `copicks_linear`**:
  * il greedy risparmia il 5,6% di distanza (circa 102 ore di netto in 6 mesi) con 150 + 20 traslochi al mese;
  * il rifacimento da capo rende di più in totale perché i traslochi costano poco;
  * la rete è ancora sotto il greedy.
* **Perché i due magazzini sono così diversi**: tre fatti strutturali.
  * *Ordini piccoli contro ordini ricchi*: nelle calzature conta la distanza dal deposito, nel farmaceutico contano le coppie.
  * *Posizioni libere contro posizioni condivise*: nelle calzature si sposta in posizioni vuote, nel farmaceutico solo per scambi.
  * *Traslochi costosi contro traslochi economici*: un'ora contro 142 secondi.
* **Domanda**: nel farmaceutico è più stabile che nelle calzature. La varietà di scenari di addestramento difficilmente renderà anche lì. Un vantaggio della rete più marcato è possibile, ma dovrà venire dalle dipendenze tra tipi di prodotto.

## 10. Cosa è definitivo e cosa resta da fare

**Definitivo:**
* adattatori e statistiche dei due dataset, inclusa l'analisi dei tipi di prodotto duplicati;
* pacchetto e protocollo;
* risultato principale sulle calzature;
* stato dell'arte;
* confronto tra punteggi (tre semi, greedy);
* analisi del costo computazionale;
* formato dei video.

**Da fare: esperimenti per Riccardo** (stime indicative, sul portatile i7 dividendo i semi su 6 copie in parallelo). Gli esperimenti a scala piena si lanciano con `scripts/run_full_scale.py`; prima di tutto conviene la prova rapida descritta in `whrl_pkg/README.md` (un seme, due checkpoint, pochi minuti).

| # | Cosa | Stima |
|---|---|---|
| 1 | Farmaceutico a scala piena con il punteggio `copicks_linear`: greedy, rete zero-shot e due configurazioni multi-istanza, 5 semi | una notte di calcolo |
| 2 | Punteggio unico (sezione 4.4): rieseguire i due notebook con co-prelievi grezzi, somma lineare, β = 5, γ = 0, e confrontarlo a scala piena con i punteggi attuali, con greedy e rete | una notte di calcolo |
| 3 | Calzature: incrementale contro da capo con la rete a scala piena, 5 semi | 2-3 ore |
| 4 | Farmaceutico: incrementale con budget mensile scelto dalla bisezione (sezione 6.2), contro il rifacimento da capo, 5 semi | 2-3 ore |
| 5 | Curva del netto in funzione di K con la rete, nei due magazzini, con le perdite delle tecniche economiche | 1-2 ore |
| 6 | Farmaceutico: ablation della capacità (una posizione in più per tipo di prodotto) e della soglia dei tipi spostabili (50, 100, 200 prelievi) | mezza giornata |
| 7 | Calzature: usare la distanza lungo i corridoi anche nell'ottimizzazione (`distance="aisles"`, sezione 6.5), e ripetere il confronto con le politiche statiche con la rete a scala piena | una notte di calcolo |
| 8 | Ablation della ricompensa: calcolare la ricompensa di fine partita sui percorsi veri di un campione di ordini, invece che sul punteggio | 1-2 giorni |
| 9 | Video a scala piena, nei due magazzini | un'ora di calcolo |
| 10 | Aggiornamento dei capitoli della tesi (risultati a scala piena, capitolo sul farmaceutico) | 3-4 giorni |

## 11. Materiale

* `Warehouse_NB7_Footwear.ipynb`, `Warehouse_NB8_Pharma.ipynb`: i due notebook eseguiti in modalità QUICK.
* `build_nb.py`, `run_nb.py`: costruttore ed esecutore riprendibile; `run_cells.py`: esegue solo le celle necessarie ai checkpoint dei video, per calcolarli a blocchi.
* `whrl_pkg/`: il pacchetto, con `scripts/compare_surrogates.py`.
* `videos/`: i quattro video.
* `results/`: i dati del confronto tra punteggi e dell'analisi di sensibilità dei pesi.
* `README.md`: istruzioni di installazione ed esecuzione.
