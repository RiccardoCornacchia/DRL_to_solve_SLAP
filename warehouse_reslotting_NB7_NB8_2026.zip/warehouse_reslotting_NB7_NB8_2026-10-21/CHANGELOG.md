# Changelog, 21 ottobre 2026

Questa versione parte dalla base di codice aggiornata da Riccardo e applica le decisioni prese dopo le sue osservazioni sui notebook. Ogni voce dice cosa è cambiato, dove, e perché.

## Cosa c'era nella base di Riccardo, e cosa ne ho fatto

**Tenuto.**
* **Greedy con temperatura adattiva** (`whrl/greedy.py`, `whrl/env.py`). Il greedy sceglie a caso il tipo di prodotto da spostare, con probabilità proporzionale al suo peso nel punteggio elevato a una temperatura τ. La versione di Riccardo parte da τ = 1,5 (concentrata sui tipi di prodotto messi peggio) e abbassa τ di 0,15 ogni 100 passi finché le mosse continuano a rendere; se il guadagno degli ultimi 100 passi scende sotto la metà del precedente, τ risale di 0,30. L'ho documentato nel codice e reso selezionabile (`GREEDY_TEMPERATURE` nella prima cella: "adaptive" oppure un numero fisso). Nella sezione 4.1 c'è una cella che lo confronta con il greedy precedente (τ = 1 fisso), a parità di budget e semi: nelle calzature 33,2% contro 30,6% di risparmio lordo sulla validazione; nel farmaceutico 19,1% contro 18,6%. Entrambi i notebook usano la versione adattiva.
* La memoizzazione delle valutazioni nelle tecniche di scelta del budget (`whrl/budget.py`) e la gestione del caso Kₘ = 0 nella scala piena (`whrl/fullscale.py`).

**Corretto.**
* Il punteggio `copicks_linear_b5` era stato cambiato a γ = 0,3. Nel report e nei notebook è definito con γ = 0 (co-prelievi, somma semplice, β = 5), ed è quello scelto sulla validazione: ripristinato. Con γ = 0,3 il candidato scelto nel farmaceutico cambiava, e le reti allenate da Riccardo sul farmaceutico sono infatti marcate `copicks_linear`.
* Il tetto alle mosse della rete era stato abbassato a 160 (`policy_reorganize`). Serve il contrario: vedi il punto 2.
* Tolte alcune stampe di debug (`knowledge.py`, `budget.py`).
* I notebook contenevano celle di lavoro (cancellazione manuale di file della cache, prove su T) e i flag impostati per la scala piena: sono stati rigenerati puliti dal builder. Le cache di Riccardo con suffisso "full" non vengono lette: vedi "Cache per modalità" sotto.

## [0] Le spiegazioni sono nei notebook

Tutto ciò che ci siamo detti è scritto nelle celle, con lo stesso linguaggio del briefing:
* **Sezione 3.1**: perché la rete si allena solo sui mesi di warm-up (contaminazione: chi è giudicato su un mese non deve averlo visto in allenamento), e perché il greedy non ha questo problema.
* **Sezione 4.2**: cosa sono K₀ e Kₘ (risposte dei dati, non impostazioni), come dipendono dal costo del trasloco, e qual è il budget usato per la rete.
* **Sezione 4.3**: cos'è una partita, perché le mosse devono essere più dei traslochi, la regola delle lunghezze (2 × K in allenamento, 4 × K in uso, nessun tetto), e quanto costa una mossa (self-attention: un confronto per ogni coppia di tipi di prodotto, circa 43 mila nelle calzature e 5,7 milioni nel farmaceutico).
* **Sezione 6**: cosa separa il risparmio lordo dal netto, la riga con il ritocco forzato, e la stabilità della domanda come causa principale.
* **Sezione 7.2**: perché la griglia è fine e cosa conta davvero (la perdita rispetto al migliore, non il K trovato).
* **Sezione 10**: perché il vecchio risultato del 12% è scartato e qual è la cella da eseguire.

## [1] Validazione e test, e il nuovo confronto rete contro greedy

* La divisione resta: 3 mesi di warm-up, 3 di validazione (solo per scegliere), il resto di test (solo per misurare). La rete si allena solo sul warm-up.
* Il risultato del Notebook 6 (rete migliore del greedy del 12% sulle calzature) è scartato: quelle reti erano allenate anche su ordini dei mesi di validazione e di test. La sezione 10 lo dice e contiene la cella pronta, uguale nei due notebook: `RUN_FULL = True` nella prima cella e si esegue; con `RUN_FULL = False` stampa il comando equivalente da terminale.
* **Lunghezza delle partite legata al budget** (`T_TRAIN_PER_K = 2`, `T_PLAY_PER_K = 4` nella prima cella, e `policy.py`, `fullscale.py`): niente più tetti fissi (120 e 360 venivano dal budget 90 delle calzature e tagliavano il farmaceutico).
* **Budget della rete.** La rete impara quali pochi tipi di prodotto spostare: se la validazione sceglie K₀ uguale a tutti i tipi di prodotto, non c'è nulla da scegliere. In quel caso la rete viene allenata e confrontata a un quarto dei tipi di prodotto (`K_NET`, sezione 4.2), con il greedy allo stesso budget nelle sezioni 5, 6 e 10. La regola è la stessa nei due notebook; nelle calzature K_NET = K₀ = 133; nel farmaceutico K₀ = 798 è sotto il totale, quindi K_NET = K₀ = 798 e la regola del quarto non serve.

## [2] Costo del trasloco farmaceutico: 10 minuti

* Prima: 142 secondi, cioè due movimentazioni da 71 secondi misurate sui tempi di prelievo di una singola scatola. È un limite inferiore, non il costo di un trasloco: spostare un tipo di prodotto vuol dire spostarne tutte le scatole, spesso con uno scambio, e aggiornare il gestionale.
* Ora: 10 minuti di lavoro per tipo di prodotto, per convenzione, come l'ora delle calzature. In unità di distanza: 600 s / 0,548 s per unità = 1.095 unità (`whrl/data.py`, con i 142 secondi dichiarati come limite inferiore nelle note).
* Effetto sui budget scelti sulla validazione: K₀ scende da 2.385 (tutti i tipi di prodotto) a 798 (il 33%), e la curva del netto ora scende oltre 900: spostare tutto non conviene più; Kₘ resta 0.
* La sezione 6 ripete il confronto con metà e doppio costo (5 e 20 minuti), riscegliendo il ritocco per ciascun costo.

## [3] Ritocco: netti come sono, e la causa

* Nessun risultato dei notebook vecchi. I netti sono riportati così come escono.
* Nella sezione 6 c'è una riga in più, "ritocco forzato": 5% dei tipi di prodotto spostati ogni mese con il costo del dataset. Mostra separatamente che il ritocco fa camminare meno (lordo) e se si ripaga (netto). Calzature: lordo dal 69% al 72%, netto da 327 a 297 ore. Farmaceutico: lordo dal 20% al 24%, netto da 194 a 195 ore (pareggio). Qui il ritocco si ripaga di poco, perché il trasloco costa 10 minuti e non un'ora, ma sulla validazione non viene comunque scelto.
* Un grafico mostra il ritocco scelto sulla validazione per ciascun costo del trasloco.
* Nella sezione 7.3 c'è una verifica in più, uguale nei due notebook: il budget del ritocco giudicato sull'intero protocollo di validazione (riorganizzazione iniziale con K₀, poi un ritocco di Kₘ in ogni mese di validazione successivo), con Kₘ pari a 0, 5%, 12,5% e 25% dei tipi di prodotto. Serve a escludere che il ritocco perda solo perché viene giudicato su un mese. Risultato: Kₘ = 0 resta il migliore in entrambi (calzature 159, 140, 113, 67 ore; farmaceutico 121, 103, 81, 37 ore).
* La causa principale è scritta nella lettura della sezione 6 con i numeri della sezione 2.2: da un mese all'altro restano tra i più prelevati l'82% dei 50 tipi di prodotto più venduti nelle calzature e il 90% dei 200 nel farmaceutico. Con una domanda così stabile un ritocco ha poco da correggere, e conviene solo se il trasloco costa poco. Il confronto 90 e 10 dei notebook vecchi resta un caso di studio da valutare solo in tesi, non nei notebook.

## Come vengono scelti i budget: la ricerca economica è il metodo

La scelta di K₀ e Kₘ nella sezione 4.2 (`whrl.fullscale.choose_budgets`) è fatta con la **sezione aurea**, in entrambi i magazzini: la ricerca tiene un intervallo di budget, ne valuta due all'interno, scarta il lato con il netto più basso e si ferma quando l'intervallo è sotto il 2% dei tipi di prodotto. Circa dieci riorganizzazioni per budget, invece di provarli tutti. K₀ si cerca tra 0 e tutti i tipi di prodotto, Kₘ tra 0 e la metà, partendo dalla disposizione ottenuta con K₀; se nessun ritocco valutato ha netto positivo, Kₘ = 0. La sezione 6 risceglie il ritocco con la stessa ricerca per i costi dimezzato e raddoppiato; la sezione 7.2 misura quanto la ricerca perde rispetto alla curva fine di 52 valori. Risultato: calzature K₀ = 133 (nove valutazioni), Kₘ = 0 (otto); farmaceutico K₀ = 798 (dieci valutazioni), Kₘ = 0 (otto).

## Riproducibilità del greedy e conteggio delle riorganizzazioni

Prima il greedy usava un solo generatore casuale per tutte le riorganizzazioni di una ricerca: ogni chiamata ripartiva da dove la precedente aveva lasciato il generatore, quindi il netto di un budget dipendeva da quali budget erano stati provati prima. Per questo la ricerca della sezione 4.2 e quella della 7.2 si fermavano su budget diversi. Ora ogni riorganizzazione riparte dallo stesso seed (`SEED` della prima cella), nel greedy (`make_greedy`, `fs.greedy_opt`) e nella rete (`make_policy_fn`, `fs.network_opt`): il netto di un budget è sempre lo stesso, chiunque lo chieda e in qualunque ordine, e le due ricerche danno lo stesso K₀. Due budget diversi restano due esecuzioni diverse del greedy (più passi per un budget più grande), quindi la curva del netto ha piccole gobbe vicino al massimo.

La sezione 7.2 contava per le ricerche solo i budget non già presenti sulla griglia fine; ora conta tutti quelli valutati, perché una ricerca usata da sola dovrebbe calcolarli tutti. La perdita è ora misurata contro il migliore dei 52 budget della griglia fine (prima contro il migliore tra le tecniche).

Tutti i risultati che dipendono dal greedy delle sezioni 4.2-9 sono stati ricalcolati in entrambi i notebook. Budget scelti: calzature K₀ = 133 (9 riorganizzazioni), farmaceutico K₀ = 798 (10 riorganizzazioni); Kₘ = 0 in entrambi.

## [4] Griglia fine per la scelta del budget

* La sezione 7.2 calcola, solo come controllo, la curva fine: un budget ogni 2% circa dei tipi di prodotto, 52 valori (0 e poi 51 passi uguali). Ogni valore è una riorganizzazione seguita dal giudice, cioè dal calcolo dei percorsi veri di tutti gli ordini dei mesi di validazione: è il passo costoso. Il passo del 2% è lo stesso a cui si ferma la sezione aurea, quindi la curva di controllo è fine quanto la precisione della ricerca.
* Calzature (greedy, un seme): il migliore dei 52 budget è 131; la sezione aurea, la stessa ricerca della sezione 4.2, dà 133 con 9 riorganizzazioni invece di 52, e un netto dello 0,5% più alto (133 sta tra due punti della griglia); la bisezione dà 130 con 10 riorganizzazioni (+1%); la stima K̂ dà 81 senza riorganizzazioni, il 20% sotto.
* Farmaceutico: il migliore dei 52 è 795; la sezione aurea dà 798 con 10 riorganizzazioni, lo 0,1% sotto; la bisezione 715 con 10 (−3%); la stima K̂ 1.609, il 37% sotto, perché conta i traslochi che si ripagano da soli e qui il guadagno di un trasloco dipende dagli altri.
* Non ho aggiunto semi: con il greedy riproducibile la curva è piatta attorno al massimo, e la colonna da guardare è la perdita, non il K.
* La sezione 7.1 (budget migliore in funzione dei mesi di uso) usa la stessa griglia fine: calzature 37, 114, 131, 139 con 1, 2, 3-4, 5+ mesi; farmaceutico 94, 561, 795, 935, 1.309 con 1, 2, 3, 4, 5-6 mesi.

## Memoria dell'allenamento della rete (dopo l'errore di Riccardo del 22 ottobre)

Riccardo ha avuto un errore di memoria esaurita (`DefaultCPUAllocator: not enough memory`) eseguendo la sezione 4.3 delle calzature a scala piena. La causa è nel modo in cui il trainer calcolava il gradiente: teneva in memoria il grafo di calcolo di tutte le mosse di una partita fino alla fine, e la memoria cresce con la lunghezza della partita per il quadrato del numero di tipi di prodotto. Con le partite di allenamento portate a 2 × K mosse (208 nelle calzature, prima erano 60) una sola iterazione occupava circa 3 GB; nel farmaceutico, con 1.788 mosse e 2.385 tipi di prodotto, sarebbe stato impossibile.

**Correzione** (`whrl/policy.py`, `make_trainer`): la partita viene giocata una prima volta senza grafo, registrando le mosse; poi le stesse mosse vengono rigiocate su copie fresche dei magazzini e il gradiente viene ricalcolato poche mosse alla volta (`moves_per_chunk`, dimensionato da `TRAIN_CHUNK_MB` nella prima cella, 512 MB). Il gradiente è identico, perché la funzione di costo è una somma sulle mosse; la memoria è limitata dal blocco di mosse; il costo è un passaggio in avanti in più per ogni mossa. La modalità vecchia resta disponibile (`memory="full"`) e la prima cella della rete nella sezione 4.3 verifica su una partita piccola che le due modalità muovono i pesi allo stesso modo (differenza attesa sotto 1e-5). Il protocollo a scala piena usa la stessa correzione.

**Cosa resta vero sui tempi.** La correzione risolve la memoria, non la durata. Nel farmaceutico ogni mossa è un passaggio della rete su 2.385 tipi di prodotto e le partite sono di 1.788 mosse, quindi un'iterazione a scala piena è lunga (decine di minuti con i tempi misurati da Riccardo). Il numero di iterazioni resta quello del protocollo precedente, uguale nei due magazzini; il lavoro è in cache e riparte da dove si era fermato.

## Cache per modalità

Le cartelle della cache ora dipendono dalla modalità: `cache_<dataset>/` per `QUICK = True`, `cache_<dataset>_full/` per `QUICK = False`. Così i risultati rapidi e quelli a scala piena non si sovrascrivono (era il problema che Riccardo aveva aggirato aggiungendo "full" ai nomi dei file). Le cache consegnate sono quelle rapide, con il greedy; le celle della rete partono da zero.

## I numeri della consegna (modalità rapida, greedy, un seme, budget scelti con la sezione aurea)

| | Calzature | Farmaceutico |
|---|---|---|
| Punteggio scelto sulla validazione | copicks_linear_b5 (33,2%) | copicks_linear_b5 (19,1%) |
| K₀, Kₘ | 133, 0 | 798, 0 |
| Budget della rete (K_NET) | 133 | 798 |
| Protocollo ibrido, tutti i mesi di valutazione | 68,8% lordo, +486 ore nette | 21,0% lordo, +315 ore nette |
| Mesi di test: single-shot / ibrido / da zero (ore nette) | 327 / 327 / −161 | 194 / 194 / 17 |
| Ritocco forzato (5% al mese) | lordo 72%, netto 297 ore | lordo 24%, netto 195 ore |
| Secondo giudice (Manhattan) | 69,2% contro 69,4% | −3% contro +20% (Manhattan è fuorviante, ignora muri e scaffali) |

## Cosa deve fare Riccardo

1. Scaricare lo zip, reinstallare il pacchetto (`pip install -e whrl_pkg`) e aprire i notebook da quella cartella.
2. Calzature: `QUICK = True`, `RUN_NETWORK = True`, eseguire tutto. Il greedy è in cache, girano solo le celle della rete. La prima cella della rete stampa la differenza tra le due modalità di memoria (attesa sotto 1e-5) e quante mosse vengono retropropagate insieme.
3. Farmaceutico: come al punto 2.
4. Scala piena: `RUN_FULL = True`, prima le calzature e poi il farmaceutico. Le iterazioni sono quelle del protocollo precedente (checkpoint a 150, 300, 450, 600, 900, 1.200, 1.500, 1.800 e 2.100, con early stopping sulla validazione), uguali nei due magazzini. Il lavoro riparte dalla cache se si interrompe.
5. Non riusare le reti allenate con il codice precedente: budget, lunghezza delle partite e punteggio sono cambiati.
