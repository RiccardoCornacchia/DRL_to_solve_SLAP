"""Builds the two notebooks from ONE flow: only DATASET changes (footwear or pharma). Every method decision is shared;
the only dataset-specific cells are the checks of section 9 and the recording check of section 2.4."""
import nbformat as nbf

def md(s): return nbf.v4.new_markdown_cell(s)
def code(s): return nbf.v4.new_code_cell(s)

RUN_MODES = """> **Run modes and resumability.** `QUICK = True` (default, environment variable `QUICK=1`) checks the whole flow on a laptop: one seed, reduced grids, the networks trained for a few dozen iterations. `QUICK = False` is the full scale of every cell. `RUN_NETWORK` (default on) runs the cells that need PyTorch; `RUN_VIDEOS` the videos; `RUN_FULL` (default off) the full-scale statistical protocol of §10 inside the notebook. **Every heavy result is saved on disk** in `cache_<dataset>/` as soon as it is computed (one file per unit of work, training checkpoints every few iterations): an interrupted run resumes where it stopped, and seeds can be split across machines by copying the cache folder. To recompute something, delete its file."""

SHARED = """## Decisions shared by the two warehouses (identical method)
1. **One position per product type** (single home). The adapter measures how far the real warehouse is from this (§2.3).
2. **Distances**: the realistic walking distance of each dataset (along the aisles and corridors for footwear, from its navigation points; on the floor around the shelves for the pharmaceutical warehouse, from its floor plan), for the optimizer and for the judge. The Manhattan distance on the coordinates, which ignores walls and shelves, is used only as a check (§9.1): where it misleads, a layout optimized with it can make the real walking longer.
3. **Capacity of a position**: its current occupancy (`EXTRA_CAPACITY = 0`); what spare room would be worth is an ablation (§4.1).
4. **Every product type is movable**: the budget, not a filter, limits the relocations.
5. **Moves**: relocation to a position with free capacity, or swap with a product type stored there; the two move sets (general, swaps only) are compared (§4.1).
6. **Score**: the same three candidates in both warehouses; the one used is chosen on the **validation months** with the same rule (§3.4).
7. **Budgets**: the initial budget K₀ and the monthly retouch budget Kₘ are chosen on the validation months only, with a cheap search (golden section, about ten reorganizations each; §4.2) instead of trying every budget; §7.2 measures what the search loses against the fine curve of 52 budgets.
8. **Relocation cost**: κ × (0.5 + bulk index) distance units per product type. κ is the labour of relocating the whole stock of one product type (every box, a possible swap, the update of the management system), set by convention in both warehouses: one hour of walking for footwear, ten minutes for the pharmaceutical warehouse (where the measured handling of a single pick, 2 × 71 s = 142 s, is only a lower bound). The protocol comparison is repeated with half and double cost.
9. **Time**: distance units are converted into seconds with the time model of the dataset (measured for the pharmaceutical warehouse, a stated convention for footwear), so every net saving is also given in hours.
10. **Evaluation**: three months of warm-up, then the evaluation months split into **validation** (first three, used only to choose score, budgets and checkpoints) and **test** (the rest, reported). The network is trained only on the warm-up months, so that no order of the validation or test months is ever seen in training. Greedy and network are compared at equal budget, with the true routes of the judge, multiple seeds and paired tests (§10).
11. **Game lengths of the network tied to the budget**: 2 moves per unit of budget in the training games, 4 when the network reorganizes, with no fixed cap, so that a large budget is never cut short.
12. **Greedy**: the same greedy in both warehouses, with the adaptive sampling temperature of §4.1."""

GLOSSARY = """## Glossary (used exclusively)
* **product type**: the model (a shoe model, a pharmaceutical article). It is what the method assigns to a position, relocates and counts in the budget.
* **product**: one physical unit of a product type (a pair of shoes in its box, a pack of medicine).
* **position**: a storage point on the shelves, with coordinates on the floor plan; it can hold one or more product types (its capacity).
* **depot**: the point where every picking route starts and ends.
* **order**: the set of product types picked in one route. **pick**: taking products of a product type from a position.
* **co-pick**: two product types are co-picked when they appear in the same order.
* **layout**: the position of every product type. **current layout**: the one in the data (`pl_asis`).
* **relocation**: a change of position of a product type, i.e. moving its whole stock. **budget K**: the maximum number of product types relocated.
* **score F**: the fast formula the optimizer uses to compare layouts (§3). **judge**: the true distance of the orders along their shortest routes (§3); it certifies every result and never guides the search.
* **gross saving**: distance saved by a layout against the current one, as a share. **net saving**: distance saved minus the relocation cost, in distance units (and hours). Higher is better for both.
* **initial reorganization**: the first, large relocation with budget K₀. **retouch**: the small monthly relocation with budget Kₘ.
* **single-shot**: initial reorganization only. **hybrid**: initial reorganization plus monthly retouches. **from scratch**: a full reorganization every month, without budget.
* **instance**: (dependencies W, popularity, starting layout, budget K), one exercise for the optimizer.
* **move**: one step of an optimizer: a product type goes to a free position, or two product types swap. **game**: a sequence of moves played by the network from a starting layout until the budget is spent or the move limit T is reached. **iteration**: B_TRAIN practice games of the network followed by one update of its parameters.
* **warm-up / validation / test months**: the first three months (knowledge and training only), the next three (choices only), the rest (results only). **knowledge window**: the three months of orders from which the dependencies and the popularity are computed before each decision."""


# Readings with the numbers of the delivered execution (QUICK mode, greedy, one seed): (footwear, pharma)
RESULTS = {
"2.1": ("208 product types in 846 positions on the two picking levels (2,292 in the whole plan); 32,634 orders over ten months, 1.9 product types per order and 73% of the orders with a single one: proximity to the depot is what matters most. The 20 most popular product types make 49% of the orders. The floor plan is 44 x 109 m; the walking of the current layout in the first month is about 140 hours at 1.27 m/s (a convention, the dataset has no times).",
        "2,385 product types in 972 positions (1,430 in the plan); 58,616 orders over ten months, 7 product types per order: the dependencies between product types weigh much more than for footwear. The last month has far fewer orders and is excluded from the evaluation. The floor plan is about 41 x 77 m (estimate: 0.60-0.70 m per cell). The walking of the current layout in the first month is about 130 hours, measured with the time model of the dataset (0.548 s per cell)."),
"2.2": ("the demand is stable: from one month to the next, 76-88% of the 50 most-picked product types stay among the top 50 (mean 82%), with a Spearman correlation of 0.82-0.91 between the monthly counts. There is little for a monthly retouch to repair, so whether it pays off is decided by the relocation cost (§6, §7.3).",
        "the demand is at least as stable as for footwear: 84-95% of the 200 most-picked product types stay among the top 200 from one month to the next (mean 90%), Spearman 0.69-0.88. Here too the value of a retouch is decided by the relocation cost, which is very low (§6)."),
"2.3": ("this is a **scattered** warehouse: every product type is picked from 44 positions on average (up to 173), and its most-used position serves only 25% of its picks on average (minimum 3%). The single-home model is therefore a strong simplification of this warehouse: the walking it computes, including that of the current layout, is the walking of the model. Every saving in this notebook must be read with this limit; a judge that picks every product type from its nearest copy is the extension to study. One product type per position and 638 free positions: relocations to free capacity are possible.",
        "the data already give a **single home**: 2,309 product types out of 2,385 have one position, the other 76 appear in two or three, and the most-used position serves 98% of the picks on average (§2.4 shows that these 76 are the same pick recorded twice). The simplification is negligible here. Positions are shared, 2.46 product types per position on average and up to 19, and only one position has free capacity: almost every move is a swap."),
"3.2": ("the depot term is decisive, as expected with 73% single-type orders: the pure QAP (pairs only) saves 3%, the QAP instance with β = 2 saves 15%, and the same co-picks with β = 5 save 33%. With the depot term in place, the differences between weights and forms (29% rules with squares, 32% co-picks with squares, 33% co-picks with the plain sum) are within what one seed can resolve.",
        "all five forms are close (15-20%): with seven product types per order the walking is spread over many pairs and the depot term matters little (pure QAP 19.5%, with the depot term 19.1%). The plain sum with co-picks is the best family, the squares the worst (15-16%)."),
"3.3": ("β is the number that matters: with rule weights the saving goes from 2% at β = 0 to 29% at β = 5 and 34% at β = 10; with co-picks from 3% to 33% and 35%. γ adds a few points at low β and nothing at β = 5. α between 0.3 and 1 moves the saving by a few points (34%, 29%, 28%). One seed: differences of two or three points are noise.",
        "the saving barely moves with β (17-20% over the whole range), γ costs one or two points, and α does not matter (16% for all three values): in this warehouse the score is insensitive to its weights, which makes the choice of §3.4 easy."),
"3.4": ("`copicks_linear_b5` is chosen: 33.2% against 29.2% for `rules_squared` and 14.9% for `copicks_linear` (β = 2). The same candidate wins in the pharmaceutical warehouse, so the two notebooks use the same score.",
        "`copicks_linear_b5` is chosen: 19.1% against 19.0% for `copicks_linear` and 16.1% for `rules_squared`, the same candidate as for footwear (the first two are equal within the noise of one seed)."),
"4.1": ("the adaptive temperature helps: 33.2% against 30.6% with the fixed τ = 1, same budget and seeds. The move set matters here because 638 positions are free: with swaps only the greedy saves 13% against 33% with general moves. One extra product type per position (a physical hypothesis, not a result) would raise the saving to 39%.",
        "the adaptive temperature gives a small gain, 19.1% against 18.6% with the fixed τ = 1. With the capacity of the data the two move sets coincide (19.1%), because every position is full and every move is a swap; one extra product type per position would raise the saving to 23% (general moves) and 20% (swaps only). It is a hypothesis to verify with the company."),
"4.2": ("K₀ = 133 (64% of the product types) and Kₘ = 0. The golden-section search evaluated nine budgets between 79 and 159: the net on validation is 9.40 million units at 133 and lower on both sides (8.83 at 121, 9.04 at 136, 8.70 at 159). For Kₘ it evaluated eight retouch budgets between 2 and 64 product types, all with a negative net on the second validation month. With a relocation that costs one hour of walking, the initial reorganization pays and the monthly retouch does not. K₀ is below the number of product types, so the network is trained and compared at the same budget (K_NET = 133).",
        "K₀ = 798 (33% of the product types) and Kₘ = 0. The golden-section search evaluated ten budgets between 563 and 1,474: the net on validation is 0.79 million units at 778-798, almost flat between 696 and 911 (0.75-0.79) and lower beyond (0.71 at 1,126, 0.57 at 1,474), because with a relocation of 10 minutes moving everything no longer pays. For Kₘ it evaluated eight retouch budgets between 25 and 737 product types, all with a negative net on the second validation month. K₀ is well below the number of product types, so there is a real choice to learn and the network is trained and compared at the same budget (K_NET = 798)."),
"5": ("the hybrid protocol saves 68.8% of the walking over the seven evaluation months with 133 relocations, net 486 hours of walking at 1.27 m/s (the relocations cost 133 hours). Since Kₘ = 0, the protocol is a single reorganization kept in use.",
        "the hybrid protocol saves 21.0% of the walking over the six evaluation months with 798 relocations, net 315 hours of walking with the measured time model (the relocations cost 133 hours). Since Kₘ = 0, the protocol is a single reorganization kept in use."),
"6": ("on the four test months the single-shot and the hybrid coincide (Kₘ = 0 at every cost: 327 net hours, 69% gross). From scratch saves more walking (77%) but relocates almost everything every month: it is worth 101 hours with half the relocation cost, −161 hours with the cost of the dataset and −686 with double. The forced retouch of 10 product types a month raises the gross saving to 72% and lowers the net to 297 hours: a retouch saves walking, but here it does not pay, because the demand changes little from month to month (82% of the top 50 kept, §2.2) and a relocation costs one hour.",
        "on the three test months the single-shot and the hybrid coincide (Kₘ = 0 at every cost: 194 net hours, 20% gross). From scratch saves more walking (35%) but relocates almost everything every month: it is worth 178 hours with half the relocation cost, 17 with the cost of the dataset and −305 with double. The forced retouch of 119 product types a month (5%) raises the gross saving to 24% and the net to 195 hours, one hour more than the single-shot: with a relocation of 10 minutes a retouch is at break-even, and on validation, where it loses, it is not chosen. The reason is that the demand changes little from month to month (84-95% of the top 200 kept, §2.2)."),
"7.1": ("the best budget grows with the horizon: 37 with one month of use, 114 with two, 131 with three or four, 139 from five months onwards (a budget every 2% of the product types). Around the maximum the net is almost flat, so the exact value matters less than the order of magnitude: about half to two thirds of the product types.",
        "the best budget grows with the horizon: 94 with one month of use, 561 with two, 795 with three, 935 with four, 1,309 with five or six (a budget every 2% of the product types). With a relocation of 10 minutes the optimum stays between a quarter and a half of the product types once the layout is used for a few months; around the maximum the curve is flat."),
"7.2": ("the best of the 52 budgets of the fine curve is 131 (9.36 million units). The golden section, the search the method uses in §4.2, returns the same K₀ = 133 with 9 reorganizations instead of 52, and a net 0.5% higher: 133 is between two grid points (131 and 135). The bisection lands at 130 with 10 reorganizations (+1%). The estimate K̂ gives 81 without any reorganization, 20% below the best: it counts the single relocations that pay on their own, and misses those that pay only together.",
        "the best of the 52 budgets of the fine curve is 795 (0.795 million units). The golden section, the search the method uses in §4.2, returns the same K₀ = 798 with 10 reorganizations instead of 52, and a net 0.1% lower: the curve is flat around the maximum. The bisection lands at 715 with 10 reorganizations (−3%). The estimate K̂ gives 1,609 without any reorganization, 37% below the best: it counts the relocations that pay on their own, and in this warehouse the gain of a relocation depends on the others."),
"7.3": ("every retouch budget of the curve has a negative net on the second validation month (−1.0 million units for 17 product types, −5.8 million for 104), like the eight budgets evaluated by the search in §4.2. With the whole validation as horizon the answer is the same: the hybrid protocol is worth 159 hours with no retouch, 140 with 10 product types a month, 113 with 26, 67 with 52. With a relocation that costs one hour of walking and a demand that changes little from one month to the next, the retouch does not pay, which is why Kₘ = 0.", "every retouch budget of the curve has a negative net on the second validation month (−104 thousand units for 199 product types, −697 thousand for 1,192), like the eight budgets evaluated by the search in §4.2. With the whole validation as horizon the answer is the same: the hybrid protocol is worth 121 hours with no retouch, 103 with 119 product types a month, 81 with 298, 37 with 596. After an initial reorganization of 798 product types there is little left to repair in the following months, which is why Kₘ = 0 even with a relocation of 10 minutes."),
"9.1 and 9.2": ("the realistic distance along the aisles and the Manhattan distance give the same picture: 69.4% against 69.2% gross saving for our protocol. The four static policies of the dataset authors, measured with the same judge on the same test months, save 2% (Random), 28% (Class-based), 35% (Dedicated) and 40% (Hybrid), each relocating 204-208 product types at once, so their net saving is negative; our protocol saves 69% with 133 relocations and a net of +11.7 million units.",
        ""),
"9.1 to 9.3": ("",
        "the Manhattan distance is misleading in this warehouse: it would rate our layout at −3% while the realistic walking on the floor, used by the method, gives +20%. The reason is in the floor plan: Manhattan ignores walls and shelves, so a position can look close to the depot while the way around the shelves is long. The real picking sequences confirm the judge: with the route re-optimized the layout saves 19.8%, with the old sequence kept 12.9% (the saving survives, but part of it needs the pick lists to be re-sequenced)."),
}

def build(dataset):
    fw = dataset == "footwear"
    nb = nbf.v4.new_notebook(); c = []
    title = "Notebook 7 · Footwear warehouse: incremental re-slotting under a budget" if fw else "Notebook 8 · Pharmaceutical warehouse: the same method on a second warehouse"
    twin = "Notebook 8 (pharmaceutical warehouse)" if fw else "Notebook 7 (footwear warehouse)"
    c.append(md(f"""# {title}

## The problem in one sentence
Decide **in which position each product type is stored**, so that pickers walk less to prepare the orders, while moving **only a few product types at a time**, because every relocation costs labour.

## The flow of the method (the same for every warehouse)
1. **From data to knowledge.** From the orders of a time window we compute the *popularity* of every product type and the *dependencies* between product types (which ones are picked together).
2. **The score F.** A fast formula measuring how good a layout is: it grows when two product types picked together are far apart and when a popular product type is far from the depot. Lower is better. It compares thousands of candidate layouts in seconds (§3).
3. **The judge.** The true distance: for every order, the shortest route depot → positions → depot. It is slow, so it never guides the search: it **certifies** every final result.
4. **The moves.** Relocate a product type to a position with free capacity, or swap it with a product type stored in the target position. The **budget K** is the number of product types whose final position differs from the starting one.
5. **Who to move: two optimizers.** The **greedy** is a fixed rule: it picks the product type that currently weighs most on F and the best of a few candidate positions. The **network** (Transformer trained with REINFORCE) learns only *which* product type to move; *where* is decided by the same verifier as the greedy (§4).
6. **The protocol over time.** After a warm-up, one initial reorganization with budget K₀, then every month a retouch with budget Kₘ computed on the orders of the last three months. The decision metric is the **net saving** (§5).
7. **The studies.** Single-shot against hybrid against from scratch (§6); the choice of the budgets and how it depends on the horizon (§7); the videos of the network while it learns (§8); the checks specific to this dataset (§9); the full-scale statistical protocol (§10).

This notebook and its twin, {twin}, are built from the same generator (`build_nb.py`) and run the same code: they differ only in the line that chooses the dataset and in the checks of §9.

{SHARED}

{GLOSSARY}

{RUN_MODES}

## The code of the method lives in a package, not in the notebook
Everything that does not depend on the dataset is in the Python package `whrl` (folder `whrl_pkg/whrl/`, installed once with `pip install -e whrl_pkg`): `data.py` adapters, `knowledge.py` score weights, `env.py` state and moves, `greedy.py`, `policy.py` network and training, `rolling.py` protocol and judge, `budget.py` budget techniques, `fullscale.py` budgets on validation, protocols and the statistical protocol, `analysis.py` shared descriptive analyses, `routes.py` real picking sequences, `video.py`, `stats.py`. The notebook calls these functions; it does not redefine them."""))

    c.append(md("""## How to run this notebook on your PC (Jupyter)
1. Install the package once, from the folder that contains `whrl_pkg/`, `footwear/` and `pharma/`: `pip install -e whrl_pkg` (plus `torch`, `mlxtend`, `scipy`, `matplotlib`, `pandas`; `imageio` and `ffmpeg` for the videos). Start Jupyter **from that folder**.
2. Run the cells in order. The first cell sets the run flags as plain Python variables: edit them there (`QUICK`, `RUN_NETWORK`, `RUN_VIDEOS`, `RUN_FULL`). Nothing else has to be configured.
3. Expected time in QUICK mode with the greedy only (`RUN_NETWORK = False`): about 5 minutes for the footwear warehouse and about 35 minutes for the pharmaceutical one, almost all in the protocol comparison of §6 (nine protocol runs with 2,385 product types). The network cells add a few minutes each in QUICK mode; the videos a few more.
4. Every heavy cell saves its result in `cache_<dataset>/` as soon as it is computed, so you can close the notebook and reopen it: the cells find their results on disk and finish in seconds. If you change a decision in the first cell (for instance `EXTRA_CAPACITY`), delete the cache folder, or the results of the sections that depend on it, before re-running.
5. The delivered copy was executed in QUICK mode with the greedy only; the numbers quoted in the readings come from that execution (one seed, so differences of a few percentage points between variants are not significant). The network cells and the full-scale protocol of §10 are to be run on your machine."""))
    # ---------- 1 setup ----------
    c.append(md("# 1 · Setup and dataset choice"))
    c.append(code(f"""import os, sys, time, json, pickle, numpy as np, pandas as pd, matplotlib.pyplot as plt
sys.path.insert(0, os.path.abspath("whrl_pkg")) if os.path.isdir("whrl_pkg") else None
from whrl import *
from whrl.rolling import Judge, run_rolling, Protocol, summarize, move_cost
from whrl.budget import brute_force_curve, golden_section, bisection_marginal, threshold_estimator
from whrl.knowledge import SURROGATES, set_surrogate, current_surrogate, build_W, build_counts
from whrl import fullscale as fs, analysis as an
plt.rcParams.update({{"font.size": 9, "axes.spines.top": False, "axes.spines.right": False}})
G, GL = "#444444", "#a6a6a6"

# ============================== DATASET SWITCH ==============================
DATASET = "{dataset}"                                   # "footwear" or "pharma": nothing else changes
PATHS = {{"footwear": "footwear/footwear_mendeley", "pharma": "pharma"}}
# ============================== RUN MODES ===================================
QUICK = True            # True: reduced grids and iterations (minutes on a laptop); False: full scale of every cell
RUN_NETWORK = True      # True: run the cells that need PyTorch (network training, §4.3, §4.4, and the network rows of §5, §6, §9)
RUN_VIDEOS = True       # True: render the two videos of §8 (needs RUN_NETWORK)
RUN_FULL = False        # True: run the full-scale statistical protocol of §10 inside the notebook (hours to days)
# the same flags can be set from the environment, e.g. QUICK=0 or RUN_NETWORK=0 before starting Jupyter
QUICK = os.environ.get("QUICK", "1" if QUICK else "0") == "1"; RUN_NETWORK = os.environ.get("RUN_NETWORK", "1" if RUN_NETWORK else "0") == "1"
RUN_VIDEOS = os.environ.get("RUN_VIDEOS", "1" if RUN_VIDEOS else "0") == "1" and RUN_NETWORK; RUN_FULL = os.environ.get("RUN_FULL", "1" if RUN_FULL else "0") == "1"
SEED = 0
# ============================== SHARED DECISIONS ============================
DISTANCE = "realistic"                                  # optimizer and judge: the walking distance of the dataset (aisles for footwear, floor for pharma); "manhattan" is the check of §9.1
EXTRA_CAPACITY = 0                                      # capacity of a position = current occupancy + this
WARM, N_VAL = 3, 3                                      # warm-up months; validation months (the first N_VAL evaluation months)
T_TRAIN_PER_K, T_PLAY_PER_K = 2, 4                      # moves per unit of budget in a training game and in a real reorganization (no cap): see §4.3
GREEDY_TEMPERATURE = "adaptive"                         # sampling temperature of the greedy: "adaptive" (§4.1) or a fixed number, e.g. 1.0
B_TRAIN, TRAIN_CHUNK_MB = 8, 512                        # games per training iteration; memory allowed to the graph of one chunk of moves (§4.3)
# ===========================================================================
CACHE = f"cache_{{DATASET}}" + ("" if QUICK else "_full"); os.makedirs(CACHE, exist_ok=True)   # one cache per mode: quick and full-scale results never overwrite each other
def cached(name, fn):
    # heavy results on disk, one file per unit of work: the cell resumes after an interruption; delete the file to recompute
    f = f"{{CACHE}}/{{name}}.pkl"
    if os.path.exists(f): return pickle.load(open(f, "rb"))
    r = fn(); pickle.dump(r, open(f, "wb")); return r
def note(name, obj):
    # intermediate results kept also as readable JSON (for the report and for the thesis tables)
    json.dump(obj, open(f"{{CACHE}}/{{name}}.json", "w"), indent=1, default=str)
ds = load_dataset(DATASET, PATHS[DATASET], distance=DISTANCE, extra_capacity=EXTRA_CAPACITY)
J = Judge(ds); months = ds.months
print(f"dataset: {{ds.name}} | product types P = {{ds.P}} | positions L = {{ds.L}} (of {{ds.notes['n_positions_plan']}} in the plan) | orders {{len(ds.orders):,}} | months {{months[0]}} → {{months[-1]}}")
print(f"movable product types: {{ds.movable.sum()}} of {{ds.P}} | capacity per position: min {{ds.capacity.min()}}, mean {{ds.capacity.mean():.2f}}, max {{ds.capacity.max()}} | relocation cost κ: {{ds.notes['kappa_note']}}")
print(an.size_summary(ds))"""))

    # ---------- 2 exploring ----------
    c.append(md("""# 2 · Exploring the dataset
Before optimizing we must know *which kind* of warehouse we have: how many product types and positions, how large the floor plan is and how distance units translate into time, how concentrated the demand is, how large the orders are (this decides how much the dependencies weigh against popularity), how much the demand changes from month to month (this decides whether retouches and multi-instance training can pay off), and how far the real layout is from the single-home model. Every figure has a reading below it."""))
    c.append(md("## 2.1 · Product types, positions, orders and floor plan"))
    c.append(md("""### Where the positions and the units come from
""" + ("""**Files.** The public footwear dataset (Mendeley Data) gives the orders with their dates, the rack coordinates of every storage position and the product type stored in each. The plan has 2,292 positions on several rack levels; the picking levels are the two lowest, 846 positions, and these are the positions of the method (`levels=(1, 2)` in the loader). 208 product types occupy 208 of them; the other 638 are free and can receive a relocation. **Unit of distance.** The coordinates are on a grid with a 7.6 cm step, as the authors state: one distance unit = 7.6 cm, and the plan is 44 × 109 m. **Time.** The dataset has no times, so the hours are a convention: a walking speed of 1.27 m/s, i.e. 0.060 s per unit; one hour of walking is 60,000 units.""" if fw else """**Files.** `mappa_magazzino.csv` has the 1,430 bays drawn on the floor plan (1,412 read from the plan, 16 assumed on a rack without measures, 2 extrapolated at the border). `istanza_qap/locazioni.csv` has the 972 bays that appear in the pick lines of the ten months and are on the plan: the pick lines cite 973 distinct bays, one (LOC1124) is not on the plan and is excluded. These 972 are the positions of the method, and their index 0-971 is the index of the distance matrix `D.npy` and of the co-pick matrix `F.npy`. The other 458 bays never appear in a pick: it is not known whether they are empty or used for something else, so the method does not use them as free positions (a prudent choice, stated here). **Levels.** The pick lines carry a level, L01 to L04 (plus L06, 159 picks): the height of the shelf inside the bay. The level does not change the walking, only the handling time (`costo_livelli.csv`), so the method collapses it: one position = one bay, and the product types on the shelves of the same bay are the product types of that position (2.45 on average, up to 19); the capacity of a position is its current occupancy. This is why almost every move here is a swap. `slotting_attuale.csv` gives for every product type its main bay and level; `istanza_qap/assegnazione_attuale.csv` is the same reduced to (product type, index of the position), the current layout. **Unit of distance.** `D.npy` is in cells of the plan grid (118 × 63), one cell = one bay; the dataset has no metric size. **Time.** Measured: 0.548 s per cell walked and 71 s per pick, from a linear model on the recorded pick times. The cell size in metres is an estimate from that: 0.548 s at 1.1-1.3 m/s gives 0.60-0.70 m, so about 65 cm and a plan of about 41 × 77 m; it is only used to draw the plan in metres.""") + """

**Why the two warehouses have different units and it does not matter.** Each notebook works in the units of its dataset: distances, score and net saving are never converted. The two warehouses are compared only through quantities without units or in hours: the gross saving (a share), the net saving in hours (through the time model of each dataset), and the relocation cost, which is defined in labour time and then expressed in the units of each dataset with the same time model (one hour = 60,000 units for footwear, ten minutes = 1,095 units for the pharmaceutical warehouse)."""))
    c.append(code("""o = ds.orders; n = o["refs"].str.len(); pop = pd.Series(np.bincount(np.concatenate(list(o["refs"])), minlength=ds.P)).sort_values(ascending=False)
fig, ax = plt.subplots(1, 4, figsize=(15, 3))
vc = n.value_counts().sort_index(); ax[0].bar(vc.index[:20], vc.values[:20], color=G); ax[0].set_yscale("log"); ax[0].set_title("(a) distinct product types per order (log)"); ax[0].set_xlabel("product types per order")
ax[1].loglog(np.arange(1, ds.P+1), pop.values+1, color=G); ax[1].set_title("(b) popularity by rank"); ax[1].set_xlabel("rank of the product type"); ax[1].set_ylabel("orders containing it")
vol = o.groupby("month").size(); ax[2].bar(range(len(vol)), vol.values, color=GL); ax[2].set_xticks(range(len(vol))); ax[2].set_xticklabels([str(m)[-2:] for m in vol.index]); ax[2].set_title("(c) orders per month")
dep = ds.notes["depot"]; ax[3].scatter(ds.slot_xy[:,0], ds.slot_xy[:,1], s=2, c=GL, marker="s"); ax[3].scatter([dep[0]],[dep[1]], s=60, c="k", marker="v"); ax[3].set_aspect("equal"); ax[3].set_xticks([]); ax[3].set_yticks([]); ax[3].set_title("(d) floor plan (positions) and depot")
plt.tight_layout(); plt.show()
print(f"orders {len(o):,} | product types per order: mean {n.mean():.2f}, median {n.median():.0f}, max {n.max()} | orders with a single product type {100*(n==1).mean():.1f}%")
print(f"share of the orders of the 20 most popular product types {100*pop.head(20).sum()/pop.sum():.1f}% | of the first 100: {100*pop.head(100).sum()/pop.sum():.1f}%")
print(f"orders per month: min {vol.min():,}, mean {vol.mean():,.0f}, max {vol.max():,}")
print(f"walking of the current layout in the first month: {J.month_distance(ds.pl_asis, months[0]):,.0f} distance units = {ds.hours(J.month_distance(ds.pl_asis, months[0])):,.0f} hours ({ds.time_model['source']})")"""))
    c.append(md("""### Reading (2.1)
* **(a)** decides the relative weight of the two parts of the score: many single-type orders → proximity to the depot dominates; large orders → the dependencies between product types dominate.
* **(b)** a straight line in log-log scale is a power law: few product types make most of the demand, so moving a few well-chosen product types can be worth a lot (the premise of the budget).
* **(c)** months with far fewer orders than the others are partial and are excluded from the evaluation (rule in §3.1); **(d)** is the geometry used by the judge.
* The last line converts distance units into hours with the time model of the dataset: it is the unit in which the net savings are also reported."""))
    c.append(md("""## 2.2 · How much the demand changes from month to month
Two complementary measures. The cosine similarity compares, month by month, how many orders contain each product type with the same count in the first month (1 = same composition of the demand). The table below is the *churn*: the share of the most-picked product types of a month that are still among the most-picked of the next month, and the Spearman correlation of the monthly counts per product type (1 = identical ranking). The number of top product types is the same rule in both warehouses: 50, or a tenth of the product types rounded to the hundred when that is larger."""))
    c.append(code("""from collections import Counter
mv = an.monthly_popularity(ds)
cos = [float(mv[m] @ mv[months[0]] / (np.linalg.norm(mv[m])*np.linalg.norm(mv[months[0]]) + 1e-12)) for m in months]
def top_pairs(m, k=50):
    cnt = Counter()
    for its in o[o.month==m]["refs"]:
        for i in range(len(its)):
            for j in range(i+1, len(its)): cnt[(its[i], its[j])] += 1
    return set(p for p,_ in cnt.most_common(k))
tp = {m: top_pairs(m) for m in months}
jac = [np.nan] + [len(tp[a]&tp[b])/max(1,len(tp[a]|tp[b])) for a,b in zip(months[:-1], months[1:])]
TOP = int(max(50, round(ds.P / 10, -2)))
STAB = an.demand_stability(ds, TOP)
fig, ax = plt.subplots(figsize=(7, 2.8)); ax.plot(range(len(months)), cos, "k-o", ms=3, label="popularity vs first month (cosine)"); ax.plot(range(len(months)), jac, "k--s", ms=3, label="top-50 pairs, consecutive months (Jaccard)")
ax.plot(range(1, len(months)), STAB.top_kept, "-^", color=GL, ms=3, label=f"top-{TOP} product types kept, consecutive months")
ax.set_xticks(range(len(months))); ax.set_xticklabels([str(m) for m in months], rotation=45); ax.set_ylim(0, 1.05); ax.legend(frameon=False, fontsize=8); ax.set_title("change of the demand over time"); plt.tight_layout(); plt.show()
display(STAB.style.format({"top_kept": "{:.0%}", "spearman": "{:.2f}"}).set_caption(f"churn between consecutive months: share of the top-{TOP} product types kept, and Spearman correlation of the monthly counts (1 = identical demand)"))
DRIFT = dict(cos_min=min(cos), cos_mean=float(np.mean(cos[1:])), jac_mean=float(np.nanmean(jac)), top=TOP, top_kept=(float(STAB.top_kept.min()), float(STAB.top_kept.mean()), float(STAB.top_kept.max())), spearman=(float(STAB.spearman.min()), float(STAB.spearman.mean()), float(STAB.spearman.max())))
note("drift", DRIFT); print({k: (v if not isinstance(v, tuple) else tuple(round(x, 2) for x in v)) for k, v in DRIFT.items()})"""))
    c.append(md("""### Reading (2.2)
These numbers are needed twice. In §6 they tell whether a monthly retouch can pay off: a retouch is worth doing when the demand changes enough to make last month's layout stale, *and* the relocation cost is low enough; with a stable demand (top product types mostly kept, Spearman close to 1) the retouch has little to repair, and the cost decides. In §4.4 they tell whether training the network on several scenarios (windows, bootstrap, synthetic orders) can pay off against training on the warm-up window alone."""))
    c.append(md("""## 2.3 · How far the real layout is from the single-home model
The model gives every product type **one** position. The adapter measures how true this is in the data: from how many positions each product type is actually picked, which share of its picks its most-used position serves, and how many product types share a position. The current layout of the model takes, for every product type, its most-picked position (ties and conflicts resolved by pick frequency). All savings in this notebook, including the walking of the current layout, are measured inside this model."""))
    c.append(code("""LP = an.layout_profile(ds); note("layout_profile", LP)
npos, share = ds.notes["positions_per_type"], ds.notes["main_share"]; occ = np.bincount(ds.pl_asis, minlength=ds.L)
fig, ax = plt.subplots(1, 3, figsize=(13, 2.8))
ax[0].hist(npos, bins=min(40, int(npos.max()) + 1), color=G); ax[0].set_title("(a) positions each product type is picked from"); ax[0].set_xlabel("positions"); ax[0].set_ylabel("product types")
ax[1].hist(share, bins=20, color=G); ax[1].set_title("(b) share of picks of the most-used position"); ax[1].set_xlabel("share (1 = one position serves all picks)")
vc = pd.Series(occ[occ > 0]).value_counts().sort_index(); ax[2].bar(vc.index, vc.values, color=GL); ax[2].set_title("(c) product types per position (current layout)"); ax[2].set_xlabel("product types in the position"); ax[2].set_ylabel("positions")
plt.tight_layout(); plt.show()
a, b, c_ = LP["positions_per_type"]; print(f"positions each product type is picked from: min {a}, mean {b:.1f}, max {c_} | product types picked from more than one position: {LP['types_with_several_positions']} of {ds.P}")
a, b, c_ = LP["main_position_share"]; print(f"share of the picks served by the most-used position: min {a:.2f}, mean {b:.2f}, max {c_:.2f}")
a, b, c_ = LP["types_per_position"]; print(f"product types per position in the current layout: min {a}, mean {b:.2f}, max {c_} | positions with free capacity: {LP['free_positions']} of {ds.L}")
kind = "single home: the data already give one position per product type" if LP["main_position_share"][1] > 0.9 else "scattered storage reduced to a single home: the model is a simplification, see the reading"
print("layout type:", kind)"""))
    c.append(md("""### Reading (2.3)
* If the mean share in **(b)** is close to 1, the single-home model is the reality of the warehouse and the only simplification is the choice of the main position for the few product types with several positions.
* If it is low, the warehouse uses **scattered storage** (the same product type in many positions) and the single-home model is a strong simplification: the walking it computes is not the real walking, and the savings are savings *within the model*. This limit must be stated with the results; a judge that picks every product type from its nearest copy is the extension to study.
* **(c)** tells whether positions are shared: with one product type per position and free positions the optimizer can relocate to free capacity; with full shared positions almost every move is a swap (compared in §4.1)."""))
    if not fw:
        c.append(md("""## 2.4 · Recording check: the product types that appear in several positions
A few product types appear in two or three positions in the raw data. The next cell checks whether this is stock split between shelves or the same pick recorded twice: in every order where one of these product types is picked, it appears in all its positions, with twin rows sharing start time, quantity and duration. If so, it is one operation recorded twice (the master data associate the product type with two positions), the warehouse has a single position per product type, and the orders do not change because they are sets of distinct product types. This is a data check, not a method decision: the twin notebook has no such artefact."""))
        c.append(code("""rp_ = pd.read_csv("pharma/righe_prelievo.csv", sep=";"); sl_ = pd.read_csv("pharma/slotting_attuale.csv", sep=";")
multi = set(sl_[sl_.n_locazioni > 1].articolo); rm = rp_[rp_.articolo.isin(multi)]
g = rm.groupby(["articolo", "transazione"]).agg(pos=("locazione", "nunique"), ini=("inizio", "nunique"), q=("quantita", "nunique"), d=("durata_s", "nunique"))
print(f"product types with more than one position: {len(multi)} of {sl_.articolo.nunique()} ({100*len(multi)/sl_.articolo.nunique():.1f}%)")
print(f"orders in which the product type appears in all its positions: {100*(g.pos > 1).mean():.0f}% of {len(g):,}")
print(f"twin rows with the same start time, quantity and duration: {100*((g.ini == 1) & (g.q == 1) & (g.d == 1)).mean():.1f}%")
print(f"duplicated rows: {len(rm) - len(g):,} ({100*(len(rm) - len(g))/len(rp_):.2f}% of the recorded picks)")"""))

    # ---------- 3 score ----------
    c.append(md("""# 3 · From orders to the score F
`build_knowledge` extracts from a window of orders the popularity `sp` and the dependencies `W` between product types. The score is F = Σ Mᵖ over the entries of a matrix M: off the diagonal M = W ⊙ (D + γ(d_exit_p + d_exit_q)), the weight of a pair times the distance between its two positions (plus, with γ > 0, their distances to the depot); on the diagonal β·sp·d_exit, the popularity of a product type times its distance to the depot. Lower is better. The improvement of a single move costs O(P) instead of O(P²): this is what makes it possible to evaluate thousands of moves.

The score has choices, and the two warehouses use the same candidates:
* **weights of the pairs**: association rules from FP-Growth (α·confidence + (1 − α)·support, α = 0.7) or raw co-pick counts (orders containing both product types);
* **form**: p = 2, the sum of the squares of the entries (the squared Frobenius norm), or p = 1, the plain sum;
* **depot weight β** and **cross-term weight γ**.

Three named candidates: `rules_squared` (rules, p = 2, β = 5, γ = 0.3, the score of Notebooks 1-6), `copicks_linear` (co-picks, p = 1, β = 2, γ = 0: the index of the QAP instance shipped with the pharmaceutical dataset, written per product type) and `copicks_linear_b5` (co-picks, p = 1, β = 5, γ = 0). The choice between them is made on the validation months with the rule of §3.4, identical in the two warehouses.

**Why the form matters, in one example.** With the plain sum a product type that makes the pickers walk 10 metres and one that makes them walk 2 contribute 10 + 2 = 12, i.e. the metres themselves, and saving one metre on either lowers F by 1. With the squares they contribute 100 + 4 = 104: saving one metre on the first lowers F by 19, on the second by 3, so the search goes first after the product types with the longest walking, even when saving the same metres elsewhere would be as good."""))
    c.append(md("""## 3.1 · Evaluation months, validation and test
A method that learns must never be trained on the months on which it is judged: if it has already seen them, the test no longer measures how it behaves on new months, only how well it remembers (data contamination). The rule applied here, identical in the two warehouses: the knowledge used to train the network comes only from the **warm-up** months; the **validation** months are used only to choose (score, budgets, checkpoints); the **test** months are looked at only once, to report the results. The greedy has no training: every month it uses the orders of the three previous months and never sees the month it is judged on."""))
    c.append(code("""vol = ds.orders.groupby("month").size()
EVAL = [m for m in months[WARM:] if vol[m] >= 0.3 * vol.median()]          # same rule in both warehouses: a month with less than 30% of the median orders is partial and excluded
split = fs.Split(ds, J, EVAL, n_val=N_VAL); VAL, TEST = split.val, split.test
STATIC = {m: split.static[m] for m in EVAL}; D_STATIC = sum(STATIC.values()); D_VAL = sum(STATIC[m] for m in VAL); D_TEST = sum(STATIC[m] for m in TEST)
print(f"warm-up {[str(m) for m in months[:WARM]]} | validation {[str(m) for m in VAL]} | test {[str(m) for m in TEST]}")
print(f"walking of the current layout: validation {D_VAL:,.0f} units ({ds.hours(D_VAL):,.0f} h) | test {D_TEST:,.0f} units ({ds.hours(D_TEST):,.0f} h)")
K0 = KM = None                       # the budgets are chosen in §4.2
K_SEL = int(round(0.25 * ds.P))     # provisional budget for the comparisons of §3: a quarter of the product types, large enough to show differences, small enough to keep every run short
STEPS_GRID = 600 if QUICK else 1500; SEEDS_GRID = [0] if QUICK else [0, 1]
STEPS_CAP = 2000 if QUICK else None                     # QUICK only: a reorganization never exceeds 2,000 greedy steps (compute shortcut for very large budgets; full scale has no cap)
def gsteps(K, base):
    # steps of the greedy for a budget K: at least `base` and 3 per unit of budget (fs.greedy_steps), capped in QUICK mode
    n = fs.greedy_steps(K, base); return n if STEPS_CAP is None else min(n, max(base, STEPS_CAP))
wo = ds.orders[ds.orders.month.isin(months[:WARM])]
def gross_val(W_, sp_, K, gamma, beta, p, seed, moves="general"):
    # one initial reorganization with the given score settings, judged on the validation months (gross saving, higher is better)
    pl = optimize(RollEnv(ds, W_, sp_, ds.pl_asis, K, gamma, beta, p=p, moves=moves), steps=gsteps(K, STEPS_GRID), rng=np.random.default_rng(seed), temperature=GREEDY_TEMPERATURE)
    return float((D_VAL - sum(J.month_distance(pl, m) for m in VAL)) / D_VAL)
print(f"comparisons of §3: greedy with budget K_SEL = {K_SEL}, {STEPS_GRID} steps, seeds {SEEDS_GRID}, judged on the validation months")"""))
    c.append(md("""## 3.2 · Four forms of the score, isolated one at a time
The next cell changes one choice at a time: the weights (rules or co-picks), the form (squares or plain sum) and the depot term (with or without). The fourth variant, co-picks, plain sum, no depot term, is the pure QAP of the pairs. Same greedy, same budget, same validation months: the numbers are gross savings, higher is better."""))
    c.append(code("""VARIANTS = [("rules, squares, with depot", "rules", 2, 0.3, 5.0), ("co-picks, squares, with depot", "copicks", 2, 0.3, 5.0),
            ("co-picks, plain sum, with depot (β = 5)", "copicks", 1, 0.0, 5.0), ("co-picks, plain sum, with depot (β = 2, QAP instance)", "copicks", 1, 0.0, 2.0), ("co-picks, plain sum, no depot (pure QAP)", "copicks", 1, 0.0, 0.0)]
def ablate_forms():
    rows = []
    for lab, w, p, g, b in VARIANTS:
        W_, sp_ = build_W(wo, ds.P, use_mlxtend=False, alpha=0.7) if w == "rules" else build_counts(wo, ds.P)
        for s in SEEDS_GRID: rows.append(dict(variant=lab, seed=s, gross=gross_val(W_, sp_, K_SEL, g, b, p, s)))
    return pd.DataFrame(rows)
ABL = cached("score_forms", ablate_forms); note("score_forms", ABL.groupby("variant", sort=False).gross.mean().to_dict())
display(ABL.groupby("variant", sort=False)["gross"].agg(mean="mean", std="std").style.format("{:.1%}").set_caption("gross saving on the validation months (higher is better) for each form of the score"))"""))
    c.append(md("""### Reading (3.2)
Read the table top-down. The depot term is what keeps popular product types near the depot: when most orders contain a single product type it is the term that matters most, and the pure QAP (last row), which only sees pairs, loses a lot. The form (squares or sum) and the weights (rules or co-picks) matter more when orders are large and the walking is spread over many pairs. A difference smaller than the standard deviation between seeds is not a difference."""))
    c.append(md("""## 3.3 · Where the weights of the score come from, and how sensitive the result is to them
Four numbers of the score are not learned from the data: **α** (mix of confidence and support, only with rule weights; 0.7 from Notebook 1), **γ** (depot distances inside the pair terms; 0.3 from Notebook 3), **β** (weight of the depot term; 5 from Notebook 3, 2 in the QAP instance of the pharmaceutical dataset, where every pick weighs its distance to the depot once) and **p** (the form). The next cell measures the sensitivity to each one with the same greedy, the same budget and the validation months: β from 0 to 10, γ = 0 or 0.3, and α = 0.3, 0.7, 1 with rule weights. The numbers are gross savings: higher is better. A value sits on a *plateau* when its neighbours give the same saving within the variability between seeds: that is the only sense in which a value is "right"."""))
    c.append(code("""BETAS = [0.0, 2.0, 5.0, 10.0] if QUICK else [0.0, 1.0, 2.0, 5.0, 10.0, 20.0]
def sensitivity():
    rows = []
    for w, p in (("rules", 2), ("copicks", 1)):
        W_, sp_ = build_W(wo, ds.P, use_mlxtend=False, alpha=0.7) if w == "rules" else build_counts(wo, ds.P)
        for b in BETAS:
            for g in (0.0, 0.3):
                for s in SEEDS_GRID: rows.append(dict(weights=w, form=p, alpha=0.7 if w == "rules" else None, beta=b, gamma=g, seed=s, gross=gross_val(W_, sp_, K_SEL, g, b, p, s)))
    for a in (0.3, 1.0):
        W_, sp_ = build_W(wo, ds.P, use_mlxtend=False, alpha=a)
        for s in SEEDS_GRID: rows.append(dict(weights="rules", form=2, alpha=a, beta=5.0, gamma=0.3, seed=s, gross=gross_val(W_, sp_, K_SEL, 0.3, 5.0, 2, s)))
    return pd.DataFrame(rows)
SENS = cached("score_sensitivity", sensitivity); note("score_sensitivity", SENS.to_dict("records"))
B = SENS[SENS.alpha.isin([0.7, None]) | SENS.alpha.isna()].groupby(["weights", "form", "gamma", "beta"]).gross.mean().unstack("beta")
display(B.style.format("{:.1%}").set_caption("gross saving on the validation months (higher is better) as a function of the depot weight β (columns), for each weights/form/γ (rows)"))
A = SENS[(SENS.weights == "rules") & (SENS.beta == 5.0) & (SENS.gamma == 0.3)].groupby("alpha").gross.mean()
display(A.to_frame("gross saving").style.format("{:.1%}").set_caption("rule weights, squares, β = 5, γ = 0.3: effect of the confidence/support mix α"))"""))
    c.append(md("""### Reading (3.3)
* **β**: look for the plateau. β = 0 removes the depot term; the saving usually rises quickly with β and then stays flat. The value used by a candidate is justified if it sits on the plateau.
* **γ**: the pair term already contains the distance between the two positions; γ adds their distances to the depot, which β already counts. If the rows γ = 0 and γ = 0.3 are equal within the seed variability, γ is not needed.
* **α**: a high confidence weight favours rare pairs that are always picked together; whether that helps depends on how large the orders are.
* The variability between seeds (standard deviation in §3.2) is the resolution of this table: smaller differences are not improvements."""))
    c.append(md("""## 3.4 · The score used from here on, chosen on the validation months
Same rule in both warehouses: among the three named candidates, the one with the highest gross saving on the validation months with the greedy at budget K_SEL. The test months are never looked at. The environment variable `SURROGATE` overrides the choice (to run the notebook with a given score on purpose, e.g. for the single-score experiment of §10)."""))
    c.append(code("""CANDIDATES = ["rules_squared", "copicks_linear", "copicks_linear_b5"]
def score_choice():
    rows = []
    for name in CANDIDATES:
        cfg = SURROGATES[name]; W_, sp_ = build_W(wo, ds.P, use_mlxtend=False, alpha=cfg["alpha"]) if cfg["weights"] == "rules" else build_counts(wo, ds.P)
        for s in SEEDS_GRID: rows.append(dict(score=name, seed=s, gross=gross_val(W_, sp_, K_SEL, cfg["gamma"], cfg["beta"], cfg["p"], s)))
    return pd.DataFrame(rows)
CH = cached("score_choice", score_choice); CHm = CH.groupby("score", sort=False).gross.mean()
display(CH.groupby("score", sort=False).gross.agg(mean="mean", std="std").style.format("{:.1%}").set_caption("the three candidates on the validation months (gross saving, higher is better)"))
SURROGATE = os.environ.get("SURROGATE") or CHm.idxmax(); set_surrogate(SURROGATE); SFX = f"_{SURROGATE}"
note("score_choice", dict(candidates=CHm.to_dict(), chosen=SURROGATE, forced=bool(os.environ.get("SURROGATE"))))
print(f"score used from here on: {SURROGATE} {SURROGATES[SURROGATE]} ({'forced by the environment variable' if os.environ.get('SURROGATE') else 'best on validation'})")
W0, sp0 = build_knowledge(wo, ds.P, use_mlxtend=(DATASET == "footwear"))
env0 = RollEnv(ds, W0, sp0, ds.pl_asis, K=10**9).reset(); print(f"knowledge of the warm-up window: non-zero dependencies {(W0 > 0).sum():,} | F of the current layout = {env0.F2:,.0f}")"""))
    c.append(md("""### Reading (3.4)
The rule is the same in both warehouses and looks only at the validation months; the chosen score names the cache files from here on, so running the notebook with another score (environment variable `SURROGATE`) keeps both sets of results."""))

    # ---------- 4 who to move ----------
    c.append(md("""# 4 · Who to move: greedy and network
**Greedy.** At every step: sample a product type in proportion to its weight in F, try a handful of candidate positions (random, near the depot, near its partners), execute the best one, accept also worsening moves to escape local minima, and return the best layout seen. No learned parameter.

**Network.** It learns **one thing only: which product type to move**. *Where* is left to the verifier (the best of the candidate positions by decrease of F), because that is exact, costs O(P), and the network would waste capacity rediscovering it. Input: for every product type six numbers (position coordinates, distance to the depot, popularity in the window, current contribution to F, already moved). A Transformer without positional encoding (the product types are a set, not a sequence) looks at all of them together; a linear head produces one number per product type; the softmax turns it into a **probability of being chosen** (zero, through −∞, for the product types the budget forbids); the product type is drawn at random. **REINFORCE**: B parallel games on the same instance, reward = decrease of F per move, advantage = standardized deviation from the batch mean. The network never sees the right move: it learns from the results of its own choices.

**The budget is not a training parameter.** K enters as a constraint (mask) and as the length of the game; a different budget is evaluated without retraining.

**Where the training games start.** The network must train on the two situations it will meet: the initial reorganization (from the current layout) and the monthly retouch (from an already reorganized layout). For the second a credible starting layout is needed: the greedy produces it once (`pl_after_K0`) and it is reused. In deployment the retouches start from the layouts produced by the network the month before; the archive of starting layouts (`ARCHIVE`) can be extended with snapshots of the network (ablation of §10)."""))
    c.append(md("""## 4.1 · The move set: general moves against swaps only, with and without spare capacity
Same greedy, same budget K_SEL, same validation months, four settings: moves = general (relocation to free capacity or swap) or swaps only, with the capacity of the data or one extra product type per position. Where positions are full the two move sets coincide; where free positions exist the comparison measures what relocations to free capacity are worth."""))
    c.append(code("""def move_sets():
    rows = []
    for extra in (0, 1):
        ds_e = ds if extra == 0 else load_dataset(DATASET, PATHS[DATASET], distance=DISTANCE, extra_capacity=1)
        for moves in ("general", "swap_only"):
            for s in SEEDS_GRID:
                pl = optimize(RollEnv(ds_e, W0, sp0, ds_e.pl_asis, K_SEL, moves=moves), steps=gsteps(K_SEL, STEPS_GRID), rng=np.random.default_rng(s), temperature=GREEDY_TEMPERATURE)
                gross = (D_VAL - sum(J.month_distance(pl, m) for m in VAL)) / D_VAL
                rows.append(dict(extra_capacity=extra, moves=moves, seed=s, free_positions=int((np.bincount(ds_e.pl_asis, minlength=ds_e.L) < ds_e.capacity).sum()), gross=gross))
    return pd.DataFrame(rows)
MS = cached(f"move_sets{SFX}", move_sets); note("move_sets", MS.to_dict("records"))
display(MS.groupby(["extra_capacity", "moves"]).agg(free_positions=("free_positions", "first"), gross=("gross", "mean"), std=("gross", "std")).style.format({"gross": "{:.1%}", "std": "{:.1%}"}).set_caption("gross saving on the validation months (higher is better) for each move set and capacity"))"""))
    c.append(md("""### The sampling temperature of the greedy
The greedy picks the product type to move at random, with probability proportional to its weight in F raised to a temperature τ: τ = 1 is proportional, τ > 1 concentrates on the worst-placed product types, τ = 0 is uniform. The adaptive rule (τ starts at 1.5, falls by 0.15 every 100 steps while the moves keep paying, rises by 0.30 when the gain of the last 100 steps drops below half of the previous ones) is compared here with the fixed τ = 1 of the earlier notebooks, same budget and seeds, on the validation months. The notebook uses `GREEDY_TEMPERATURE` from §1 everywhere else."""))
    c.append(code("""def temperatures():
    rows = []
    for name, temp in (("fixed, τ = 1", 1.0), ("adaptive", "adaptive")):
        for s in SEEDS_GRID:
            pl = optimize(RollEnv(ds, W0, sp0, ds.pl_asis, K_SEL), steps=gsteps(K_SEL, STEPS_GRID), rng=np.random.default_rng(s), temperature=temp)
            rows.append(dict(temperature=name, seed=s, gross=(D_VAL - sum(J.month_distance(pl, m) for m in VAL)) / D_VAL))
    return pd.DataFrame(rows)
TMP = cached(f"greedy_temperature{SFX}", temperatures); note("greedy_temperature", TMP.to_dict("records"))
display(TMP.groupby("temperature", sort=False).gross.agg(mean="mean", std="std").style.format("{:.1%}").set_caption("gross saving on the validation months (higher is better): fixed against adaptive sampling temperature of the greedy"))"""))
    c.append(md("""### Reading (4.1)
If the rows "general" and "swap_only" are equal with the capacity of the data, the warehouse has no usable free capacity and every move is a swap. The rows with one extra product type per position measure what spare room would be worth: it is a physical hypothesis to verify with the warehouse, not a result of the data. The method keeps the general move set and the capacity of the data."""))
    c.append(md("""## 4.2 · The budgets of this notebook, chosen on the validation months with a cheap search
Two budgets: K₀ for the initial reorganization and Kₘ for the monthly retouch. Both are chosen with the same rule (`whrl.fullscale.choose_budgets`), on the validation months only. Trying every budget would cost one reorganization, with the judge, per value (52 values in §7.2); the method instead uses a **golden-section search**: it keeps an interval of budgets, evaluates two budgets inside it, discards the side with the lower net and stops when the interval is narrower than 2% of the product types. About ten evaluations in all, against 52 for the fine curve of §7.2. Every reorganization starts from the same random seed (`SEED` of §1), so the net of a budget is always the same, whichever search asks for it and in whatever order. Two different budgets are, however, two different runs of the greedy (more steps for a larger budget, the budget binds at a different moment), so the net curve has small bumps around its maximum; what the search loses because of them is measured in §7.2 against the fine curve.

**How the two budgets are chosen, step by step (same in both warehouses).**
1. K₀. For a budget K, one initial reorganization is made from the current layout with the warm-up knowledge; the judge measures the walking of the three validation months with the new layout; the net is the walking saved minus the relocation cost. The golden-section search on K between 0 and the number of product types returns K₀.
2. Kₘ, after K₀. Starting from the layout obtained with K₀, a retouch of Kₘ product types is made on the second validation month with the knowledge of the three previous months; its net is the walking saved in that month minus its relocation cost. The same search on Kₘ between 0 and half of the product types returns Kₘ; if no evaluated retouch has a positive net, Kₘ = 0.

Kₘ therefore depends on three things: the relocation cost (what the retouch must pay back; §6 repeats the choice with half and double cost), K₀ (the better the initial reorganization, the less is left to repair) and the horizon on which a retouch is judged (one month here, because a retouch stays in use until the next one; §7.3 repeats the choice with the whole validation period as horizon)."""))
    c.append(code("""STEPS0, STEPSM = (1500, 1000)
def make_greedy(seed=SEED, moves="general", steps0=STEPS0, stepsm=STEPSM):
    # the optimizer with the signature of the protocol: (W, sp, starting layout, K) -> layout.
    # Every call starts a fresh random stream from the same seed: the result of a reorganization depends only on its inputs
    # (knowledge, starting layout, budget), never on which reorganizations were run before. So the net of a budget is the
    # same whichever search asks for it, in whatever order, and a rerun gives the same numbers.
    return lambda W, sp, pl0, K: optimize(RollEnv(ds, W, sp, pl0, K, moves=moves), steps=gsteps(K, steps0 if K >= (K0 or 1) else stepsm), rng=np.random.default_rng(seed), temperature=GREEDY_TEMPERATURE)   # at least 3 steps per unit of budget, so that a large budget can be used
BUD = cached(f"budgets_validation{SFX}", lambda: fs.choose_budgets(ds, J, make_greedy(SEED, steps0=STEPS_GRID, stepsm=STEPS_GRID), split))
K0, KM = BUD["K0"], BUD["Km"]; pl_after_K0 = BUD["pl_after"]
note("budgets", dict(K0=K0, Km=KM, curve_K0={int(k): float(v) for k, v in BUD["memo0"].items()}, curve_Km={int(k): float(v) for k, v in BUD["memom"].items()}))
print(f"budgets used from here on: K0 = {K0} ({100*K0/ds.P:.0f}% of the product types) | Km = {KM} ({'no retouch pays on validation' if KM == 0 else f'{100*KM/ds.P:.1f}% of the product types per month'})")
greedy_fn = make_greedy(SEED)
ARCHIVE = [ds.pl_asis.copy(), pl_after_K0.copy()]      # starting layouts of the training games: current layout (initial regime) and layout after K0 (retouch regime)
# The network learns WHICH product types to move when not all of them can be moved. If validation chose K0 = every product
# type (it happens when a relocation is very cheap), there is nothing left to choose: the network is then trained and compared
# at a quarter of the product types, the same rule in both warehouses, and the fact is printed.
K_NET = K0 if K0 < ds.P else int(round(0.25 * ds.P))
print(f"budget of the network experiments: K_NET = {K_NET}" + ("" if K_NET == K0 else f" (K0 = {K0} is every product type: no choice left to learn, so the network is compared at a quarter of them)"))"""))
    c.append(md("""### Reading (4.2)
Read the two budgets as the answer of the data, not as settings: K₀ is where the net saving of one initial reorganization stops growing on validation, Kₘ is whether a monthly retouch pays on validation. A Kₘ of 0 is a legitimate answer and makes the hybrid protocol a single-shot one. Both depend on the relocation cost: a cheaper relocation raises K₀ and makes a retouch more likely to pay (the sensitivity is in §6)."""))
    c.append(md("""## 4.3 · The network, zero-shot: one instance, both regimes
Trained on one instance (the knowledge of the warm-up window) and on both regimes: half of the games are initial reorganizations from the current layout with budget K_NET (§4.2), half are retouches from `pl_after_K0` with budget Kₘ (when Kₘ = 0 the retouch regime has nothing to learn and only the initial regime is played).

**How long a game is.** A game proceeds one move at a time (a relocation to free capacity or a swap) and ends when the budget is spent, that is when K product types are away from their starting position, or after T moves. T must exceed the budget, because the same product type can be moved more than once in a game and counts once in the budget. The rule, identical in the two warehouses: T = 2 × K in the training games and T = 4 × K when the network reorganizes for real (it plays a few games and keeps the best layout), with **no fixed cap**: a cap chosen for a small warehouse would cut a large budget short.

**What a move costs.** At every move the network looks at the six numbers of every product type (coordinates of the position, distance to the depot, popularity, weight in F, already moved) and gives each product type a probability of being chosen. Its central step is self-attention: a score for every pair of product types, which is how a Transformer encoder lets each element see all the others. The number of pairs grows with the square of the number of product types: with 208 product types it is about 43 thousand, with 2,385 about 5.7 million, roughly 130 times more per move. This is why the same training takes much longer in a warehouse with many product types.

**Memory of the training.** The learning rule (REINFORCE) needs, for every move of a game, the gradient of the log-probability of the chosen product type, weighted by how good the whole game was. Keeping the computation graph of all the moves of a game until the end would need memory proportional to the game length times the square of the number of product types: with games of 2 × K moves that runs out of memory on a laptop. The trainer therefore plays each game once without graph, recording the moves, then replays the same moves and recomputes the gradient a few moves at a time (`moves_per_chunk`, sized by `TRAIN_CHUNK_MB` of §1). The gradient is the same, because the loss is a sum over the moves; the memory is bounded by the chunk; the cost is one extra forward pass per move. The first network cell runs a check of this equivalence on a tiny game (one iteration in each mode from the same weights and seed; the printed difference is float rounding, below 1e-5) and prints how many moves are back-propagated together in this warehouse. **How the learning is measured.** The reward printed by the trainer mixes games of the two regimes, which have very different sizes, so its average over iterations is not a learning curve. The measure used here is at **fixed regime**: the share of F removed by the network in games of the initial reorganization from the current layout, before and after training, same instance and same budget."""))
    c.append(code("""if RUN_NETWORK:
    import torch
    from whrl.policy import ProductPolicy, make_trainer, moves_per_chunk
    def equivalence_check(T_small=6, B_small=2):
        # the same tiny game trained in the two memory modes must move the weights the same way
        out = {}
        for mode in ("full", "chunked"):
            torch.manual_seed(0); pol_c = ProductPolicy(); torch.manual_seed(1)
            tr_c = make_trainer(pol_c, ds, lambda rng_: (W0, sp0, ds.pl_asis, K_NET), B=B_small, T=T_small, seed=0, memory=mode, chunk_mb=1)
            tr_c.step(1); out[mode] = {k: v.detach().clone() for k, v in pol_c.state_dict().items()}
        return max(float((out["full"][k] - out["chunked"][k]).abs().max()) for k in out["full"])
    print(f"largest difference between the two memory modes after one tiny iteration: {equivalence_check():.2e} (expected: below 1e-5)")
    print(f"moves back-propagated together in this warehouse: {moves_per_chunk(ds.P, B_TRAIN, TRAIN_CHUNK_MB)} (B_TRAIN = {B_TRAIN}, {TRAIN_CHUNK_MB} MB)")"""))
    c.append(code("""if RUN_NETWORK:
    import torch
    from whrl.policy import ProductPolicy, make_trainer, policy_reorganize
    torch.manual_seed(SEED); rng = np.random.default_rng(SEED)
    def sampler_static(rng_):
        # one instance (warm-up knowledge), two regimes: initial reorganization from the current layout with K_NET, or retouch from the layout after K0 with KM
        if KM == 0 or rng_.random() < 0.5: return W0, sp0, ds.pl_asis, K_NET
        return W0, sp0, ARCHIVE[rng_.integers(1, len(ARCHIVE))], KM
    T_BY = {K_NET: T_TRAIN_PER_K * K_NET, KM: T_TRAIN_PER_K * max(KM, 1)}   # training game length tied to the budget (§1), no cap
    def fixed_regime_reward(pol, n_games=3):
        # share of F removed in games of the initial reorganization from the current layout (same instance, same budget)
        F0 = RollEnv(ds, W0, sp0, ds.pl_asis, K_NET).reset().F2
        pl = policy_reorganize(pol, ds, W0, sp0, ds.pl_asis, K_NET, n_games=n_games, rng=np.random.default_rng(123), T_moves=T_PLAY_PER_K * K_NET)
        return float((F0 - RollEnv(ds, W0, sp0, pl, 0).reset().F2) / F0)
    def train_resumable(name, pol, trainer, iters, every=5):
        # training saved every `every` iterations: an interrupted run resumes from the last checkpoint
        PT = f"{CACHE}/{name}.pt"; done = 0
        if os.path.exists(PT): ck = torch.load(PT, weights_only=False); pol.load_state_dict(ck["state"]); done = ck["iters"]; trainer.hist.extend(ck["hist"])
        t0 = time.time()
        while done < iters:
            trainer(min(every, iters - done)); done += min(every, iters - done); torch.save(dict(state=pol.state_dict(), iters=done, hist=trainer.hist), PT)
        return done, time.time() - t0
    ITERS = 40 if QUICK else 600
    policy = ProductPolicy(); r_before = fixed_regime_reward(policy)
    trainer = make_trainer(policy, ds, sampler_static, B=B_TRAIN, T=60, seed=SEED, T_by_regime=T_BY, chunk_mb=TRAIN_CHUNK_MB)
    done, secs = train_resumable(f"policy_zeroshot{SFX}", policy, trainer, ITERS)
    r_after = fixed_regime_reward(policy)
    print(f"zero-shot network: {done} iterations ({secs:.0f}s in this session, {secs/max(1, done):.1f}s per iteration with {ds.P} product types) | share of F removed at fixed regime: untrained {r_before:.1%} → trained {r_after:.1%}")
    def make_policy_fn(pol, seed=SEED, n_games=None):
        ng = n_games or (3 if QUICK else 6)
        # same rule as the greedy: a fresh random stream from the same seed at every reorganization; 4 moves per unit of budget, no cap
        return lambda W, sp, pl0, K: policy_reorganize(pol, ds, W, sp, pl0, K, n_games=ng, rng=np.random.default_rng(seed), T_moves=T_PLAY_PER_K * K)
    policy_fn = make_policy_fn(policy)
else: print("RUN_NETWORK = False: the network cells are skipped (PyTorch needed)")"""))
    c.append(md("""## 4.4 · Zero-shot against multi-instance training (data augmentation)
The same network trained on different pools of instances, all built **only from the warm-up months** (nothing from validation or test): `static` (one instance), `monthly` (one per warm-up month), `weekly_bootstrap` (windows of one week, orders resampled with replacement) and `synthetic` (orders generated from a model fitted on the warm-up months: order size from the empirical distribution, product types drawn by popularity and by the co-pick profile of the previous one). Each network plays half of its games in the initial regime and half in the retouch regime. The comparison is the **net saving on the validation months** with the greedy as reference; in QUICK mode the networks are under-trained, so only large differences are meaningful. Every training is saved on disk and resumable.

**Why these four.** They differ in one thing only, the source of the variety of the training instances: none (one instance), the months, the weeks with resampling, a synthetic model. Mixtures of two sources, or a training in two stages (synthetic first, then real), would change two things at once and are not needed to answer the question of this section: which source of variety helps the network."""))
    c.append(code("""if RUN_NETWORK:
    POOLS = ["static", "monthly", "weekly_bootstrap", "synthetic"]; N_POOL = 10 if QUICK else 30
    ITERS_MI = 40 if QUICK else 300
    def multi_instance():
        rows, trained = [], {}
        g_net = fs.net_validation(ds, J, split, make_greedy(SEED), K_NET, KM); rows.append(dict(training="greedy (no training)", net_validation=g_net, hours=ds.hours(g_net)))   # same budget K_NET for greedy and network
        for kind in POOLS:
            pool = [(W0, sp0)] if kind == "static" else fs.instance_pool(ds, months[:WARM], kind, n=N_POOL, seed=SEED)
            starts = ARCHIVE if KM > 0 else [ds.pl_asis]
            pol = ProductPolicy(); tr = make_trainer(pol, ds, fs.make_sampler(pool, starts, K_NET, max(KM, 1)), B=B_TRAIN, T=60, seed=SEED, T_by_regime=T_BY, chunk_mb=TRAIN_CHUNK_MB)
            done, secs = train_resumable(f"policy_{kind}{SFX}", pol, tr, ITERS_MI)
            n_net = fs.net_validation(ds, J, split, make_policy_fn(pol), K_NET, KM); trained[kind] = pol.state_dict()
            rows.append(dict(training=f"network, {kind} ({len(pool)} instances)", net_validation=n_net, hours=ds.hours(n_net), iterations=done))
        return pd.DataFrame(rows), trained
    MI, MI_STATE = cached(f"multi_instance{SFX}", multi_instance); note("multi_instance", MI.to_dict("records"))
    display(MI.style.format({"net_validation": "{:+,.0f}", "hours": "{:+,.1f}"}).set_caption("net saving on the validation months (distance units and hours; higher is better): greedy against the network trained on each pool"))"""))
    c.append(md("""### Reading (4.4)
Multi-instance training can only pay off when the demand of the evaluation months differs from the warm-up window (the churn of §2.2); with a stable demand the static instance already represents the months to come. Read the differences against the resolution of the comparison: in QUICK mode one seed and a few dozen iterations; the decision belongs to the full-scale runs of §10, where each pool is trained with checkpoints, early stopping on validation and several seeds."""))

    # ---------- 5 protocol ----------
    c.append(md("""# 5 · The protocol over time
Three months of warm-up for the first knowledge; one initial reorganization with budget K₀; then every month a retouch with budget Kₘ computed on the orders of the last three months. Every optimizer is called with the same signature `(W, sp, starting layout, K) → layout`, so the protocol does not know which one it is using. The judge measures every month with the true routes. The table reports: gross saving (share of distance saved against never reorganizing), labour of the relocations, **net** saving (the decision metric: distance saved minus labour; 0 = the reorganization exactly pays for itself), the same net in **hours**, the distance of the last two months (how well the change of demand is followed) and the number of relocations. All over the evaluation months; the test-only comparison of the protocols is in §6."""))
    c.append(code("""proto = Protocol(warm=WARM, K0=K0, Km=KM, window=3, eval_months=EVAL)            # the protocol with the budgets chosen on validation (§4.2)
res_g = cached(f"rolling_greedy{SFX}", lambda: run_rolling(ds, make_greedy(SEED), proto, J))
rows = [summarize(ds, res_g, D_STATIC, f"greedy, hybrid (K0 = {K0})")]
proto_net = Protocol(warm=WARM, K0=K_NET, Km=KM, window=3, eval_months=EVAL)     # the same protocol at the budget of the network experiments: greedy and network at equal budget
if K_NET != K0:
    res_gn = cached(f"rolling_greedy_knet{SFX}", lambda: run_rolling(ds, make_greedy(SEED), proto_net, J)); rows.append(summarize(ds, res_gn, D_STATIC, f"greedy, hybrid (K = {K_NET})"))
if RUN_NETWORK:
    res_p = cached(f"rolling_network{SFX}", lambda: run_rolling(ds, make_policy_fn(policy), proto_net, J)); rows.append(summarize(ds, res_p, D_STATIC, f"network, hybrid (K = {K_NET})"))
cmp = pd.DataFrame(rows).set_index("name"); note("rolling", cmp.to_dict("index"))
display(cmp.style.format({"gross": "{:+.1%}", "labor": "{:,.0f}", "net": "{:+,.0f}", "net_hours_saved": "{:+,.1f}", "last_two_months": "{:,.0f}"}).set_caption("hybrid protocol over all evaluation months; gross and net saving: higher is better"))
fig, ax = plt.subplots(figsize=(7, 2.8)); ax.plot(range(len(EVAL)), [STATIC[m] for m in EVAL], "k:", label="never reorganizing"); ax.plot(range(len(EVAL)), res_g["dist"], "k-o", ms=3, label="greedy, hybrid")
if RUN_NETWORK: ax.plot(range(len(EVAL)), res_p["dist"], "-s", color=GL, ms=3, label="network, hybrid")
ax.axvspan(-0.5, N_VAL - 0.5, color="#eeeeee", label="validation months"); ax.set_xticks(range(len(EVAL))); ax.set_xticklabels([str(m) for m in EVAL], rotation=45); ax.set_ylabel("distance of the month"); ax.legend(frameon=False, fontsize=8); plt.tight_layout(); plt.show()"""))
    c.append(md("""### Reading (5)
The plot shows the distance of every month: the gap between the dotted line (never reorganizing) and the others is the gross saving; the grey band marks the validation months, whose relocation costs are charged to the validation period and not to the test."""))

    # ---------- 6 protocols ----------
    c.append(md("""# 6 · Single-shot, hybrid and from scratch, with the budgets chosen on validation
Three protocols with the same optimizer: **single-shot** (the initial reorganization with K₀ and nothing else), **hybrid** (K₀ then a retouch with Kₘ every month) and **from scratch** (a full reorganization every month, without budget). The only difference between single-shot and hybrid is the retouches: if the single-shot wins, the retouches cost more than they save. The table is over the **test months only** (the costs of the validation months are not charged to the test), so it is the honest comparison; when Kₘ = 0 was chosen on validation, hybrid and single-shot coincide by construction. Because the relocation cost decides this comparison, it is repeated with half and double the cost: for those rows the retouch budget Kₘ is chosen again on validation with the new cost (K₀ is kept: the initial reorganization falls in the validation months and its cost is not in the test rows). A last row forces a retouch of 5% of the product types every month: it separates what a retouch saves in walking (gross) from whether it pays (net). The other ingredient of the answer is how much the demand changes from month to month (§2.2): with a stable demand a retouch has little to repair, so it pays only when a relocation is cheap."""))
    c.append(code("""def protocols_all():
    out = {}
    for kappa_mult in (0.5, 1.0, 2.0):
        kappa0 = ds.notes["kappa"]; ds.notes["kappa"] = kappa0 * kappa_mult
        try:
            # the retouch budget depends on the relocation cost: with a different cost it is chosen again on validation (same golden-section search as §4.2);
            # K0 is kept, because the initial reorganization falls in the validation months and its cost is not in the test rows
            if kappa_mult == 1.0: b = BUD
            else:
                cm = {}; fm = lambda K: fs.retouch_curve(ds, J, make_greedy(SEED, steps0=STEPS_GRID, stepsm=STEPS_GRID), pl_after_K0, VAL[1], [int(K)], cache=cm)[int(K)]
                km_, memo = golden_section(fm, 0, ds.P // 2, tol=max(1, int(round(0.02 * ds.P)))); b = dict(K0=K0, Km=int(km_) if memo[int(km_)] > 0 else 0)
            rr, raw = fs.compare_protocols(ds, J, lambda: make_greedy(SEED), split, b["K0"], b["Km"]); out[("greedy", kappa_mult)] = (b["K0"], b["Km"], rr)
            if kappa_mult == 1.0 and K_NET != K0:    # greedy at the budget of the network, so that the two are compared at equal budget
                rr, raw = fs.compare_protocols(ds, J, lambda: make_greedy(SEED), split, K_NET, b["Km"]); out[("greedy at K_NET", kappa_mult)] = (K_NET, b["Km"], rr)
            if RUN_NETWORK and kappa_mult == 1.0: rr, raw = fs.compare_protocols(ds, J, lambda: make_policy_fn(policy), split, K_NET, b["Km"]); out[("network", kappa_mult)] = (K_NET, b["Km"], rr)
        finally: ds.notes["kappa"] = kappa0
    # a retouch forced every month, 5% of the product types, with the cost of the dataset: it shows that a retouch saves walking (gross) and whether it pays (net)
    KM_FORCED = max(1, int(round(0.05 * ds.P)))
    rr, raw = fs.compare_protocols(ds, J, lambda: make_greedy(SEED), split, K0, KM_FORCED); out[("greedy, retouch forced", 1.0)] = (K0, KM_FORCED, {"hybrid (forced retouch)": rr["hybrid"]})
    return out
PR = cached(f"protocols{SFX}", protocols_all)
rows = [dict(optimizer=o_, relocation_cost=f"{k_}× κ", K0=k0_, Km=km_, protocol=p_, gross=v["gross"], net=v["net"], hours=v["net_hours"]) for (o_, k_), (k0_, km_, rr) in PR.items() for p_, v in rr.items()]
T6 = pd.DataFrame(rows).set_index(["optimizer", "relocation_cost", "K0", "Km", "protocol"]); note("protocols", rows)
display(T6.style.format({"gross": "{:+.1%}", "net": "{:+,.0f}", "hours": "{:+,.1f}"}).set_caption("test months only: gross saving, net saving (distance units) and net hours, higher is better; κ = the relocation cost of the dataset; K0 and Km chosen on validation for each cost"))
km_by_cost = {k_: km_ for (o_, k_), (k0_, km_, rr) in PR.items() if o_ == "greedy"}
fig, ax = plt.subplots(figsize=(4.2, 2.6)); ax.bar([f"{k}× κ" for k in sorted(km_by_cost)], [km_by_cost[k] for k in sorted(km_by_cost)], color=G)
ax.set_ylabel("retouch budget Km"); ax.set_title("retouch chosen on validation, by relocation cost"); plt.tight_layout(); plt.show()"""))
    c.append(md("""### Reading (6)
* **Hybrid against single-shot** measures the retouches alone. The initial reorganization falls in the validation months, so its cost is not in these rows: the single-shot row does not change with the cost, and the retouches (hybrid) and the monthly full reorganizations (from scratch) are what the cost acts on. With Kₘ > 0 the hybrid should win when the demand changes and the relocation cost is low (κ/2 rows), and lose when the cost is high (2κ rows): the sign of the difference is the finding, not its size. When validation chooses Kₘ = 0, hybrid and single-shot coincide by construction.
* **From scratch** is the upper bound of the gross saving and the lower bound of the net one: it moves almost everything every month, and its labour is charged every month.
* The budgets were chosen on validation, so the test rows are a fair measure; §7 shows how the best budget would move with a longer horizon of use."""))

    # ---------- 7 budget ----------
    c.append(md("""# 7 · The choice of the budget: techniques, cost of the choice, and dependence on the horizon
Choosing the budget means finding the K with the highest net saving. Every evaluation of a K is expensive: one reorganization plus the judge on the months of interest. Four techniques, all with the greedy:
* **exact curve**: net(K) for every K of a fine list, a budget every 2% of the product types, 52 values (the reference: one reorganization per value, each followed by the judge on the months of interest);
* **golden section**: maximum of a unimodal function with O(log n) evaluations;
* **bisection**: on the sign of the marginal gain net(K + δ) − net(K), O(log n) evaluations;
* **estimate K̂**: no reorganization at all: it counts the product types whose best single move saves more than its relocation cost, converting the score into distance with a scale taken from one pilot reorganization.

Two further questions: **how the best budget depends on the horizon** (a relocation is paid once, its saving accumulates every month: the longer the new layout stays in use, the more relocations pay off), and **the value of the monthly retouch** as a function of its budget, measured from the layout after the initial reorganization."""))
    c.append(md("## 7.1 · The exact curve month by month and the best budget as a function of the horizon"))
    c.append(code("""GRID = sorted(set([0] + [int(round(x)) for x in np.linspace(0, ds.P, 52)[1:]]))   # fine grid: a budget every 2% of the product types (52 values, 0 included), in both modes
CUR = cached(f"initial_curve{SFX}", lambda: fs.initial_curve(ds, J, make_greedy(SEED, steps0=STEPS_GRID, stepsm=STEPS_GRID), EVAL, GRID))
STATIC_ARR = np.array([STATIC[m] for m in EVAL]); H = len(EVAL)
NETS = pd.DataFrame({h: {K: fs.net_from_curve(CUR, STATIC_ARR, K, h) for K in GRID} for h in range(1, H + 1)}); NETS.index.name = "K"; NETS.columns.name = "months of use"
KSTAR = NETS.idxmax(); note("budget_horizon", dict(grid=GRID, best_K_by_horizon={int(h): int(k) for h, k in KSTAR.items()}, nets=NETS.to_dict()))
fig, ax = plt.subplots(1, 2, figsize=(11, 3))
for h in (1, N_VAL, H): ax[0].plot(GRID, NETS[h] / 1e6, "-o", ms=3, color={1: GL, N_VAL: "#777777", H: "k"}[h], label=f"{h} month{'s' if h > 1 else ''} of use")
ax[0].axhline(0, color="k", lw=0.5); ax[0].set_xlabel("budget K of the initial reorganization"); ax[0].set_ylabel("net saving (millions of units)"); ax[0].set_title("(a) net saving against the budget, by horizon"); ax[0].legend(frameon=False, fontsize=8)
ax[1].plot(range(1, H + 1), KSTAR.values, "k-o", ms=3); ax[1].set_xlabel("months the new layout stays in use"); ax[1].set_ylabel("best budget K"); ax[1].set_title("(b) best budget as a function of the horizon"); ax[1].set_ylim(0, ds.P * 1.05)
plt.tight_layout(); plt.show()
display(NETS.style.format("{:+,.0f}").set_caption("net saving (distance units, higher is better) of one initial reorganization with budget K (rows) kept in use for h months (columns); all evaluation months, descriptive"))
print("best budget by horizon:", KSTAR.to_dict(), "| the budgets used for the test results were chosen on the validation months only (§4.2)")"""))
    c.append(md("""### Reading (7.1)
* Over one month of use almost no budget pays back: the relocations are paid at once, the saving of one month is small. With more months the curve rises and its maximum moves to the right: the best budget is not a property of the warehouse but of **how long the layout will be used**. This is why a budget chosen on a short horizon looks "too low" when judged on a long one.
* Panel (b) is the number to give the warehouse: the budget worth spending for a layout that will stay in use for h months. It uses all evaluation months and is descriptive; the budgets of the test results come from validation only."""))
    c.append(md("## 7.2 · The four techniques on the validation horizon: budget found, loss against the exact curve, reorganizations needed The four techniques are compared on K₀ only, in both warehouses: a search is worth comparing when the curve has a maximum to find, as the curve of K₀ has; the curve of Kₘ (§7.3) is monotone in both warehouses, so every technique would return the same answer. The golden section is the technique the method uses (§4.2); the other three are the alternatives it is compared with. The golden section here is the same search as §4.2, on the same function and with the same stopping rule, so it returns K₀; the table shows what it saves (its reorganizations against the 52 of the fine curve) and what it loses (its net against the best of the fine curve)."))
    c.append(code("""net_val = lambda K: fs.net_from_curve(fs.initial_curve(ds, J, make_greedy(SEED, steps0=STEPS_GRID, stepsm=STEPS_GRID), VAL, [K], cache=CURV), np.array([STATIC[m] for m in VAL]), K, len(VAL))
CURV = cached(f"initial_curve_val{SFX}", lambda: fs.initial_curve(ds, J, make_greedy(SEED, steps0=STEPS_GRID, stepsm=STEPS_GRID), VAL, GRID))
def techniques():
    rows = []; sv = np.array([STATIC[m] for m in VAL]); t0 = time.time()
    exact = {K: fs.net_from_curve(CURV, sv, K, len(VAL)) for K in GRID}; Kx = max(exact, key=exact.get); rows.append(dict(technique="exact curve (grid)", K=Kx, net=exact[Kx], reorganizations=len(GRID), seconds=time.time() - t0))
    for name, fn in (("golden section", lambda: golden_section(net_val, 0, ds.P, tol=max(1, int(round(0.02 * ds.P))), memo={})), ("bisection", lambda: bisection_marginal(net_val, 0, ds.P, delta=max(1, int(0.05 * ds.P)), memo={}))):
        t0 = time.time(); K_, memo = fn()
        # cost of the search = the budgets it evaluated (K = 0 costs nothing); budgets that happen to be on the grid are counted too,
        # because a search used alone, without the grid, would have to run them
        rows.append(dict(technique=name, K=int(K_), net=memo[int(K_)], reorganizations=sum(1 for k in memo if int(k) > 0), seconds=time.time() - t0))
    # estimate without reorganizations: the scale converts points of F into distance units, from the pilot reorganization at K_SEL
    t0 = time.time(); Kp = min(GRID, key=lambda k: abs(k - K_SEL)); d_pl, c_pl, pl_pl = CURV[Kp]
    F_as = RollEnv(ds, W0, sp0, ds.pl_asis, 0).reset().F2; F_pl = RollEnv(ds, W0, sp0, pl_pl, 0).reset().F2
    scale = float((sv.sum() - d_pl.sum()) / max(F_as - F_pl, 1e-9))
    K_hat, gains, costs = threshold_estimator(ds, W0, sp0, ds.pl_asis, rng=np.random.default_rng(SEED), scale=scale)
    rows.append(dict(technique="estimate K̂ (no reorganization)", K=int(K_hat), net=net_val(int(K_hat)), reorganizations=0, seconds=time.time() - t0))
    return pd.DataFrame(rows)
TE = cached(f"budget_techniques{SFX}", techniques); best = float(TE.loc[TE.technique == "exact curve (grid)", "net"].iloc[0])
TE["loss_vs_exact"] = (TE.net - best) / abs(best)   # against the best of the 52 grid budgets: negative = the technique loses net; positive = it found, between two grid points, a budget with a slightly higher net
note("budget_techniques", TE.to_dict("records"))
display(TE.set_index("technique").style.format({"net": "{:+,.0f}", "loss_vs_exact": "{:+.1%}", "seconds": "{:,.1f}"}).set_caption("validation horizon: budget found by each technique, its net saving, difference against the best of the 52 budgets of the fine curve (negative = net lost, positive = a budget between two grid points with a slightly higher net), reorganizations it needed (the fine curve needs 52) and seconds"))"""))
    c.append(md("""### Reading (7.2)
The column *reorganizations* is the cost of each technique: every reorganization is one run of the optimizer followed by the judge (the true routes of the orders), the slow step. The exact curve pays one for each of the 52 values of the grid, the two searches about seven to ten, the estimate none (seconds instead of minutes). Counting the searches against a coarse grid of a few values would hide this advantage, which is why the grid is fine. The column *loss* says what that cost buys: a search is good when its loss is within the noise of the curve (the greedy is stochastic, so neighbouring budgets differ by a few percent). The estimate is cheap and rough, and its scale depends on one pilot reorganization."""))
    c.append(md("## 7.3 · The value of the monthly retouch as a function of its budget"))
    c.append(code("""GRID_M = sorted(set([0] + [int(round(x)) for x in np.linspace(0, ds.P / 2, 7)[1:]]))
RT = cached(f"retouch_curve{SFX}", lambda: fs.retouch_curve(ds, J, make_greedy(SEED, steps0=STEPS_GRID, stepsm=STEPS_GRID), pl_after_K0, VAL[1], GRID_M))
RTs = pd.Series(RT).sort_index(); note("retouch_curve", {int(k): float(v) for k, v in RTs.items()})
fig, ax = plt.subplots(figsize=(5.5, 2.8)); ax.plot(RTs.index, RTs.values / 1e6, "k-o", ms=3); ax.axhline(0, color="k", lw=0.5); ax.set_xlabel("budget Km of the retouch"); ax.set_ylabel("net saving of the month (millions of units)"); ax.set_title(f"one retouch on {VAL[1]}, from the layout after K0 = {K0}"); plt.tight_layout(); plt.show()
print(f"best retouch budget on {VAL[1]}: {int(RTs.idxmax())} (net {RTs.max():+,.0f} units = {ds.hours(RTs.max()):+,.1f} h); Km chosen in §4.2 by the golden-section search: {KM}")"""))
    c.append(md("""### The same question with a longer horizon
The curve above judges a retouch on the month that follows it. A retouch also leaves its mark on the months after, until the next retouch changes the layout again. To check that the one-month horizon is not what makes the retouch lose, the whole hybrid protocol (initial reorganization with K₀, then a retouch of Kₘ at every later validation month) is judged here on all the validation months together, for a few values of Kₘ: none, 5%, 12.5% and 25% of the product types. The choice of §4.2 stands if Kₘ = 0 is still the best."""))
    c.append(code("""KM_H = sorted({0, max(1, int(round(0.05 * ds.P))), int(round(0.125 * ds.P)), int(round(0.25 * ds.P))})   # the same fractions of the product types in both warehouses
def km_horizon():
    rows = []
    for km_ in KM_H:
        nv = fs.net_validation(ds, J, split, make_greedy(SEED), K0, km_)   # hybrid protocol over all the validation months: initial K0, then km_ every later month
        rows.append(dict(Km=km_, share=km_ / ds.P, net_validation=nv, hours=ds.hours(nv)))
    return pd.DataFrame(rows)
KMH = cached(f"km_horizon{SFX}", km_horizon); note("km_horizon", KMH.to_dict("records"))
display(KMH.set_index("Km").style.format({"share": "{:.1%}", "net_validation": "{:+,.0f}", "hours": "{:+,.1f}"}).set_caption("net saving of the hybrid protocol over ALL the validation months (distance units and hours, higher is better) for a few retouch budgets Km; K0 fixed"))
print(f"best Km with the whole validation as horizon: {int(KMH.loc[KMH.net_validation.idxmax(), 'Km'])} (Km chosen in §4.2 on one month: {KM})")"""))
    c.append(md("""### Reading (7.3)
This is the curve the choice of Kₘ comes from. It starts at 0 (no retouch, net 0) and says whether moving a few product types one month after the initial reorganization saves more walking in that month than it costs. When the whole curve is negative the retouch does not pay with this relocation cost and this churn, and the hybrid protocol collapses into the single-shot one. The dependence on the cost is visible in §6."""))

    # ---------- 8 videos ----------
    c.append(md("""# 8 · The videos
Two videos, with the same format in both warehouses. **Video 1, the simulation**: one initial reorganization played by the trained network, move by move, on the floor plan seen from above: dark positions hold frequently ordered product types, the blue route is a real order, the red arrow the product type being moved; the counters show the product types moved against the budget and the walking over a sample of real orders. **Video 2, the learning**: the network at successive checkpoints next to the greedy, with the training reward and the true distance on control orders. The checkpoints are computed once and cached (resumable); the schedule is identical in the two warehouses: in QUICK mode 15 checkpoints of 10 iterations, at full scale 30 of 20."""))
    c.append(code("""if RUN_VIDEOS:
    from whrl import video as wv
    os.makedirs("videos", exist_ok=True)
    floor = wv.Floor(ds, map_csv=("pharma/mappa_magazzino.csv" if DATASET == "pharma" else None))   # geometry for drawing
    month0 = ds.orders[ds.orders.month == EVAL[0]]
    sample_orders = month0.sample(min(300, len(month0)), random_state=0)          # control orders of video 2
    kpi_orders = month0.sample(min(500, len(month0)), random_state=2)              # orders of the counter of video 1
    pool_o = month0[month0["refs"].str.len().between(4, 8)]; pool_o = pool_o.sample(min(400, len(pool_o)), random_state=1)   # candidates for the highlighted order
    pop_w = np.bincount(np.concatenate(list(wo["refs"])), minlength=ds.P) / len(wo)   # share of orders containing each product type
    LABEL = "Footwear e-commerce warehouse (public data)" if DATASET == "footwear" else "Pharmaceutical warehouse (real data)"
    pl_g = cached(f"story_greedy{SFX}", lambda: make_greedy(SEED)(W0, sp0, ds.pl_asis, K0))
    pol_v = ProductPolicy(); tr_v = make_trainer(pol_v, ds, sampler_static, B=B_TRAIN, T=60, seed=1, T_by_regime=T_BY, chunk_mb=TRAIN_CHUNK_MB)
    NCK, ITC = (30, 20) if not QUICK else (15, 10)
    CK = wv.learning_checkpoints(ds, J, pol_v, tr_v, W0, sp0, ds.pl_asis, K0, sample_orders, NCK, ITC, f"{CACHE}/learning_ckpts{SFX}.pkl", rng, legacy=None)
    print(f"checkpoints: {len(CK)} | share of F removed {CK[0]['reward']:.2f}% -> {CK[-1]['reward']:.2f}% | distance on the control orders {CK[0]['d']:,.0f} -> {CK[-1]['d']:,.0f} | greedy {J.distance(pl_g, sample_orders):,.0f} | current layout {J.distance(ds.pl_asis, sample_orders):,.0f}")
    pol_best = ProductPolicy(); pol_best.load_state_dict(CK[-1]["state"])
    from whrl.policy import features, budget_mask
    def best_chooser(env):
        mov = np.where(ds.movable)[0]
        with torch.no_grad(): a, _, _ = pol_best(features([env], sp0, mov), budget_mask([env], mov))
        return int(mov[int(a[0])])
    V1 = f"videos/{DATASET}_1_simulation.mp4"
    if not os.path.exists(V1): wv.video_simulation(ds, J, floor, W0, sp0, ds.pl_asis, K0, best_chooser, pop_w, kpi_orders, pool_o, V1, LABEL, n_detail=24, stride=max(1, K0 // 15))
    cand = [list(r) for r in pool_o["refs"]]
    ORDER2 = max(cand, key=lambda o_: (J.tour(ds.pl_asis[o_]) - J.tour(CK[-1]["pl"][o_])) / max(J.tour(ds.pl_asis[o_]), 1e-9))
    V2 = f"videos/{DATASET}_2_learning.mp4"
    if not os.path.exists(V2): wv.video_learning(ds, J, floor, ds.pl_asis, pl_g, CK, sample_orders, ORDER2, pop_w, V2, LABEL, K0)
    print("videos:", V1, V2)
else: print("RUN_VIDEOS = False: videos skipped")"""))

    # ---------- 9 dataset-specific checks ----------
    c.append(md("""# 9 · Checks specific to this dataset (data, not method)
The method is identical in the two warehouses; what differs is what each dataset allows to check. Both warehouses have the same first check: **the Manhattan distance** on the coordinates (which ignores walls and shelves) as a second judge next to the realistic walking distance used by the method, to see how much a simpler distance would mislead in this warehouse. The other checks are those the data make possible."""))
    c.append(md("## 9.1 · A second judge: the Manhattan distance on the coordinates"))
    c.append(code("""ds_r = load_dataset(DATASET, PATHS[DATASET], distance="manhattan", extra_capacity=EXTRA_CAPACITY); J_r = Judge(ds_r)
nz = ds_r.D > 0
print(f"realistic distance / Manhattan distance over all pairs of positions: min {np.min(ds.D[nz] / ds_r.D[nz]):.2f}, mean {np.mean(ds.D[nz] / ds_r.D[nz]):.2f}, max {np.max(ds.D[nz] / ds_r.D[nz]):.2f} | distance to the depot: mean {ds.d_exit.mean():.0f} (realistic) against {ds_r.d_exit.mean():.0f} (Manhattan)")
JUDGES = {"realistic walking distance (used by the method)": J, "Manhattan on the coordinates": J_r}
ASIS = {k: sum(JJ.month_distance(ds.pl_asis, m) for m in TEST) for k, JJ in JUDGES.items()}
runs = [("greedy, hybrid (§5)", res_g)] + ([("network, hybrid (§5)", res_p)] if RUN_NETWORK else [])
rows = []
for name, r in runs:
    for k, JJ in JUDGES.items():
        d = sum(JJ.month_distance(r["placements"][len(VAL) + t], m) for t, m in enumerate(TEST)); rows.append(dict(layout=name, judge=k, gross=(ASIS[k] - d) / ASIS[k]))
T9 = pd.DataFrame(rows).pivot(index="layout", columns="judge", values="gross"); note("second_judge", T9.to_dict())
display(T9.style.format("{:+.1%}").set_caption("gross saving on the test months with the two judges (higher is better): the conclusions should not depend on the judge"))"""))
    if fw:
        c.append(md("""## 9.2 · The static policies of the dataset authors, measured with our judge
The dataset ships the layouts of the four static storage policies compared by its authors (Gomez Gnone, de Assis, Ouhimmou, de Paula Ferreira, IFAC-PapersOnLine 2025): **Random**, **Class-based** (classes by turnover, the most requested closest to the depot), **Dedicated** (every product type and size in its own fixed location) and **Hybrid**. They are the only external comparison possible on this dataset, and it must be made with the same judge. Each layout is brought to the single-home representation (every product type to the position holding most of its boxes), applied once at the start of the evaluation months and kept; the relocations are counted against the current layout and priced with the same cost. Caveat: the policies may have been designed with the demand of the whole period. The other published works on this dataset (de Assis et al., IEEE Access 2024, routing; the data paper, Data in Brief 2025) do not reorganize under a budget nor learn."""))
        c.append(code("""from whrl.footwear_extras import load_static_policies
POL = load_static_policies(PATHS["footwear"], ds); rows = []
for name, pl in POL.items():
    mv_ = np.where(pl != ds.pl_asis)[0]; cost = move_cost(ds, mv_)
    for k, JJ in JUDGES.items():
        d = sum(JJ.month_distance(pl, m) for m in TEST); rows.append(dict(layout=f"static policy: {name}", judge=k, relocations=len(mv_), gross=(ASIS[k] - d) / ASIS[k], net=ASIS[k] - d - cost))
for name, r in runs:
    for k, JJ in JUDGES.items():
        d = sum(JJ.month_distance(r["placements"][len(VAL) + t], m) for t, m in enumerate(TEST)); rows.append(dict(layout=name, judge=k, relocations=r["n_moves"], gross=(ASIS[k] - d) / ASIS[k], net=ASIS[k] - d - r["cost"]))
T92 = pd.DataFrame(rows).pivot(index=["layout", "relocations"], columns="judge", values=["gross", "net"]); note("static_policies", rows)
display(T92.style.format({c_: ("{:+.1%}" if c_[0] == "gross" else "{:+,.0f}") for c_ in T92.columns}).set_caption("test months: gross and net saving against the current layout (higher is better), with the two judges; relocations counted against the current layout"))"""))
        c.append(md("""### Reading (9.1 and 9.2)
Compare the rows at equal judge. A static policy moves almost every product type once; our protocol moves far fewer. If our rows are above the static ones in net saving with both judges, the advantage does not come from the distance simplification. The net saving of the static policies charges their whole relocation at once, which is how the warehouse would pay it."""))
    else:
        c.append(md("""## 9.2 · Real picking sequences: how the pickers actually walk, and a check of the judge
The file `liste_prelievo.csv` lists, for every order, the product types in the chronological order in which they were picked, with the measured working time. On the current layout we compute two lengths per order: the **walked length** (depot → positions in the real order → depot) and the **shortest length** (the route the judge computes). Three questions: how far the pickers are from the shortest route; whether the shortest route explains the measured times as well as the route actually walked (is the judge a sound measure of the work?); and, in §9.3, whether the savings of a new layout survive when the pickers keep their old sequence."""))
        c.append(code("""from whrl.routes import load_pick_lists, route_study, savings_two_routings
from scipy.stats import pearsonr
LISTS = load_pick_lists("pharma/liste_prelievo.csv")
RS = cached("route_study", lambda: route_study(ds, J, LISTS))
ratio = RS.walked / RS.shortest
fig, ax = plt.subplots(1, 2, figsize=(11, 3))
ax[0].hist(ratio.clip(1, 3), bins=60, color=G); ax[0].set_title("(a) walked length / shortest length, per order"); ax[0].set_xlabel("ratio (1 = the picker took the shortest route)")
q = pd.qcut(RS.shortest, 20, duplicates="drop"); qw = pd.qcut(RS.walked, 20, duplicates="drop")
ax[1].plot(RS.groupby(q, observed=True).shortest.mean(), RS.groupby(q, observed=True).time_s.mean(), "k-o", ms=3, label="shortest length (judge)")
ax[1].plot(RS.groupby(qw, observed=True).walked.mean(), RS.groupby(qw, observed=True).time_s.mean(), "k--s", ms=3, label="walked length")
ax[1].set_xlabel("route length (distance units), 20 bins"); ax[1].set_ylabel("mean measured time (s)"); ax[1].set_title("(b) measured time against route length"); ax[1].legend(frameon=False, fontsize=8)
plt.tight_layout(); plt.show()
print(f"orders: {len(RS):,} | walked / shortest: median {ratio.median():.2f}, mean {ratio.mean():.2f}, 90th percentile {ratio.quantile(.9):.2f} | orders within 1% of the shortest route: {100*(ratio <= 1.01).mean():.0f}%")
for col in ("walked", "shortest"):
    X = np.c_[np.ones(len(RS)), RS.picks, RS[col]]; beta = np.linalg.lstsq(X, RS.time_s, rcond=None)[0]; res = RS.time_s - X @ beta
    print(f"time = a + b·picks + c·{col}: R² {1 - (res**2).sum()/((RS.time_s - RS.time_s.mean())**2).sum():.3f} | {beta[1]:.1f} s per pick, {beta[2]:.3f} s per distance unit")"""))
        c.append(md("""## 9.3 · Do the savings survive the pickers' real sequence?
The judge assumes that, after a reorganization, every order is walked along the shortest route through the new positions. The next cell measures the saving of the layouts of §5 on the test months under two assumptions: the route is re-optimized for the new layout (the judge), or the pickers keep picking the product types in the same order as before."""))
        c.append(code("""test_ids = set(ds.orders[ds.orders.month.isin(TEST)]["id"])
ROB = cached(f"routing_robustness{SFX}", lambda: {name: savings_two_routings(ds, J, LISTS, test_ids, ds.pl_asis, r["placements"][len(VAL)]) for name, r in runs})
note("routing_robustness", ROB)
display(pd.DataFrame(ROB).T.style.format({"orders": "{:,.0f}", "saving_reoptimized_route": "{:+.1%}", "saving_same_sequence": "{:+.1%}"}).set_caption("test months: saving with the route re-optimized (judge) and with the old picking sequence kept"))"""))
        c.append(md("""### Reading (9.1 to 9.3)
* **9.1**: a large gap between the two judges means that the Manhattan simplification distorts this warehouse (walls and shelves between positions that are close on the coordinates); it is why the method uses the realistic distance.
* **9.2**: if the shortest length explains the measured times as well as the walked length, the judge is a sound measure of the work, and the seconds per pick and per unit confirm the time model independently of the one shipped with the dataset.
* **9.3**: if the saving disappears with the old sequence kept, the re-slotting pays only if the pick lists are re-sequenced for the new layout, which is what a warehouse management system does when it sorts the picks by position. This condition must be stated when the method is proposed to the company."""))

    # ---------- 10 full scale ----------
    c.append(md("""# 10 · The full-scale statistical protocol
The same protocol in both warehouses, implemented in `whrl.fullscale` (the one of Notebook 6, section 10.8): (1) **validation separated from test** in time; (2) training by **checkpoints** with **early stopping** and selection of the checkpoint on the validation net saving, never on the test; (3) **several seeds**; (4) **paired tests** (t-test and Wilcoxon) between each configuration and the greedy on the monthly test net savings, pairs with the same seed and month. Configurations: `greedy`, `zero-shot` (one instance) and the multi-instance pools `monthly`, `weekly-bootstrap` and `synthetic`, each trained with checkpoints at 150, 300, 450, 600, 900, 1200, 1500, 1800 and 2100 iterations and early stopping after two checkpoints without improvement. Every (configuration, seed) is a unit of work with its own file, so the runs resume after an interruption and seeds can be split across machines by copying the cache folder.

All configurations use the budget of the network experiments, K_NET (§4.2), so that greedy and network are compared at equal budget. The earlier full-scale result of Notebook 6 (network better than the greedy by about 12% on footwear) is discarded: its networks were trained on orders of the validation and test months (§3.1), and the method has changed since; the comparison is recomputed here, in both warehouses. The next cell runs the protocol inside the notebook when `RUN_FULL = True` (hours to days of compute); otherwise it only prints the equivalent command line (`whrl_pkg/scripts/run_full_scale.py`, same code). The iteration counts are the ones of the earlier protocol, the same in both warehouses: checkpoints at 150, 300, 450, 600, 900, 1,200, 1,500, 1,800 and 2,100 iterations, with early stopping on the validation net saving."""))
    c.append(code("""SEEDS_FULL = [int(s) for s in os.environ.get("SEEDS", "0 1 2 3 4").split()]
CONFIGS = ["greedy", "zero-shot", "monthly", "weekly-bootstrap", "synthetic"]
CHECKPOINTS = [150, 300, 450, 600, 900, 1200, 1500, 1800, 2100] if not QUICK else [10, 20]
FULL_DIR = f"{CACHE}/full_scale{SFX}"; KIND = {"zero-shot": "static", "monthly": "monthly", "weekly-bootstrap": "weekly_bootstrap", "synthetic": "synthetic"}
def greedy_unit(seed):
    net, per = fs.test_report(ds, J, split, fs.greedy_opt(ds, K_NET, seed=seed), K_NET, KM); return dict(test=net, months=per, ckpt=None)
def network_unit(kind, seed):
    pool = fs.instance_pool(ds, months[:WARM], kind, n=(10 if QUICK else 30), seed=seed) if kind != "static" else [(W0, sp0)]
    starts = [ds.pl_asis, fs.greedy_opt(ds, K_NET, seed=seed)(W0, sp0, ds.pl_asis, K_NET)] if KM > 0 else [ds.pl_asis]
    pol, st = fs.train_select(ds, J, split, fs.make_sampler(pool, starts, K_NET, max(KM, 1)), seed, K_NET, max(KM, 1), CHECKPOINTS, patience=2, cache_path=f"{FULL_DIR}/{kind}__seed{seed}__training.pt")
    net, per = fs.test_report(ds, J, split, fs.network_opt(pol, ds, seed=seed), K_NET, KM); return dict(test=net, months=per, ckpt=st["best_ck"], validation_curve=st["curve"])
if RUN_FULL:
    import torch; from whrl.policy import ProductPolicy, make_trainer, policy_reorganize
    R = {}
    for seed in SEEDS_FULL:
        for cfg in CONFIGS:
            print(f"--> {cfg}, seed {seed}", flush=True)
            R[(cfg, seed)] = fs.run_unit(FULL_DIR, cfg, seed, (lambda s=seed: greedy_unit(s)) if cfg == "greedy" else (lambda s=seed, k=KIND[cfg]: network_unit(k, s)))
    FULL = fs.summary(R, CONFIGS, SEEDS_FULL); FULL.to_csv(f"{FULL_DIR}/summary.csv"); display(FULL)
else:
    print("RUN_FULL = False. Equivalent command line, from the folder that contains whrl_pkg/, footwear/ and pharma/:")
    print(f"  SURROGATE={SURROGATE} python whrl_pkg/scripts/run_full_scale.py --dataset {DATASET} --seeds {' '.join(map(str, SEEDS_FULL))} --configs {' '.join(CONFIGS)} --k0 {K_NET} --km {KM}")
    print("  (split the seeds across machines with --seeds, copy the cache folders together, then add --summary-only for the final table)")"""))
    c.append(md("""## Experiments to run at full scale, in order
1. **Greedy against network at equal budget**, 5 seeds, both warehouses: the main result, with paired tests.
2. **Zero-shot against multi-instance** (monthly, weekly bootstrap, synthetic): when does variety pay off.
3. **Single-shot, hybrid and from scratch** with the budgets chosen on validation, and with half and double relocation cost (§6).
4. **The score at full scale**: the three candidates of §3.4 plus the variant with co-picks and squares (β = 5, γ = 0.3), with 5 seeds, in both warehouses; the same score should win in both.
5. **Moves and capacity** (§4.1) with the network.
6. **The second judge** (§9.1) used also by the optimizer (`DISTANCE = "aisles"` or `"floor"`).
7. **Archive of starting layouts** with snapshots of the network, and the reward on the true routes at the end of the game (ablations of the training).
8. **Videos** at full scale: 30 checkpoints of 20 iterations."""))
    c.append(code("""summary = dict(dataset=DATASET, quick=QUICK, surrogate=SURROGATE, K0=K0, Km=KM, drift=DRIFT, layout=LP, rolling=cmp.to_dict("index"), protocols=T6.reset_index().to_dict("records"), best_K_by_horizon={int(h): int(k) for h, k in KSTAR.items()})
json.dump(summary, open(f"{CACHE}/summary{SFX}.json", "w"), indent=2, default=str); print(json.dumps(summary, indent=1, default=str)[:2000])"""))
    for cell in c:
        if cell["cell_type"] == "markdown" and cell["source"].startswith("### Reading ("):
            key = cell["source"][len("### Reading ("):cell["source"].index(")")]
            if key in RESULTS: cell["source"] += "\n\n**In this warehouse** (QUICK mode, greedy, one seed): " + (RESULTS[key][0] if fw else RESULTS[key][1])
    nb["cells"] = c; nb.metadata["kernelspec"] = {"name": "python3", "display_name": "Python 3", "language": "python"}
    return nb

if __name__ == "__main__":
    for d, name in [("footwear", "Warehouse_NB7_Footwear.ipynb"), ("pharma", "Warehouse_NB8_Pharma.ipynb")]:
        nbf.write(build(d), name); print("written", name)
